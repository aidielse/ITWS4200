var tweets = [
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802713092100,
        "id_str": "407240802713092096",
        "text": "@Laumontijano GRACIAS LAU!!!ERES UN CARAMELO:)",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240051240615940,
        "in_reply_to_status_id_str": "407240051240615936",
        "in_reply_to_user_id": 489687630,
        "in_reply_to_user_id_str": "489687630",
        "in_reply_to_screen_name": "Laumontijano",
        "user": {
            "id": 315759011,
            "id_str": "315759011",
            "name": "ANQUITA:)",
            "screen_name": "ancamatei1",
            "location": "",
            "url": null,
            "description": "Si ME PIDIERAS EL MUNDO ENTERO,\r\nTE LO DARIA!!!!",
            "protected": false,
            "followers_count": 136,
            "friends_count": 87,
            "listed_count": 1,
            "created_at": "Sun Jun 12 11:53:53 +0000 2011",
            "favourites_count": 202,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2547,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "642D8B",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000113198975/cbde5019a7f5864a012d9d4a08610171.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000113198975/cbde5019a7f5864a012d9d4a08610171.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000717822242/b0aabd40ad81fece1c56fb212c3adddc_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000717822242/b0aabd40ad81fece1c56fb212c3adddc_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/315759011/1384033379",
            "profile_link_color": "0048FF",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "b858babfb96ffae4",
            "url": "https://api.twitter.com/1.1/geo/id/b858babfb96ffae4.json",
            "place_type": "city",
            "name": "Benalmádena",
            "full_name": "Benalmádena, Málaga",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -4.5969769,
                            36.5712406
                        ],
                        [
                            -4.5969769,
                            36.6229195
                        ],
                        [
                            -4.5076793,
                            36.6229195
                        ],
                        [
                            -4.5076793,
                            36.5712406
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Laumontijano",
                    "name": "Laumontijano",
                    "id": 489687630,
                    "id_str": "489687630",
                    "indices": [
                        0,
                        13
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802893434900,
        "id_str": "407240802893434880",
        "text": "até um dia ai",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 741667370,
            "id_str": "741667370",
            "name": "tico. ʕ•̬͡•ʔ",
            "screen_name": "4ever1ddl",
            "location": "",
            "url": "http://www.youtube.com/watch?v=z3zdIHDTbg0",
            "description": "♡ bea // fefs // yasmin // ju // my // debby ♡",
            "protected": false,
            "followers_count": 1981,
            "friends_count": 1764,
            "listed_count": 1,
            "created_at": "Mon Aug 06 23:24:10 +0000 2012",
            "favourites_count": 3404,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 29171,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000121501671/df076511efde96a6b825eb9d7f343ee8.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000121501671/df076511efde96a6b825eb9d7f343ee8.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000772810483/91983448f6859866addc9ebea1489e5e_normal.png",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000772810483/91983448f6859866addc9ebea1489e5e_normal.png",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/741667370/1385093207",
            "profile_link_color": "00DECC",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "68e019afec7d0ba5",
            "url": "https://api.twitter.com/1.1/geo/id/68e019afec7d0ba5.json",
            "place_type": "city",
            "name": "São Paulo",
            "full_name": "São Paulo, São Paulo",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -46.826038999999994,
                            -24.008813999999997
                        ],
                        [
                            -46.826038999999994,
                            -23.356792
                        ],
                        [
                            -46.365052,
                            -23.356792
                        ],
                        [
                            -46.365052,
                            -24.008813999999997
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802889629700,
        "id_str": "407240802889629696",
        "text": "@samcallahan94 missing you not being on the X factor!! Gonna see you at the X factor tour anyway can't wait!! 💕 Love you babe 💜",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": 232680664,
        "in_reply_to_user_id_str": "232680664",
        "in_reply_to_screen_name": "samcallahan94",
        "user": {
            "id": 846237960,
            "id_str": "846237960",
            "name": "Shannon Brooks",
            "screen_name": "shannon123glen",
            "location": "Beechmount close, belfast",
            "url": "http://www.facebook.com",
            "description": "The Janoskians... #Perfect!! Luke :)",
            "protected": false,
            "followers_count": 607,
            "friends_count": 1481,
            "listed_count": 1,
            "created_at": "Tue Sep 25 21:18:15 +0000 2012",
            "favourites_count": 15,
            "utc_offset": 0,
            "time_zone": "Casablanca",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 890,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "11DB3A",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000025040005/aefc5dee566b8a36a76e3916cdcfb757.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000025040005/aefc5dee566b8a36a76e3916cdcfb757.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000815160261/6e9fa84b1ae8772b79ee18ac43f789cc_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000815160261/6e9fa84b1ae8772b79ee18ac43f789cc_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/846237960/1385898552",
            "profile_link_color": "BD0BB1",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                54.59645929,
                -5.96417067
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -5.96417067,
                54.59645929
            ]
        },
        "place": {
            "id": "a5d1791165a6517e",
            "url": "https://api.twitter.com/1.1/geo/id/a5d1791165a6517e.json",
            "place_type": "city",
            "name": "Belfast",
            "full_name": "Belfast, Belfast",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -6.045853999999999,
                            54.5305937
                        ],
                        [
                            -6.045853999999999,
                            54.6648512
                        ],
                        [
                            -5.8071746,
                            54.6648512
                        ],
                        [
                            -5.8071746,
                            54.5305937
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "samcallahan94",
                    "name": "Sam Callahan",
                    "id": 232680664,
                    "id_str": "232680664",
                    "indices": [
                        0,
                        14
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802822524900,
        "id_str": "407240802822524930",
        "text": "“@RauhlxInfinity: Guys we can break the record, lets take it back :) http://t.co/W1k4sYWHro” #mtvstars Justin Bieber",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240602074349600,
        "in_reply_to_status_id_str": "407240602074349568",
        "in_reply_to_user_id": 340820617,
        "in_reply_to_user_id_str": "340820617",
        "in_reply_to_screen_name": "RauhlxInfinity",
        "user": {
            "id": 1237674901,
            "id_str": "1237674901",
            "name": "Princess ",
            "screen_name": "SecuteSantana",
            "location": "'Muricah! ;D",
            "url": "http://www.wattpad.com/user/GlitterWaterfall",
            "description": "I stand for love and sincerity, self-esteem and respect. :) Be honest with me and treat me right and I'll be loyal til the end. Justin Bieber is everything. :)",
            "protected": false,
            "followers_count": 1475,
            "friends_count": 1673,
            "listed_count": 6,
            "created_at": "Sun Mar 03 04:08:09 +0000 2013",
            "favourites_count": 1475,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7317,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "642D8B",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000718286396/80b676b9fc74068f203635a2345c2241_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000718286396/80b676b9fc74068f203635a2345c2241_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1237674901/1382208379",
            "profile_link_color": "FF0000",
            "profile_sidebar_border_color": "65B0DA",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.65679265,
                -84.1566985
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -84.1566985,
                39.65679265
            ]
        },
        "place": {
            "id": "edacd050f402302c",
            "url": "https://api.twitter.com/1.1/geo/id/edacd050f402302c.json",
            "place_type": "city",
            "name": "Centerville",
            "full_name": "Centerville, OH",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -84.208829,
                            39.590614
                        ],
                        [
                            -84.208829,
                            39.673616
                        ],
                        [
                            -84.108731,
                            39.673616
                        ],
                        [
                            -84.108731,
                            39.590614
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "mtvstars",
                    "indices": [
                        93,
                        102
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "RauhlxInfinity",
                    "name": ";",
                    "id": 340820617,
                    "id_str": "340820617",
                    "indices": [
                        1,
                        16
                    ]
                }
            ],
            "media": [
                {
                    "id": 407240602078543900,
                    "id_str": "407240602078543872",
                    "indices": [
                        69,
                        91
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPK4ECAAAlzyO.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPK4ECAAAlzyO.jpg",
                    "url": "http://t.co/W1k4sYWHro",
                    "display_url": "pic.twitter.com/W1k4sYWHro",
                    "expanded_url": "http://twitter.com/RauhlxInfinity/status/407240602074349568/photo/1",
                    "type": "photo",
                    "sizes": {
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "medium": {
                            "w": 600,
                            "h": 465,
                            "resize": "fit"
                        },
                        "large": {
                            "w": 600,
                            "h": 465,
                            "resize": "fit"
                        },
                        "small": {
                            "w": 340,
                            "h": 264,
                            "resize": "fit"
                        }
                    },
                    "source_status_id": 407240602074349600,
                    "source_status_id_str": "407240602074349568"
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802759614460,
        "id_str": "407240802759614464",
        "text": "@batiekush haha you would",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407238331110805500,
        "in_reply_to_status_id_str": "407238331110805504",
        "in_reply_to_user_id": 194332172,
        "in_reply_to_user_id_str": "194332172",
        "in_reply_to_screen_name": "batiekush",
        "user": {
            "id": 409575489,
            "id_str": "409575489",
            "name": "Brooke Shellabarger",
            "screen_name": "Shella_babby",
            "location": "",
            "url": "http://Instagram.com/brooke_shellabarger/",
            "description": "Morehead State University. Space Science.",
            "protected": false,
            "followers_count": 471,
            "friends_count": 491,
            "listed_count": 0,
            "created_at": "Thu Nov 10 23:04:13 +0000 2011",
            "favourites_count": 1369,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10033,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFF04D",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/764940043/fe4c5018a3d64fae8dcadf825c0f73b0.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/764940043/fe4c5018a3d64fae8dcadf825c0f73b0.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000345185913/4afa9a245268ff76400538a33b6cab02_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000345185913/4afa9a245268ff76400538a33b6cab02_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/409575489/1352688758",
            "profile_link_color": "0099CC",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "C790C7",
            "profile_text_color": "1C0B1C",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.88316853,
                -84.311333
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -84.311333,
                39.88316853
            ]
        },
        "place": {
            "id": "b152589e47844e57",
            "url": "https://api.twitter.com/1.1/geo/id/b152589e47844e57.json",
            "place_type": "city",
            "name": "Englewood",
            "full_name": "Englewood, OH",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -84.3434,
                            39.832744
                        ],
                        [
                            -84.3434,
                            39.891294
                        ],
                        [
                            -84.267663,
                            39.891294
                        ],
                        [
                            -84.267663,
                            39.832744
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "batiekush",
                    "name": "kaitlin bush",
                    "id": 194332172,
                    "id_str": "194332172",
                    "indices": [
                        0,
                        10
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803170648060,
        "id_str": "407240803170648064",
        "text": "I ordered that hoe the first week of October &amp; its December 1st. 😡",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 176979510,
            "id_str": "176979510",
            "name": "NTK. ",
            "screen_name": "FreshFlyFloyd",
            "location": "Houston, TX ",
            "url": null,
            "description": "Hampton University Class of '15",
            "protected": false,
            "followers_count": 793,
            "friends_count": 475,
            "listed_count": 3,
            "created_at": "Tue Aug 10 23:18:49 +0000 2010",
            "favourites_count": 57,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 23219,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/545358767/jordan-vs-kobe1.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/545358767/jordan-vs-kobe1.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000489274460/e512602f8e43bd37962026cec24177d5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000489274460/e512602f8e43bd37962026cec24177d5_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/176979510/1366763011",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                38.8932862,
                -76.74164789
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -76.74164789,
                38.8932862
            ]
        },
        "place": {
            "id": "369842624da7239c",
            "url": "https://api.twitter.com/1.1/geo/id/369842624da7239c.json",
            "place_type": "city",
            "name": "Bowie",
            "full_name": "Bowie, MD",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -76.800051,
                            38.889876
                        ],
                        [
                            -76.800051,
                            39.012463
                        ],
                        [
                            -76.693975,
                            39.012463
                        ],
                        [
                            -76.693975,
                            38.889876
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802922815500,
        "id_str": "407240802922815489",
        "text": "@Abo3es2  اذبحتك الذكريات طلعت شايب",
        "source": "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
        "truncated": false,
        "in_reply_to_status_id": 407236910449692700,
        "in_reply_to_status_id_str": "407236910449692672",
        "in_reply_to_user_id": 78123983,
        "in_reply_to_user_id_str": "78123983",
        "in_reply_to_screen_name": "Abo3es2",
        "user": {
            "id": 362218288,
            "id_str": "362218288",
            "name": "محمد الصويلح",
            "screen_name": "kuwaitycool556",
            "location": "kuwait",
            "url": null,
            "description": "اجمل الاقوال ذوو النفوس الدنيئه ، يجدون اللذة في التفتيش عن اخطاء العظماء",
            "protected": false,
            "followers_count": 227,
            "friends_count": 248,
            "listed_count": 0,
            "created_at": "Fri Aug 26 01:32:10 +0000 2011",
            "favourites_count": 2,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1134,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000265162524/77cd45e13927548166e07261dfdebe04_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000265162524/77cd45e13927548166e07261dfdebe04_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/362218288/1358567690",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "8fd4df820aa3236d",
            "url": "https://api.twitter.com/1.1/geo/id/8fd4df820aa3236d.json",
            "place_type": "city",
            "name": "Rochester",
            "full_name": "Rochester, MN",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -92.552458,
                            43.89171
                        ],
                        [
                            -92.552458,
                            44.094228
                        ],
                        [
                            -92.393772,
                            44.094228
                        ],
                        [
                            -92.393772,
                            43.89171
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Abo3es2",
                    "name": "احمد بوعيسى",
                    "id": 78123983,
                    "id_str": "78123983",
                    "indices": [
                        0,
                        8
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802830540800,
        "id_str": "407240802830540800",
        "text": "い",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 970031984,
            "id_str": "970031984",
            "name": "林 陸",
            "screen_name": "riku065",
            "location": "神奈川県横浜市",
            "url": null,
            "description": "長良高／日本体育大学 体育学科／アルティメット＃53",
            "protected": false,
            "followers_count": 130,
            "friends_count": 140,
            "listed_count": 0,
            "created_at": "Sun Nov 25 13:22:06 +0000 2012",
            "favourites_count": 2,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 434,
            "lang": "ja",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/2894165712/30645bda9d230f64d73ce7f3dd4b16d3_normal.png",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/2894165712/30645bda9d230f64d73ce7f3dd4b16d3_normal.png",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                35.552256,
                139.4909073
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                139.4909073,
                35.552256
            ]
        },
        "place": {
            "id": "bfdffb491d839e84",
            "url": "https://api.twitter.com/1.1/geo/id/bfdffb491d839e84.json",
            "place_type": "city",
            "name": "横浜市青葉区",
            "full_name": "横浜市青葉区, 神奈川県",
            "country_code": "JP",
            "country": "日本",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            139.468047222222,
                            35.5275877777778
                        ],
                        [
                            139.468047222222,
                            35.5928472222222
                        ],
                        [
                            139.567888055556,
                            35.5928472222222
                        ],
                        [
                            139.567888055556,
                            35.5275877777778
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ja"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803208413200,
        "id_str": "407240803208413184",
        "text": "Bon Nw PSG - OL",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 2194431057,
            "id_str": "2194431057",
            "name": "Jp.",
            "screen_name": "95_dmn",
            "location": "Nous en sommes Propriétaires.",
            "url": null,
            "description": "D'où je viens tu connais[···]",
            "protected": false,
            "followers_count": 74,
            "friends_count": 78,
            "listed_count": 0,
            "created_at": "Sun Nov 24 18:17:32 +0000 2013",
            "favourites_count": 20,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 784,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000785660662/e175bfd80271134b3c1b2be856eea035_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000785660662/e175bfd80271134b3c1b2be856eea035_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/2194431057/1385317278",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.996266,
                2.3836466
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                2.3836466,
                48.996266
            ]
        },
        "place": {
            "id": "fb076e4c4c3b6710",
            "url": "https://api.twitter.com/1.1/geo/id/fb076e4c4c3b6710.json",
            "place_type": "city",
            "name": "Sarcelles",
            "full_name": "Sarcelles, Val-d'Oise",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.3630404,
                            48.9712536
                        ],
                        [
                            2.3630404,
                            49.0137704
                        ],
                        [
                            2.4082019,
                            49.0137704
                        ],
                        [
                            2.4082019,
                            48.9712536
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "nl"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803120345100,
        "id_str": "407240803120345088",
        "text": "Need this 3 day week so bad",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1855222284,
            "id_str": "1855222284",
            "name": "Issy ",
            "screen_name": "issycliff96",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 110,
            "friends_count": 233,
            "listed_count": 0,
            "created_at": "Wed Sep 11 19:34:16 +0000 2013",
            "favourites_count": 79,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 151,
            "lang": "en-gb",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000752974284/04ad7deacac09c8326da7f793eaf25e0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000752974284/04ad7deacac09c8326da7f793eaf25e0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1855222284/1385844004",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                53.46219439,
                -2.52512498
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -2.52512498,
                53.46219439
            ]
        },
        "place": {
            "id": "e109e8e1b7f57984",
            "url": "https://api.twitter.com/1.1/geo/id/e109e8e1b7f57984.json",
            "place_type": "city",
            "name": "Warrington",
            "full_name": "Warrington, Warrington",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -2.6977249999999997,
                            53.32233
                        ],
                        [
                            -2.6977249999999997,
                            53.480908
                        ],
                        [
                            -2.425382,
                            53.480908
                        ],
                        [
                            -2.425382,
                            53.32233
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803090972700,
        "id_str": "407240803090972672",
        "text": "Mio mio mio mio mio mio.",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1628572249,
            "id_str": "1628572249",
            "name": "Alejandra Orti",
            "screen_name": "Alejandraortig",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 31,
            "friends_count": 130,
            "listed_count": 0,
            "created_at": "Sun Jul 28 19:10:19 +0000 2013",
            "favourites_count": 1,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 325,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000203987627/759157168fe2489090ed8de638caded8_normal.png",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000203987627/759157168fe2489090ed8de638caded8_normal.png",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                19.2019573,
                -69.4323213
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -69.4323213,
                19.2019573
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803267141600,
        "id_str": "407240803267141632",
        "text": "AhoraLosLeeo",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 567509367,
            "id_str": "567509367",
            "name": "Una Nueva Vida :c",
            "screen_name": "Mafe_Cardenas05",
            "location": "",
            "url": "https://www.facebook.com/mafe.kardenazz",
            "description": "Ya Nada Tiene Sentido :( #25 #23 & #05",
            "protected": false,
            "followers_count": 150,
            "friends_count": 278,
            "listed_count": 0,
            "created_at": "Mon Apr 30 18:12:08 +0000 2012",
            "favourites_count": 238,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3275,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "851978",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000106332944/690caee55a464c45e703bd645d99d39e.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000106332944/690caee55a464c45e703bd645d99d39e.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000808128508/10f95326eb117286debcd593837433eb_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000808128508/10f95326eb117286debcd593837433eb_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/567509367/1384636370",
            "profile_link_color": "146E24",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                4.7999929,
                -75.7409436
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -75.7409436,
                4.7999929
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803204206600,
        "id_str": "407240803204206592",
        "text": "@blindbank @ToraSparkles asså vad snackar du om jag förtrycker inte kvinnor !",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240423057653760,
        "in_reply_to_status_id_str": "407240423057653760",
        "in_reply_to_user_id": 815032298,
        "in_reply_to_user_id_str": "815032298",
        "in_reply_to_screen_name": "blindbank",
        "user": {
            "id": 622925329,
            "id_str": "622925329",
            "name": "EvilDentist",
            "screen_name": "Zuperkukn",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 65,
            "friends_count": 121,
            "listed_count": 0,
            "created_at": "Sat Jun 30 15:54:29 +0000 2012",
            "favourites_count": 2155,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2364,
            "lang": "sv",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000384366877/1a83eda4647d2456948325a43fc54e44_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000384366877/1a83eda4647d2456948325a43fc54e44_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/622925329/1377863798",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                58.75912945,
                17.06770992
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                17.06770992,
                58.75912945
            ]
        },
        "place": {
            "id": "4ca13653c1a41e50",
            "url": "https://api.twitter.com/1.1/geo/id/4ca13653c1a41e50.json",
            "place_type": "city",
            "name": "Nyköping",
            "full_name": "Nyköping, Södermanlands Län",
            "country_code": "SE",
            "country": "Sverige",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            16.268701,
                            58.4265284
                        ],
                        [
                            16.268701,
                            59.0300617
                        ],
                        [
                            17.8291808,
                            59.0300617
                        ],
                        [
                            17.8291808,
                            58.4265284
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "blindbank",
                    "name": "blindbank",
                    "id": 815032298,
                    "id_str": "815032298",
                    "indices": [
                        0,
                        10
                    ]
                },
                {
                    "screen_name": "ToraSparkles",
                    "name": "Tora Sparkles",
                    "id": 274027274,
                    "id_str": "274027274",
                    "indices": [
                        11,
                        24
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "sv"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803250348000,
        "id_str": "407240803250348032",
        "text": "J'achèterais jamais de Porsche :/",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 85884507,
            "id_str": "85884507",
            "name": "NELSTACHE",
            "screen_name": "NelsonisSexy",
            "location": "Los Santos",
            "url": null,
            "description": "Helicopter dick",
            "protected": false,
            "followers_count": 496,
            "friends_count": 164,
            "listed_count": 2,
            "created_at": "Wed Oct 28 18:58:12 +0000 2009",
            "favourites_count": 341,
            "utc_offset": 3600,
            "time_zone": "Paris",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 38419,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/421681038/70528408.gif",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/421681038/70528408.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000810882316/22414b2a9c6b7ebc668e45720cd5d709_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000810882316/22414b2a9c6b7ebc668e45720cd5d709_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/85884507/1370938263",
            "profile_link_color": "000000",
            "profile_sidebar_border_color": "8A888A",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "1F1C1F",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                47.9066487,
                1.89924177
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                1.89924177,
                47.9066487
            ]
        },
        "place": {
            "id": "5eb1eaca93bb4b8e",
            "url": "https://api.twitter.com/1.1/geo/id/5eb1eaca93bb4b8e.json",
            "place_type": "city",
            "name": "Orléans",
            "full_name": "Orléans, Loiret",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            1.8758485999999999,
                            47.8132946
                        ],
                        [
                            1.8758485999999999,
                            47.9335433
                        ],
                        [
                            1.9484739,
                            47.9335433
                        ],
                        [
                            1.9484739,
                            47.8132946
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803195834400,
        "id_str": "407240803195834368",
        "text": "Todo lo necesario para los outfit de esta temporada decembrina!!! ❄️⛄️🎄🎁🎋🎉 (@ Pallium Boutique) http://t.co/XoDRBUpmIe",
        "source": "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 179316726,
            "id_str": "179316726",
            "name": "Ignacio Aldaz",
            "screen_name": "nachoaldaz",
            "location": "zamora michoacan",
            "url": null,
            "description": "arquitecto.....amante de lo bueno.....soy ese lujo q no todos se pueden dar....naci en año bisiesto...#casual me la paso por el mundo",
            "protected": false,
            "followers_count": 140,
            "friends_count": 607,
            "listed_count": 0,
            "created_at": "Tue Aug 17 01:11:06 +0000 2010",
            "favourites_count": 113,
            "utc_offset": -21600,
            "time_zone": "Guadalajara",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2368,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000070106885/dae79bf965fbaab5f1c1301833a3e53b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000070106885/dae79bf965fbaab5f1c1301833a3e53b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/179316726/1372632729",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                19.980765,
                -102.280017
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -102.280017,
                19.980765
            ]
        },
        "place": {
            "id": "ef01edad2f7e5b65",
            "url": "https://api.twitter.com/1.1/geo/id/ef01edad2f7e5b65.json",
            "place_type": "city",
            "name": "Zamora",
            "full_name": "Zamora, Michoacán de Ocampo",
            "country_code": "MX",
            "country": "México",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -102.408768,
                            19.9489651
                        ],
                        [
                            -102.408768,
                            20.1112581
                        ],
                        [
                            -102.120477,
                            20.1112581
                        ],
                        [
                            -102.120477,
                            19.9489651
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/XoDRBUpmIe",
                    "expanded_url": "http://4sq.com/1fWQAzd",
                    "display_url": "4sq.com/1fWQAzd",
                    "indices": [
                        96,
                        118
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803384561660,
        "id_str": "407240803384561664",
        "text": "Man its still so unreal that Paul Walker died yesterday it just shows you that life is precious and can be taken at any moment",
        "source": "<a href=\"http://www.twitter.com\" rel=\"nofollow\">Twitter for Windows Phone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 328655608,
            "id_str": "328655608",
            "name": "Robby Phillips",
            "screen_name": "rob_phillips26",
            "location": "Mckenzie TN",
            "url": null,
            "description": "#BUcats #VFL #KickerPunter #MakeItCount #WinTheDay It ain't about how hard you hit, its about how hard you can get hit and keep moving forward.",
            "protected": false,
            "followers_count": 545,
            "friends_count": 506,
            "listed_count": 0,
            "created_at": "Sun Jul 03 19:48:28 +0000 2011",
            "favourites_count": 2395,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 24225,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/353138467/Lance-Armstrong-livestrong-chalkbot.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/353138467/Lance-Armstrong-livestrong-chalkbot.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000768621001/f574df7fd58a4766703bdbad5ec191e6_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000768621001/f574df7fd58a4766703bdbad5ec191e6_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/328655608/1382534797",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                30.62503,
                -81.46898
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -81.46898,
                30.62503
            ]
        },
        "place": {
            "id": "7142eb97ae21e839",
            "url": "https://api.twitter.com/1.1/geo/id/7142eb97ae21e839.json",
            "place_type": "admin",
            "name": "Georgia",
            "full_name": "Georgia, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -85.605165,
                            30.355756999999997
                        ],
                        [
                            -85.605165,
                            35.000659
                        ],
                        [
                            -80.751429,
                            35.000659
                        ],
                        [
                            -80.751429,
                            30.355756999999997
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803166064640,
        "id_str": "407240803166064640",
        "text": "@zachLAbonte yeah I made a big mistake. #kickinmyself",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240594193268740,
        "in_reply_to_status_id_str": "407240594193268736",
        "in_reply_to_user_id": 454598731,
        "in_reply_to_user_id_str": "454598731",
        "in_reply_to_screen_name": "zachLAbonte",
        "user": {
            "id": 272170242,
            "id_str": "272170242",
            "name": "Alex Harrison",
            "screen_name": "alexharrison21",
            "location": "illinois",
            "url": null,
            "description": "THE Iowa State University",
            "protected": false,
            "followers_count": 396,
            "friends_count": 391,
            "listed_count": 1,
            "created_at": "Sat Mar 26 00:00:38 +0000 2011",
            "favourites_count": 2629,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 6679,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000505836439/92fdf1c0d53f134edeffe725a8d5befe_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000505836439/92fdf1c0d53f134edeffe725a8d5befe_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/272170242/1359482885",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.32367402,
                -89.30049725
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -89.30049725,
                41.32367402
            ]
        },
        "place": {
            "id": "07e11f634dba027f",
            "url": "https://api.twitter.com/1.1/geo/id/07e11f634dba027f.json",
            "place_type": "city",
            "name": "De Pue",
            "full_name": "De Pue, IL",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -89.32573,
                            41.309505
                        ],
                        [
                            -89.32573,
                            41.341285
                        ],
                        [
                            -89.267627,
                            41.341285
                        ],
                        [
                            -89.267627,
                            41.309505
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "kickinmyself",
                    "indices": [
                        40,
                        53
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "zachLAbonte",
                    "name": "Luh-Bon-T",
                    "id": 454598731,
                    "id_str": "454598731",
                    "indices": [
                        0,
                        12
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802998300700,
        "id_str": "407240802998300673",
        "text": "“@xDrasiLatryce_: the one thing that erks my nerves is when people tell me im tall . like duh dont you think i would know that ?”",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407239924866236400,
        "in_reply_to_status_id_str": "407239924866236416",
        "in_reply_to_user_id": 348146511,
        "in_reply_to_user_id_str": "348146511",
        "in_reply_to_screen_name": "xDrasiLatryce_",
        "user": {
            "id": 312781325,
            "id_str": "312781325",
            "name": "kaee.",
            "screen_name": "xo_kaee",
            "location": "",
            "url": null,
            "description": "instagram: @xo_kaee ✌️",
            "protected": false,
            "followers_count": 503,
            "friends_count": 216,
            "listed_count": 0,
            "created_at": "Tue Jun 07 17:15:20 +0000 2011",
            "favourites_count": 614,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10501,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/601072086/tuwj659lb5jf2102mzmm.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/601072086/tuwj659lb5jf2102mzmm.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000798049214/f00198ef487f367bf6a69b26dd89e54b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000798049214/f00198ef487f367bf6a69b26dd89e54b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/312781325/1384366668",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                30.13602567,
                -94.1868748
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -94.1868748,
                30.13602567
            ]
        },
        "place": {
            "id": "33d5cf4dea5828c5",
            "url": "https://api.twitter.com/1.1/geo/id/33d5cf4dea5828c5.json",
            "place_type": "city",
            "name": "Beaumont",
            "full_name": "Beaumont, TX",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -94.225236,
                            29.973175
                        ],
                        [
                            -94.225236,
                            30.189106
                        ],
                        [
                            -94.032893,
                            30.189106
                        ],
                        [
                            -94.032893,
                            29.973175
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "xDrasiLatryce_",
                    "name": "DRASIIIII",
                    "id": 348146511,
                    "id_str": "348146511",
                    "indices": [
                        1,
                        16
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803258347500,
        "id_str": "407240803258347520",
        "text": "@ludovic_dore Tu a quand même passer une année ou plus à ses côtés ou tu as été heureux",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240529551052800,
        "in_reply_to_status_id_str": "407240529551052800",
        "in_reply_to_user_id": 1412779298,
        "in_reply_to_user_id_str": "1412779298",
        "in_reply_to_screen_name": "ludovic_dore",
        "user": {
            "id": 1050674250,
            "id_str": "1050674250",
            "name": "Julie C mon amour",
            "screen_name": "DuneRobin",
            "location": "",
            "url": null,
            "description": "XXVII.XI.MMX-XX.IV.MMXIII\r\n\r\nII.VII.MMXI-XVIII.IX.MMXIII",
            "protected": false,
            "followers_count": 86,
            "friends_count": 82,
            "listed_count": 0,
            "created_at": "Mon Dec 31 16:24:28 +0000 2012",
            "favourites_count": 505,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9385,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000057321062/103003b392bdc08e90a174955b6c49df.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000057321062/103003b392bdc08e90a174955b6c49df.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000761155752/da4b7961be3f5f2ba156cd9642a0febf_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000761155752/da4b7961be3f5f2ba156cd9642a0febf_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1050674250/1385063824",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "31cb9e7ed29dbe52",
            "url": "https://api.twitter.com/1.1/geo/id/31cb9e7ed29dbe52.json",
            "place_type": "city",
            "name": "Carcassonne",
            "full_name": "Carcassonne, Aude",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.2622287,
                            43.1712777
                        ],
                        [
                            2.2622287,
                            43.2442277
                        ],
                        [
                            2.4346162,
                            43.2442277
                        ],
                        [
                            2.4346162,
                            43.1712777
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "ludovic_dore",
                    "name": "Pogba ❤",
                    "id": 1412779298,
                    "id_str": "1412779298",
                    "indices": [
                        0,
                        13
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803166478340,
        "id_str": "407240803166478336",
        "text": "I would never wanna repeat school lol",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 163357144,
            "id_str": "163357144",
            "name": "✈J'Almigh✈️",
            "screen_name": "Foolie_Boy",
            "location": "Lewisville ✈️ Tyler",
            "url": "http://m.youtube.com/user/MrJayman85?feature=guide",
            "description": "One good girl is worth a thousand bitches. Ig:LilLos95 #TeamMixedGirls #TeamLastLaugh. #TJC15",
            "protected": false,
            "followers_count": 504,
            "friends_count": 317,
            "listed_count": 0,
            "created_at": "Tue Jul 06 05:53:31 +0000 2010",
            "favourites_count": 7231,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 33864,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/456710382/imagesCASUTVLV.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/456710382/imagesCASUTVLV.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000737846005/362c4c3b11c90277d065bacde2b15b02_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000737846005/362c4c3b11c90277d065bacde2b15b02_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/163357144/1384229096",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                32.31668567,
                -95.24240694
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -95.24240694,
                32.31668567
            ]
        },
        "place": {
            "id": "9d4c71b7937a3a90",
            "url": "https://api.twitter.com/1.1/geo/id/9d4c71b7937a3a90.json",
            "place_type": "city",
            "name": "Tyler",
            "full_name": "Tyler, TX",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -95.373393,
                            32.239077
                        ],
                        [
                            -95.373393,
                            32.430928
                        ],
                        [
                            -95.193307,
                            32.430928
                        ],
                        [
                            -95.193307,
                            32.239077
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802843123700,
        "id_str": "407240802843123712",
        "text": "@TiffanyMay7 😠😠😠",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407234359389741060,
        "in_reply_to_status_id_str": "407234359389741056",
        "in_reply_to_user_id": 485273221,
        "in_reply_to_user_id_str": "485273221",
        "in_reply_to_screen_name": "TiffanyMay7",
        "user": {
            "id": 702023154,
            "id_str": "702023154",
            "name": "Jason Martinez",
            "screen_name": "JasonMartinez_1",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 188,
            "friends_count": 235,
            "listed_count": 0,
            "created_at": "Wed Jul 18 00:10:20 +0000 2012",
            "favourites_count": 1054,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5915,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000397967936/b030bb981108cf65ff7fa66a1b82e513_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000397967936/b030bb981108cf65ff7fa66a1b82e513_normal.jpeg",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                64.80823484,
                -147.41033502
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -147.41033502,
                64.80823484
            ]
        },
        "place": {
            "id": "39c068a203ddd5e1",
            "url": "https://api.twitter.com/1.1/geo/id/39c068a203ddd5e1.json",
            "place_type": "city",
            "name": "Fairbanks North Star",
            "full_name": "Fairbanks North Star, AK",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -148.667164,
                            64.257854
                        ],
                        [
                            -148.667164,
                            65.454475
                        ],
                        [
                            -143.884795,
                            65.454475
                        ],
                        [
                            -143.884795,
                            64.257854
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "TiffanyMay7",
                    "name": "Tiff",
                    "id": 485273221,
                    "id_str": "485273221",
                    "indices": [
                        0,
                        12
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "und"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803392962560,
        "id_str": "407240803392962560",
        "text": "“@_tiffnasty: My side nigga my main nigga cause my main nigga ain't feeling me no mo.”",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240434029973500,
        "in_reply_to_status_id_str": "407240434029973504",
        "in_reply_to_user_id": 28248615,
        "in_reply_to_user_id_str": "28248615",
        "in_reply_to_screen_name": "_tiffnasty",
        "user": {
            "id": 441235303,
            "id_str": "441235303",
            "name": "Kelly Soprano",
            "screen_name": "SopranoNYCest",
            "location": "ig: sopranonyc",
            "url": "http://soundcloud.com/kellysoprano",
            "description": "Queens get the motherfuckin money. $",
            "protected": false,
            "followers_count": 987,
            "friends_count": 646,
            "listed_count": 10,
            "created_at": "Mon Dec 19 21:53:09 +0000 2011",
            "favourites_count": 454,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 19386,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/842836306/21ff367e539165384f654ee23e8827dc.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/842836306/21ff367e539165384f654ee23e8827dc.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000808661159/0d1ad10cbc9ab58b3e9dd6fadcd2fe97_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000808661159/0d1ad10cbc9ab58b3e9dd6fadcd2fe97_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/441235303/1385823294",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.70299829,
                -73.73094385
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -73.73094385,
                40.70299829
            ]
        },
        "place": {
            "id": "b6ea2e341ba4356f",
            "url": "https://api.twitter.com/1.1/geo/id/b6ea2e341ba4356f.json",
            "place_type": "city",
            "name": "Queens",
            "full_name": "Queens, NY",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -74.042112,
                            40.489794
                        ],
                        [
                            -74.042112,
                            40.812242
                        ],
                        [
                            -73.700272,
                            40.812242
                        ],
                        [
                            -73.700272,
                            40.489794
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "_tiffnasty",
                    "name": "tiffαny",
                    "id": 28248615,
                    "id_str": "28248615",
                    "indices": [
                        1,
                        12
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803556536300,
        "id_str": "407240803556536320",
        "text": "Joey francis tribbiani",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 66198446,
            "id_str": "66198446",
            "name": "Joe Trivni ♌",
            "screen_name": "trivni87",
            "location": "tkd :)",
            "url": null,
            "description": "chiller en taekwondo #blackbelt #tkdchamp #letrivs #deejay #christianboy #loveG*d #loveyouus #summer2o13love",
            "protected": false,
            "followers_count": 238,
            "friends_count": 1058,
            "listed_count": 0,
            "created_at": "Sun Aug 16 21:34:31 +0000 2009",
            "favourites_count": 495,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8297,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "EBAAAA",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000006390635/4d5dbd3e83820a8a38fd8ac2d0449804.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000006390635/4d5dbd3e83820a8a38fd8ac2d0449804.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000037698535/b5e2c685e6d64e865a98ea258d09bec8_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000037698535/b5e2c685e6d64e865a98ea258d09bec8_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/66198446/1372050121",
            "profile_link_color": "EBAAAA",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "D9FFDC",
            "profile_text_color": "11751A",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                45.46763694,
                -73.63717619
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -73.63717619,
                45.46763694
            ]
        },
        "place": {
            "id": "378a442883b05c3c",
            "url": "https://api.twitter.com/1.1/geo/id/378a442883b05c3c.json",
            "place_type": "city",
            "name": "Montréal",
            "full_name": "Montréal, Québec",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -73.99865199999999,
                            45.398467
                        ],
                        [
                            -73.99865199999999,
                            45.705566
                        ],
                        [
                            -73.473085,
                            45.705566
                        ],
                        [
                            -73.473085,
                            45.398467
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803376189440,
        "id_str": "407240803376189441",
        "text": "#NavidadMonterrey @ Centro Comercial Monterrey http://t.co/DfQjlxsnC8",
        "source": "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 168386710,
            "id_str": "168386710",
            "name": "JUAN PABLO GOMEZ GIL",
            "screen_name": "jgomegi",
            "location": "Medellín",
            "url": null,
            "description": "Estudiante de Sistemas de Información, Auxiliar de tecnología. Coordinador de #UnaSemanaParaTIC. Enamorado por la ciencia y la tecnología.",
            "protected": false,
            "followers_count": 179,
            "friends_count": 372,
            "listed_count": 0,
            "created_at": "Mon Jul 19 05:35:00 +0000 2010",
            "favourites_count": 132,
            "utc_offset": -18000,
            "time_zone": "Bogota",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2225,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000277801254/f9f272e411f14df56c8fcee17076dcac_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000277801254/f9f272e411f14df56c8fcee17076dcac_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/168386710/1384219296",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                6.21422856,
                -75.57673216
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -75.57673216,
                6.21422856
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "NavidadMonterrey",
                    "indices": [
                        0,
                        17
                    ]
                }
            ],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/DfQjlxsnC8",
                    "expanded_url": "http://instagram.com/p/hZFiTnQ4_F/",
                    "display_url": "instagram.com/p/hZFiTnQ4_F/",
                    "indices": [
                        47,
                        69
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803228999700,
        "id_str": "407240803228999681",
        "text": "@AndresG__20 hmu",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240404887543800,
        "in_reply_to_status_id_str": "407240404887543808",
        "in_reply_to_user_id": 480922327,
        "in_reply_to_user_id_str": "480922327",
        "in_reply_to_screen_name": "AndresG__20",
        "user": {
            "id": 172036685,
            "id_str": "172036685",
            "name": "Felipe Velazco",
            "screen_name": "velazco_felipe",
            "location": "Where The Wild Things Are",
            "url": null,
            "description": "God is mercy.",
            "protected": false,
            "followers_count": 270,
            "friends_count": 159,
            "listed_count": 1,
            "created_at": "Wed Jul 28 19:26:51 +0000 2010",
            "favourites_count": 771,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4695,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "07090B",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/291285111/twitter_design_smaller.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/291285111/twitter_design_smaller.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000800756153/bd0de6bab0e3b84c0e6b205bafbacbe8_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000800756153/bd0de6bab0e3b84c0e6b205bafbacbe8_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/172036685/1384839636",
            "profile_link_color": "C34242",
            "profile_sidebar_border_color": "BFBFBF",
            "profile_sidebar_fill_color": "C9C9C9",
            "profile_text_color": "1C1F23",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                33.4134357,
                -111.8080591
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -111.8080591,
                33.4134357
            ]
        },
        "place": {
            "id": "44d207663001f00b",
            "url": "https://api.twitter.com/1.1/geo/id/44d207663001f00b.json",
            "place_type": "city",
            "name": "Mesa",
            "full_name": "Mesa, AZ",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -111.894881,
                            33.277624
                        ],
                        [
                            -111.894881,
                            33.513376
                        ],
                        [
                            -111.580636,
                            33.513376
                        ],
                        [
                            -111.580636,
                            33.277624
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "AndresG__20",
                    "name": "Andres Gurrola",
                    "id": 480922327,
                    "id_str": "480922327",
                    "indices": [
                        0,
                        12
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "und"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803518787600,
        "id_str": "407240803518787584",
        "text": "You were.",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 370481992,
            "id_str": "370481992",
            "name": "BEYONCE .",
            "screen_name": "cardoso_anthony",
            "location": "",
            "url": null,
            "description": "Waukegan/ Wrestling/ 18 years old/ Born on april 29, 1995/",
            "protected": false,
            "followers_count": 342,
            "friends_count": 322,
            "listed_count": 0,
            "created_at": "Fri Sep 09 03:05:20 +0000 2011",
            "favourites_count": 378,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7980,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "2FE1B3",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/472340787/x424f2036775d2673c9cf6624565cf23.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/472340787/x424f2036775d2673c9cf6624565cf23.jpg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000588365895/1ded6be57d77027ebed0114dfd36b2fe_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000588365895/1ded6be57d77027ebed0114dfd36b2fe_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/370481992/1385777986",
            "profile_link_color": "E57640",
            "profile_sidebar_border_color": "ECDFEB",
            "profile_sidebar_fill_color": "E054D1",
            "profile_text_color": "AD7BA8",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                42.36306631,
                -87.85263187
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -87.85263187,
                42.36306631
            ]
        },
        "place": {
            "id": "b819c5d90b780b57",
            "url": "https://api.twitter.com/1.1/geo/id/b819c5d90b780b57.json",
            "place_type": "city",
            "name": "Waukegan",
            "full_name": "Waukegan, IL",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -87.964419,
                            42.309377
                        ],
                        [
                            -87.964419,
                            42.432657
                        ],
                        [
                            -87.804207,
                            42.432657
                        ],
                        [
                            -87.804207,
                            42.309377
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803249967100,
        "id_str": "407240803249967104",
        "text": "So many beautiful women on interstate 45 today. #cabcreepin \nBe ready for it @Brazos_Elkins",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 517948311,
            "id_str": "517948311",
            "name": "Derek Durant",
            "screen_name": "derek_durant2",
            "location": "College Station/Forney, Tx",
            "url": null,
            "description": "Sophomore Engineering Major at TAMU that prefers showers to a 4.0 | You miss 100% of the shots you don't take-Wayne Gretzky -Michael Scott | Matt.23:12",
            "protected": false,
            "followers_count": 376,
            "friends_count": 258,
            "listed_count": 1,
            "created_at": "Wed Mar 07 21:21:51 +0000 2012",
            "favourites_count": 2127,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2793,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "352726",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme5/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme5/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000732067983/ebe6b2b43e131906e5907fc3752d7ad0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000732067983/ebe6b2b43e131906e5907fc3752d7ad0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/517948311/1384291221",
            "profile_link_color": "D02B55",
            "profile_sidebar_border_color": "829D5E",
            "profile_sidebar_fill_color": "99CC33",
            "profile_text_color": "3E4415",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                32.3979482,
                -96.65606587
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -96.65606587,
                32.3979482
            ]
        },
        "place": {
            "id": "e0060cda70f5f341",
            "url": "https://api.twitter.com/1.1/geo/id/e0060cda70f5f341.json",
            "place_type": "admin",
            "name": "Texas",
            "full_name": "Texas, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -106.645646,
                            25.837163999999998
                        ],
                        [
                            -106.645646,
                            36.500704
                        ],
                        [
                            -93.508039,
                            36.500704
                        ],
                        [
                            -93.508039,
                            25.837163999999998
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "cabcreepin",
                    "indices": [
                        48,
                        59
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Brazos_Elkins",
                    "name": "Brazos",
                    "id": 29452901,
                    "id_str": "29452901",
                    "indices": [
                        77,
                        91
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803321278460,
        "id_str": "407240803321278464",
        "text": "hj é dia de montar árvore de natal",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 212914044,
            "id_str": "212914044",
            "name": "Guilherme",
            "screen_name": "guilhermedc14",
            "location": "Uberlândia-MG",
            "url": null,
            "description": "Verifique a classificação indicativa.",
            "protected": false,
            "followers_count": 263,
            "friends_count": 725,
            "listed_count": 33,
            "created_at": "Sun Nov 07 12:32:50 +0000 2010",
            "favourites_count": 51,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10725,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0C0C0D",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000089620189/eab29ac645304dc473a20f77321f6753.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000089620189/eab29ac645304dc473a20f77321f6753.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000743569267/8083012c529132c0935ebb99887984f9_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000743569267/8083012c529132c0935ebb99887984f9_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/212914044/1384534374",
            "profile_link_color": "08C999",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "050505",
            "profile_text_color": "1923E3",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "4ebe32c7ad1032ae",
            "url": "https://api.twitter.com/1.1/geo/id/4ebe32c7ad1032ae.json",
            "place_type": "city",
            "name": "Uberlândia",
            "full_name": "Uberlândia, Minas Gerais",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -48.8228587,
                            -19.4163493
                        ],
                        [
                            -48.8228587,
                            -18.5924338
                        ],
                        [
                            -47.894203999999995,
                            -18.5924338
                        ],
                        [
                            -47.894203999999995,
                            -19.4163493
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803463876600,
        "id_str": "407240803463876608",
        "text": "Hard water mineral build-up takes time to build-up - you do not need to use a product for that alone every time unless you want to do so.",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 542792728,
            "id_str": "542792728",
            "name": "ktani ",
            "screen_name": "ktanimara",
            "location": "Canada",
            "url": "http://ktanihairsense.blogspot.ca/",
            "description": "I specialize in finding reputable, current research to empower all kinds of business needs. Licensed Paralegal. Bully-Free Social Media Now!",
            "protected": false,
            "followers_count": 1297,
            "friends_count": 1754,
            "listed_count": 18,
            "created_at": "Sun Apr 01 19:26:12 +0000 2012",
            "favourites_count": 3939,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14270,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/3725599635/230ab4cc947cd5e605131dab274a17bb_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/3725599635/230ab4cc947cd5e605131dab274a17bb_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/542792728/1369794637",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "8f9664a8ccd89e5c",
            "url": "https://api.twitter.com/1.1/geo/id/8f9664a8ccd89e5c.json",
            "place_type": "city",
            "name": "Toronto",
            "full_name": "Toronto, Ontario",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -79.63918699999999,
                            43.403220999999995
                        ],
                        [
                            -79.63918699999999,
                            43.855466
                        ],
                        [
                            -78.90581999999999,
                            43.855466
                        ],
                        [
                            -78.90581999999999,
                            43.403220999999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803619463200,
        "id_str": "407240803619463168",
        "text": "Je croi pas sa mm",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1373514374,
            "id_str": "1373514374",
            "name": "#$.K.M×!!",
            "screen_name": "SSilsix",
            "location": "#Mare-galliard #Bløck 44.",
            "url": null,
            "description": "#teamBien,PaS JouEr èVè DiFé mm!!!#team Football.#teamPSG #Follow me et je te #Follow back*__*.C pas Parceque Tù Joue que Le Jeù S'arrèTe!! #teamCLR.!!!:')",
            "protected": false,
            "followers_count": 113,
            "friends_count": 328,
            "listed_count": 0,
            "created_at": "Tue Apr 23 01:30:01 +0000 2013",
            "favourites_count": 17,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 11787,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000073634577/8e0e00e3bd6c296e42f3e2e00e5a5591.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000073634577/8e0e00e3bd6c296e42f3e2e00e5a5591.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000590601039/6593a41e796af4e152a875b9dfd62833_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000590601039/6593a41e796af4e152a875b9dfd62833_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1373514374/1377523627",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                16.2161161,
                -61.4367873
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -61.4367873,
                16.2161161
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240802784776200,
        "id_str": "407240802784776192",
        "text": "@Learr_ http://t.co/J1ey10huNk",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407239928050114560,
        "in_reply_to_status_id_str": "407239928050114561",
        "in_reply_to_user_id": 338722139,
        "in_reply_to_user_id_str": "338722139",
        "in_reply_to_screen_name": "Learr_",
        "user": {
            "id": 237338088,
            "id_str": "237338088",
            "name": "K Δ L I✈",
            "screen_name": "BoyceAvenue__",
            "location": "In the endzone, celebrating",
            "url": "http://www.hudl.com/athlete/114956/kali-boyce",
            "description": "Albright 17'",
            "protected": false,
            "followers_count": 684,
            "friends_count": 212,
            "listed_count": 1,
            "created_at": "Wed Jan 12 16:27:54 +0000 2011",
            "favourites_count": 2716,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 28509,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "080808",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/538107902/jungle_fever_logo-bold-01.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/538107902/jungle_fever_logo-bold-01.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000745712213/c95ddcb8770275b2ddd8f6893ca0d383_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000745712213/c95ddcb8770275b2ddd8f6893ca0d383_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/237338088/1372605564",
            "profile_link_color": "060469",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "7A0A13",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.71265051,
                -75.03169262
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -75.03169262,
                39.71265051
            ]
        },
        "place": {
            "id": "497bea73b899e639",
            "url": "https://api.twitter.com/1.1/geo/id/497bea73b899e639.json",
            "place_type": "city",
            "name": "Monroe",
            "full_name": "Monroe, NJ",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -75.091687,
                            39.57862
                        ],
                        [
                            -75.091687,
                            39.726408
                        ],
                        [
                            -74.877189,
                            39.726408
                        ],
                        [
                            -74.877189,
                            39.57862
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Learr_",
                    "name": "Chris",
                    "id": 338722139,
                    "id_str": "338722139",
                    "indices": [
                        0,
                        7
                    ]
                }
            ],
            "media": [
                {
                    "id": 407240802612817900,
                    "id_str": "407240802612817920",
                    "indices": [
                        8,
                        30
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWjHIMAA_JkY.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWjHIMAA_JkY.jpg",
                    "url": "http://t.co/J1ey10huNk",
                    "display_url": "pic.twitter.com/J1ey10huNk",
                    "expanded_url": "http://twitter.com/BoyceAvenue__/status/407240802784776192/photo/1",
                    "type": "photo",
                    "sizes": {
                        "large": {
                            "w": 946,
                            "h": 960,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "medium": {
                            "w": 599,
                            "h": 608,
                            "resize": "fit"
                        },
                        "small": {
                            "w": 340,
                            "h": 345,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "und"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803375779840,
        "id_str": "407240803375779840",
        "text": "@BigPapaMunoz67 it's my favorite thing in the world! They light them all over campus for one night and have sleigh rides and carolers 😍😍😍😍",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240441818411000,
        "in_reply_to_status_id_str": "407240441818411008",
        "in_reply_to_user_id": 2148268218,
        "in_reply_to_user_id_str": "2148268218",
        "in_reply_to_screen_name": "BigPapaMunoz67",
        "user": {
            "id": 1112818188,
            "id_str": "1112818188",
            "name": "Sallie Elizabeth",
            "screen_name": "MissSallie11",
            "location": "Las Cruces, NM",
            "url": null,
            "description": "There are few things in life that a cup of tea and a hand to hold can't fix (: ΠΒΦ❤",
            "protected": false,
            "followers_count": 86,
            "friends_count": 107,
            "listed_count": 0,
            "created_at": "Tue Jan 22 22:45:39 +0000 2013",
            "favourites_count": 436,
            "utc_offset": -25200,
            "time_zone": "Mountain Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 966,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "ACDED6",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme18/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme18/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000806756859/8e0b322fc4bbb15621e7f9b77774176b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000806756859/8e0b322fc4bbb15621e7f9b77774176b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1112818188/1381631431",
            "profile_link_color": "038543",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "F6F6F6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                32.2695855,
                -106.76295935
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -106.76295935,
                32.2695855
            ]
        },
        "place": {
            "id": "71d65c0e6d94efab",
            "url": "https://api.twitter.com/1.1/geo/id/71d65c0e6d94efab.json",
            "place_type": "admin",
            "name": "New Mexico",
            "full_name": "New Mexico, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -109.050173,
                            31.332172
                        ],
                        [
                            -109.050173,
                            37.000293
                        ],
                        [
                            -103.001964,
                            37.000293
                        ],
                        [
                            -103.001964,
                            31.332172
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "BigPapaMunoz67",
                    "name": "Lea Munoz",
                    "id": 2148268218,
                    "id_str": "2148268218",
                    "indices": [
                        0,
                        15
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803497435140,
        "id_str": "407240803497435136",
        "text": "HOME SWEET HOME❤️",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 98496359,
            "id_str": "98496359",
            "name": "gaby milone",
            "screen_name": "g_babyy13",
            "location": "IL",
            "url": "http://babyyg13.tumblr.com/",
            "description": "Get to know me♡",
            "protected": false,
            "followers_count": 262,
            "friends_count": 300,
            "listed_count": 0,
            "created_at": "Mon Dec 21 23:28:23 +0000 2009",
            "favourites_count": 9048,
            "utc_offset": -25200,
            "time_zone": "Mountain Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 6600,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/447580344/white_wooden_planks.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/447580344/white_wooden_planks.png",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000794228386/a56cd90af62c8ecd806980bc7f13671b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000794228386/a56cd90af62c8ecd806980bc7f13671b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/98496359/1385924442",
            "profile_link_color": "000000",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "000000",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                42.04878274,
                -88.32969765
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -88.32969765,
                42.04878274
            ]
        },
        "place": {
            "id": "a7a453f75eea792e",
            "url": "https://api.twitter.com/1.1/geo/id/a7a453f75eea792e.json",
            "place_type": "city",
            "name": "Elgin",
            "full_name": "Elgin, IL",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -88.355855,
                            41.986626
                        ],
                        [
                            -88.355855,
                            42.103385
                        ],
                        [
                            -88.222773,
                            42.103385
                        ],
                        [
                            -88.222773,
                            41.986626
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803619459100,
        "id_str": "407240803619459072",
        "text": "Maintenant n'empêche quand y'aura des diffusions de Fast&amp;Furious a la télé on les regardera plus jamais comme avant...",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 394205747,
            "id_str": "394205747",
            "name": "ثةةغ ♡",
            "screen_name": "EmmyBkr",
            "location": "",
            "url": null,
            "description": "ಌ Follow back. ; #TeamGuizmo ♡ | #TeamPetiteTaille ✿ | #teamkaaris #welcometothejunglebitch ♔ #TeamHayce PIN BBM : 7BAC0EF6 ❤️",
            "protected": false,
            "followers_count": 833,
            "friends_count": 1998,
            "listed_count": 15,
            "created_at": "Wed Oct 19 18:43:02 +0000 2011",
            "favourites_count": 84,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 6107,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "66FFF7",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000015560514/71a80dc35798e43bfd55ce7a751c15ae.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000015560514/71a80dc35798e43bfd55ce7a751c15ae.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000811706671/6290be6056f9a8d62257e0ae6493cd0c_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000811706671/6290be6056f9a8d62257e0ae6493cd0c_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/394205747/1385834898",
            "profile_link_color": "890DB3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.81134204,
                2.28203698
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                2.28203698,
                48.81134204
            ]
        },
        "place": {
            "id": "5954fe3bf3a61904",
            "url": "https://api.twitter.com/1.1/geo/id/5954fe3bf3a61904.json",
            "place_type": "city",
            "name": "Malakoff",
            "full_name": "Malakoff, Hauts-de-Seine",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.2744997,
                            48.8088789
                        ],
                        [
                            2.2744997,
                            48.8252117
                        ],
                        [
                            2.3143083,
                            48.8252117
                        ],
                        [
                            2.3143083,
                            48.8088789
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803644616700,
        "id_str": "407240803644616704",
        "text": "يجي عطرك ،  و أحس القلب يترمم.......  و أنا من مر عطرك فوق كفـي؟  كرهت المآء ، ولحد إلحين أتيمم.\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1276889982,
            "id_str": "1276889982",
            "name": "سجى الليل ",
            "screen_name": "Koon10666",
            "location": "",
            "url": null,
            "description": "‏يّـاللهَ تّـغًنينيَ بّفضَلك عنً النّاس وَعنَ حّاجةَ الليَ لّا بغّيتهَ خذًلَنيّ!!)( شمريه طبعا ) الخاص ممنوع)",
            "protected": false,
            "followers_count": 678,
            "friends_count": 811,
            "listed_count": 0,
            "created_at": "Mon Mar 18 05:55:01 +0000 2013",
            "favourites_count": 871,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9050,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000785153260/072cc545c78f3a7de82a70f8d63de2ab_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000785153260/072cc545c78f3a7de82a70f8d63de2ab_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1276889982/1385317108",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                31.3362749,
                37.3389027
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                37.3389027,
                31.3362749
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803464257540,
        "id_str": "407240803464257537",
        "text": "@HectorMON_ pero Corujo ko es no Carajo vovo jajaa",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240683955945500,
        "in_reply_to_status_id_str": "407240683955945473",
        "in_reply_to_user_id": 170766953,
        "in_reply_to_user_id_str": "170766953",
        "in_reply_to_screen_name": "HectorMON_",
        "user": {
            "id": 317485763,
            "id_str": "317485763",
            "name": "DANI SERNA",
            "screen_name": "Serna_Carlos",
            "location": "San lorenzo-Paraguay ",
            "url": null,
            "description": "Cronista de la 680 AM Radio Caritas PUNTO PENAL Coberturas del Club OLIMPIA",
            "protected": false,
            "followers_count": 909,
            "friends_count": 573,
            "listed_count": 4,
            "created_at": "Wed Jun 15 00:47:08 +0000 2011",
            "favourites_count": 33,
            "utc_offset": -36000,
            "time_zone": "Hawaii",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 11959,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000749459550/025fc21b265089a6bd2015ceb6c28087_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000749459550/025fc21b265089a6bd2015ceb6c28087_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/317485763/1384644327",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -25.2754251,
                -57.4776209
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -57.4776209,
                -25.2754251
            ]
        },
        "place": {
            "id": "1b107df3ccc0aaa1",
            "url": "https://api.twitter.com/1.1/geo/id/1b107df3ccc0aaa1.json",
            "place_type": "country",
            "name": "Brasil",
            "full_name": "Brasil",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -73.99148199999999,
                            -33.750575999999995
                        ],
                        [
                            -73.99148199999999,
                            5.27192
                        ],
                        [
                            -32.378186,
                            5.27192
                        ],
                        [
                            -32.378186,
                            -33.750575999999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "HectorMON_",
                    "name": "Hector MON",
                    "id": 170766953,
                    "id_str": "170766953",
                    "indices": [
                        0,
                        11
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803673972740,
        "id_str": "407240803673972737",
        "text": "Sevmek yetmiyomus sevilmeye..",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 167463257,
            "id_str": "167463257",
            "name": "Melih Güngör",
            "screen_name": "gngrmlh",
            "location": "STANDAR(T-A-Y-A-H)▲ ANKARA",
            "url": "http://facebook.com/JuardiaN",
            "description": "KKU / http://instagram.com/gngrmlh",
            "protected": false,
            "followers_count": 489,
            "friends_count": 461,
            "listed_count": 0,
            "created_at": "Fri Jul 16 17:15:04 +0000 2010",
            "favourites_count": 817,
            "utc_offset": 7200,
            "time_zone": "Istanbul",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5196,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000083671556/b054dfe28fd7acb2c16f7f6500343501.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000083671556/b054dfe28fd7acb2c16f7f6500343501.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000311983311/e7a9c5a3743e3b3bacf6ff23e6e284ea_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000311983311/e7a9c5a3743e3b3bacf6ff23e6e284ea_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/167463257/1379806569",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.8439786,
                33.4973083
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                33.4973083,
                39.8439786
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803564933100,
        "id_str": "407240803564933120",
        "text": "И ничто \nВообще все тлен \nЯ тлен",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1063319364,
            "id_str": "1063319364",
            "name": "stupid ",
            "screen_name": "likalovem",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 37,
            "friends_count": 45,
            "listed_count": 0,
            "created_at": "Sat Jan 05 16:02:12 +0000 2013",
            "favourites_count": 24,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4483,
            "lang": "ru",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000483292641/ba4a122f5961e2c8e675b5ccc656af90_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000483292641/ba4a122f5961e2c8e675b5ccc656af90_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1063319364/1379706359",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                43.91757557,
                39.33033728
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                39.33033728,
                43.91757557
            ]
        },
        "place": {
            "id": "aa622fd05cbbb49b",
            "url": "https://api.twitter.com/1.1/geo/id/aa622fd05cbbb49b.json",
            "place_type": "city",
            "name": "Лазаревское",
            "full_name": "Лазаревское, Сочи",
            "country_code": "RU",
            "country": "Россия",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            39.1481902,
                            43.632503
                        ],
                        [
                            39.1481902,
                            44.127558
                        ],
                        [
                            39.849728,
                            44.127558
                        ],
                        [
                            39.849728,
                            43.632503
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ru"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803548168200,
        "id_str": "407240803548168192",
        "text": "@_dannifr @Danarauber awwwn .... Então vai la p Dana hj, daí nos bebemos u.u",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240412756070400,
        "in_reply_to_status_id_str": "407240412756070400",
        "in_reply_to_user_id": 175623947,
        "in_reply_to_user_id_str": "175623947",
        "in_reply_to_screen_name": "_dannifr",
        "user": {
            "id": 347934366,
            "id_str": "347934366",
            "name": "Vika",
            "screen_name": "ViihBarbosaaa",
            "location": "Santa Cruz do Sul, RS",
            "url": null,
            "description": "♥",
            "protected": false,
            "followers_count": 586,
            "friends_count": 426,
            "listed_count": 0,
            "created_at": "Wed Aug 03 16:14:48 +0000 2011",
            "favourites_count": 625,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14333,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/754991206/364fba3aca1ecf253d4529c8d6f413af.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/754991206/364fba3aca1ecf253d4529c8d6f413af.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000813076202/d1b6890619c573cdd53a3dfb7b90fbf7_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000813076202/d1b6890619c573cdd53a3dfb7b90fbf7_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/347934366/1357288847",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -29.7127943,
                -52.4238487
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -52.4238487,
                -29.7127943
            ]
        },
        "place": {
            "id": "c99718f589129a6a",
            "url": "https://api.twitter.com/1.1/geo/id/c99718f589129a6a.json",
            "place_type": "city",
            "name": "Santa Cruz do Sul",
            "full_name": "Santa Cruz do Sul, Rio Grande do Sul",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -52.5839446,
                            -29.8265408
                        ],
                        [
                            -52.5839446,
                            -29.3706112
                        ],
                        [
                            -52.298364,
                            -29.3706112
                        ],
                        [
                            -52.298364,
                            -29.8265408
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "_dannifr",
                    "name": "danni rodrigues  ;",
                    "id": 175623947,
                    "id_str": "175623947",
                    "indices": [
                        0,
                        9
                    ]
                },
                {
                    "screen_name": "Danarauber",
                    "name": "Dânara Rauber.",
                    "id": 609485663,
                    "id_str": "609485663",
                    "indices": [
                        10,
                        21
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803686174700,
        "id_str": "407240803686174721",
        "text": "I shouldn't have ever fucked you on a boat on your birthday",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 792815576,
            "id_str": "792815576",
            "name": "ΔΝDRΞΔ GΔΞ†Δ",
            "screen_name": "andr33zyy",
            "location": "killa city",
            "url": null,
            "description": "when I was a baby I was dropped in a box of glitter & I been shinin ever since",
            "protected": false,
            "followers_count": 594,
            "friends_count": 330,
            "listed_count": 2,
            "created_at": "Fri Aug 31 01:49:52 +0000 2012",
            "favourites_count": 17195,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 22576,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/768067259/9432dc6468acc0d0b25770acbb124d58.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/768067259/9432dc6468acc0d0b25770acbb124d58.png",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000780223341/ddc9ae9d37ace2ba505ae5ebdb58aaca_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000780223341/ddc9ae9d37ace2ba505ae5ebdb58aaca_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/792815576/1385510727",
            "profile_link_color": "000000",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "000000",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                38.8856191,
                -94.82661889
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -94.82661889,
                38.8856191
            ]
        },
        "place": {
            "id": "06d6054b42e6575f",
            "url": "https://api.twitter.com/1.1/geo/id/06d6054b42e6575f.json",
            "place_type": "city",
            "name": "Olathe",
            "full_name": "Olathe, KS",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -94.928023,
                            38.825531
                        ],
                        [
                            -94.928023,
                            38.987756
                        ],
                        [
                            -94.714048,
                            38.987756
                        ],
                        [
                            -94.714048,
                            38.825531
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803820785660,
        "id_str": "407240803820785664",
        "text": "Há muito tempo não me sentia tão bem e em casa assim...",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 750465469,
            "id_str": "750465469",
            "name": "Bárbara.",
            "screen_name": "barbaaaaramelo",
            "location": "Campo Grande - MS",
            "url": null,
            "description": "http://instagram.com/barbaramelomei…",
            "protected": false,
            "followers_count": 211,
            "friends_count": 353,
            "listed_count": 0,
            "created_at": "Sat Aug 11 02:14:15 +0000 2012",
            "favourites_count": 614,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10676,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000079714246/d2a3dac65e8334561a9375d11694c3d0.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000079714246/d2a3dac65e8334561a9375d11694c3d0.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000790015557/b23be561e2d54c37e3be1a0124c0949c_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000790015557/b23be561e2d54c37e3be1a0124c0949c_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/750465469/1379816766",
            "profile_link_color": "000000",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -20.453394,
                -54.6091212
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -54.6091212,
                -20.453394
            ]
        },
        "place": {
            "id": "d13775d10c08f835",
            "url": "https://api.twitter.com/1.1/geo/id/d13775d10c08f835.json",
            "place_type": "city",
            "name": "Campo Grande",
            "full_name": "Campo Grande, Mato Grosso do Sul",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -54.923521,
                            -21.585065999999998
                        ],
                        [
                            -54.923521,
                            -20.166076999999998
                        ],
                        [
                            -53.600229,
                            -20.166076999999998
                        ],
                        [
                            -53.600229,
                            -21.585065999999998
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803619065860,
        "id_str": "407240803619065856",
        "text": "@HannahPDavis it's not a song haha",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240731699343360,
        "in_reply_to_status_id_str": "407240731699343360",
        "in_reply_to_user_id": 539243415,
        "in_reply_to_user_id_str": "539243415",
        "in_reply_to_screen_name": "HannahPDavis",
        "user": {
            "id": 93120555,
            "id_str": "93120555",
            "name": "⭐️valon Nero",
            "screen_name": "Avalon_Nero",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 318,
            "friends_count": 306,
            "listed_count": 0,
            "created_at": "Sat Nov 28 04:44:40 +0000 2009",
            "favourites_count": 1474,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2399,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000357991686/0d6fab5bac1a88edccb4bcbb2137210d_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000357991686/0d6fab5bac1a88edccb4bcbb2137210d_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/93120555/1385314559",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                42.19117568,
                -88.34841977
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -88.34841977,
                42.19117568
            ]
        },
        "place": {
            "id": "c648b4de515a26e9",
            "url": "https://api.twitter.com/1.1/geo/id/c648b4de515a26e9.json",
            "place_type": "city",
            "name": "Crystal Lake",
            "full_name": "Crystal Lake, IL",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -88.389685,
                            42.189512
                        ],
                        [
                            -88.389685,
                            42.276973
                        ],
                        [
                            -88.271903,
                            42.276973
                        ],
                        [
                            -88.271903,
                            42.189512
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "HannahPDavis",
                    "name": "Hannah Davis",
                    "id": 539243415,
                    "id_str": "539243415",
                    "indices": [
                        0,
                        13
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803762044900,
        "id_str": "407240803762044928",
        "text": "@1Alberto_Garcia Alberto que le dibiste al hijo puta de hoy para q te sacase la roja?",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": 634424045,
        "in_reply_to_user_id_str": "634424045",
        "in_reply_to_screen_name": "1Alberto_Garcia",
        "user": {
            "id": 400567145,
            "id_str": "400567145",
            "name": "Oscar Cano ",
            "screen_name": "OscarCanoCastro",
            "location": "Xixon",
            "url": null,
            "description": "Rajoy responde a las críticas no voy a dimitir mientras se escuche una gaita o haya sidra en el llagar",
            "protected": false,
            "followers_count": 279,
            "friends_count": 456,
            "listed_count": 3,
            "created_at": "Sat Oct 29 07:25:00 +0000 2011",
            "favourites_count": 180,
            "utc_offset": 3600,
            "time_zone": "Madrid",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9844,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/1887114161/Sin_t_tulo-2_normal.jpg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/1887114161/Sin_t_tulo-2_normal.jpg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/400567145/1363950383",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                43.521363,
                -5.6684551
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -5.6684551,
                43.521363
            ]
        },
        "place": {
            "id": "731c9d11275a5436",
            "url": "https://api.twitter.com/1.1/geo/id/731c9d11275a5436.json",
            "place_type": "city",
            "name": "Gijón",
            "full_name": "Gijón, Asturias",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -5.8209772,
                            43.4416802
                        ],
                        [
                            -5.8209772,
                            43.5751547
                        ],
                        [
                            -5.5629115,
                            43.5751547
                        ],
                        [
                            -5.5629115,
                            43.4416802
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "1Alberto_Garcia",
                    "name": "Alberto García 25",
                    "id": 634424045,
                    "id_str": "634424045",
                    "indices": [
                        0,
                        16
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803850149900,
        "id_str": "407240803850149888",
        "text": "Have to say that Ross always holds fabulous parties!",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 610705850,
            "id_str": "610705850",
            "name": "Latino Heat ✞",
            "screen_name": "_PussyLiquor",
            "location": "Glasgow, Scotland.",
            "url": "http://vag-i-na.tumblr.com/",
            "description": "Michael Jackson and Eddie Guerrero are my life, rest in peace.",
            "protected": false,
            "followers_count": 1052,
            "friends_count": 300,
            "listed_count": 2,
            "created_at": "Sun Jun 17 10:46:34 +0000 2012",
            "favourites_count": 675,
            "utc_offset": 0,
            "time_zone": "London",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 15928,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000766427403/17806e7ae596fbc56684ab3d57be19a5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000766427403/17806e7ae596fbc56684ab3d57be19a5_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/610705850/1384361929",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                55.85060264,
                -4.58707119
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -4.58707119,
                55.85060264
            ]
        },
        "place": {
            "id": "589dd64daeb877d5",
            "url": "https://api.twitter.com/1.1/geo/id/589dd64daeb877d5.json",
            "place_type": "city",
            "name": "Renfrewshire",
            "full_name": "Renfrewshire, Renfrewshire",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -4.783999,
                            55.759510999999996
                        ],
                        [
                            -4.783999,
                            55.938689
                        ],
                        [
                            -4.356717,
                            55.938689
                        ],
                        [
                            -4.356717,
                            55.759510999999996
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803019284500,
        "id_str": "407240803019284480",
        "text": "cuando me quiero tomar una foto @LorenaIsabelvb http://t.co/hc0cc7OXNz",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1330152758,
            "id_str": "1330152758",
            "name": "change me",
            "screen_name": "effysadness",
            "location": "24/10 best day ever.",
            "url": null,
            "description": "14. stay loyal, stay faithful, stay true.",
            "protected": false,
            "followers_count": 1115,
            "friends_count": 1175,
            "listed_count": 5,
            "created_at": "Fri Apr 05 21:55:30 +0000 2013",
            "favourites_count": 906,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 6830,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000114608237/ee29ea437010f11d9adb1485ba6dd1cd.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000114608237/ee29ea437010f11d9adb1485ba6dd1cd.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000811534192/7821a0f3f79b5dedb15a7c3c5f4231ac_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000811534192/7821a0f3f79b5dedb15a7c3c5f4231ac_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1330152758/1385832185",
            "profile_link_color": "0D0404",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                9.05779736,
                -79.47512147
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -79.47512147,
                9.05779736
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "LorenaIsabelvb",
                    "name": "Lorena Vargas♡",
                    "id": 948005815,
                    "id_str": "948005815",
                    "indices": [
                        32,
                        47
                    ]
                }
            ],
            "media": [
                {
                    "id": 407240802226540540,
                    "id_str": "407240802226540544",
                    "indices": [
                        48,
                        70
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWhrCEAAxVAI.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWhrCEAAxVAI.jpg",
                    "url": "http://t.co/hc0cc7OXNz",
                    "display_url": "pic.twitter.com/hc0cc7OXNz",
                    "expanded_url": "http://twitter.com/effysadness/status/407240803019284480/photo/1",
                    "type": "photo",
                    "sizes": {
                        "small": {
                            "w": 339,
                            "h": 261,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "large": {
                            "w": 500,
                            "h": 384,
                            "resize": "fit"
                        },
                        "medium": {
                            "w": 500,
                            "h": 384,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804022104060,
        "id_str": "407240804022104064",
        "text": "#new_avatar",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1462192082,
            "id_str": "1462192082",
            "name": "ادهم محمد",
            "screen_name": "Adham_El7eny",
            "location": "EL MinYa",
            "url": "https://www.facebook.com/adham.elheenny",
            "description": "منير وبحب اصحابى",
            "protected": false,
            "followers_count": 274,
            "friends_count": 91,
            "listed_count": 0,
            "created_at": "Mon May 27 14:04:33 +0000 2013",
            "favourites_count": 322,
            "utc_offset": 7200,
            "time_zone": "Cairo",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2407,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1A1B1F",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000817075483/7ec4bfca5e3d382c097abc1ad149b246_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000817075483/7ec4bfca5e3d382c097abc1ad149b246_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1462192082/1385928584",
            "profile_link_color": "BD1E3E",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "252429",
            "profile_text_color": "666666",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                28.0970916,
                30.7515937
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                30.7515937,
                28.0970916
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "new_avatar",
                    "indices": [
                        0,
                        11
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "vi"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803770462200,
        "id_str": "407240803770462208",
        "text": "@DanCarl_ exactly, it's a children's film but it's quite scary for a child 🙈",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407239662185775100,
        "in_reply_to_status_id_str": "407239662185775104",
        "in_reply_to_user_id": 39651760,
        "in_reply_to_user_id_str": "39651760",
        "in_reply_to_screen_name": "DanCarl_",
        "user": {
            "id": 585636538,
            "id_str": "585636538",
            "name": "becky ⭐",
            "screen_name": "davison_becky",
            "location": "UK. SUNDERLAND",
            "url": null,
            "description": "Bios are shit so @_beckydavison go follow me on instagram",
            "protected": false,
            "followers_count": 503,
            "friends_count": 452,
            "listed_count": 0,
            "created_at": "Sun May 20 12:35:46 +0000 2012",
            "favourites_count": 799,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3389,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/626163246/0h720admakfvlv6fw95v.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/626163246/0h720admakfvlv6fw95v.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000784213284/dc57952bfcf536e43c80f19bc32330fb_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000784213284/dc57952bfcf536e43c80f19bc32330fb_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/585636538/1372599970",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                54.87603891,
                -1.39726288
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -1.39726288,
                54.87603891
            ]
        },
        "place": {
            "id": "565cdb1de3e0a390",
            "url": "https://api.twitter.com/1.1/geo/id/565cdb1de3e0a390.json",
            "place_type": "city",
            "name": "Sunderland",
            "full_name": "Sunderland, Sunderland",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -1.5688799999999998,
                            54.799046
                        ],
                        [
                            -1.5688799999999998,
                            54.944173
                        ],
                        [
                            -1.345665,
                            54.944173
                        ],
                        [
                            -1.345665,
                            54.799046
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "DanCarl_",
                    "name": "Dan",
                    "id": 39651760,
                    "id_str": "39651760",
                    "indices": [
                        0,
                        9
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803921432600,
        "id_str": "407240803921432576",
        "text": "\"@Jane_Aloud: @woxoge *ignored*\" oh gyae saa",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 53770435,
            "id_str": "53770435",
            "name": "vincent dumashie",
            "screen_name": "woxoge",
            "location": "ghana",
            "url": null,
            "description": "i dont have a type. If i like you, i like you! Period!",
            "protected": false,
            "followers_count": 337,
            "friends_count": 345,
            "listed_count": 2,
            "created_at": "Sat Jul 04 21:57:19 +0000 2009",
            "favourites_count": 71,
            "utc_offset": 0,
            "time_zone": "London",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 35795,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C6E2EE",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/243557569/incredibles_1_8.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/243557569/incredibles_1_8.jpg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000814134938/5bb8ce6242b8e72387d94a454b26f3a0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000814134938/5bb8ce6242b8e72387d94a454b26f3a0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/53770435/1380310028",
            "profile_link_color": "1F98C7",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DAECF4",
            "profile_text_color": "663B12",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                5.6722915,
                -0.0195054
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -0.0195054,
                5.6722915
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Jane_Aloud",
                    "name": "Childish Gambino",
                    "id": 972309336,
                    "id_str": "972309336",
                    "indices": [
                        1,
                        12
                    ]
                },
                {
                    "screen_name": "woxoge",
                    "name": "vincent dumashie",
                    "id": 53770435,
                    "id_str": "53770435",
                    "indices": [
                        14,
                        21
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803799429100,
        "id_str": "407240803799429120",
        "text": "I love getting my nails done but hate it because I can't understand anything they say",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 460143616,
            "id_str": "460143616",
            "name": "Hannah",
            "screen_name": "hburns122",
            "location": "",
            "url": null,
            "description": "Hannah Burns - Sophomore - Beechwood - Soccer - Demi Lovato - Ice Cream Cake",
            "protected": false,
            "followers_count": 222,
            "friends_count": 371,
            "listed_count": 0,
            "created_at": "Tue Jan 10 12:45:58 +0000 2012",
            "favourites_count": 500,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3439,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000815847605/16598377e74765bca2cf89c53631ecff_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000815847605/16598377e74765bca2cf89c53631ecff_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/460143616/1384559300",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.06132636,
                -84.54182574
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -84.54182574,
                39.06132636
            ]
        },
        "place": {
            "id": "38ce91044a32055f",
            "url": "https://api.twitter.com/1.1/geo/id/38ce91044a32055f.json",
            "place_type": "city",
            "name": "Fort Wright",
            "full_name": "Fort Wright, KY",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -84.559309,
                            39.00704
                        ],
                        [
                            -84.559309,
                            39.080482
                        ],
                        [
                            -84.511497,
                            39.080482
                        ],
                        [
                            -84.511497,
                            39.00704
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240803938234400,
        "id_str": "407240803938234368",
        "text": "Mi sto riducendo a tornare a casa sbronza ogni domenica",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 548678969,
            "id_str": "548678969",
            "name": "Big Jellyfish",
            "screen_name": "AnnaTamburlini",
            "location": "Udine",
            "url": null,
            "description": "Essere intelligenti, di questi tempi mette a disagio più che farla nei cessi pubblici.\r\n[Marracash]",
            "protected": false,
            "followers_count": 135,
            "friends_count": 111,
            "listed_count": 0,
            "created_at": "Sun Apr 08 20:01:44 +0000 2012",
            "favourites_count": 152,
            "utc_offset": 3600,
            "time_zone": "Rome",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1427,
            "lang": "it",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0099B9",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/814559239/b3b87229b2209360dac9bb8e3c4300aa.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/814559239/b3b87229b2209360dac9bb8e3c4300aa.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000494879157/594ba785cbec4a862f487bc8006116df_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000494879157/594ba785cbec4a862f487bc8006116df_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/548678969/1366654027",
            "profile_link_color": "0099B9",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "000B17",
            "profile_text_color": "448668",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                46.0971623,
                13.231682
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                13.231682,
                46.0971623
            ]
        },
        "place": {
            "id": "3282e2eaa378536e",
            "url": "https://api.twitter.com/1.1/geo/id/3282e2eaa378536e.json",
            "place_type": "city",
            "name": "Udine",
            "full_name": "Udine, Udine",
            "country_code": "IT",
            "country": "Italia",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            13.1844558,
                            46.0017755
                        ],
                        [
                            13.1844558,
                            46.1171329
                        ],
                        [
                            13.2944503,
                            46.1171329
                        ],
                        [
                            13.2944503,
                            46.0017755
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "it"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804693180400,
        "id_str": "407240804693180417",
        "text": "بياخدوا صورة تشخارية ....",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 309142699,
            "id_str": "309142699",
            "name": "أرض النفاق ",
            "screen_name": "Basem_Barakat",
            "location": "Giza , Faysal ",
            "url": "https://m.facebook.com/basemsayhi?id=1147551617&_rdr",
            "description": "‏‏أنا التراب افتكري يا نفسي .. انا التراب إياكي تنسي",
            "protected": false,
            "followers_count": 550,
            "friends_count": 198,
            "listed_count": 6,
            "created_at": "Wed Jun 01 16:09:41 +0000 2011",
            "favourites_count": 479,
            "utc_offset": 7200,
            "time_zone": "Vilnius",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 19464,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "642D8B",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000573375389/211c23f521df9201293de5229dd18627_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000573375389/211c23f521df9201293de5229dd18627_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/309142699/1377995011",
            "profile_link_color": "FF0000",
            "profile_sidebar_border_color": "65B0DA",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                30.0065275,
                31.1589259
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                31.1589259,
                30.0065275
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804626087940,
        "id_str": "407240804626087937",
        "text": "Love that white dress on tamera foster",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 393662222,
            "id_str": "393662222",
            "name": "_scar",
            "screen_name": "scarlett_elizaa",
            "location": "roaming the streets of london",
            "url": null,
            "description": "i like your face.",
            "protected": false,
            "followers_count": 669,
            "friends_count": 1097,
            "listed_count": 0,
            "created_at": "Tue Oct 18 21:46:49 +0000 2011",
            "favourites_count": 618,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5087,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000782960353/e098a591b7a11dd174ef06cd0438de71_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000782960353/e098a591b7a11dd174ef06cd0438de71_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/393662222/1383218145",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                51.61674498,
                -0.0992336
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -0.0992336,
                51.61674498
            ]
        },
        "place": {
            "id": "a542d4198f8151de",
            "url": "https://api.twitter.com/1.1/geo/id/a542d4198f8151de.json",
            "place_type": "city",
            "name": "Enfield",
            "full_name": "Enfield, London",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -0.18575999999999998,
                            51.604518999999996
                        ],
                        [
                            -0.18575999999999998,
                            51.691672
                        ],
                        [
                            -0.010135,
                            51.691672
                        ],
                        [
                            -0.010135,
                            51.604518999999996
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804517027840,
        "id_str": "407240804517027840",
        "text": "They know who we are #MTVStars Nicki Minaj",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 355078523,
            "id_str": "355078523",
            "name": "™Twerk King™",
            "screen_name": "NickiFollowMe69",
            "location": "",
            "url": "http://mypinkfriday.com",
            "description": "@NICKIMINAJ Retweeted.",
            "protected": false,
            "followers_count": 2124,
            "friends_count": 1815,
            "listed_count": 1,
            "created_at": "Sun Aug 14 20:00:08 +0000 2011",
            "favourites_count": 158,
            "utc_offset": 0,
            "time_zone": "London",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 15451,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "33FF00",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000047452681/925635cf58a5d6d6efc6e8795cd4a7b8.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000047452681/925635cf58a5d6d6efc6e8795cd4a7b8.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000817078087/dfa8b38b2b80b58337cbd7302edb706a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000817078087/dfa8b38b2b80b58337cbd7302edb706a_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/355078523/1385146278",
            "profile_link_color": "FF00FF",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                50.69130157,
                -1.31757726
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -1.31757726,
                50.69130157
            ]
        },
        "place": {
            "id": "ef1be8fb55cd3db6",
            "url": "https://api.twitter.com/1.1/geo/id/ef1be8fb55cd3db6.json",
            "place_type": "city",
            "name": "Isle of Wight",
            "full_name": "Isle of Wight, Isle of Wight",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -1.5924607000000002,
                            50.5743399
                        ],
                        [
                            -1.5924607000000002,
                            50.7678382
                        ],
                        [
                            -1.062719,
                            50.7678382
                        ],
                        [
                            -1.062719,
                            50.5743399
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "MTVStars",
                    "indices": [
                        21,
                        30
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804751917060,
        "id_str": "407240804751917056",
        "text": "Je liegt veel man",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 236740004,
            "id_str": "236740004",
            "name": "-",
            "screen_name": "Sammmy072",
            "location": "HHW ALL DAY - 072",
            "url": "http://www.Mocro-Place.nl",
            "description": "#MarokkaansBloed   #insta: Sammmy072   - 'Live Your Own Life' - 'Keep Your Self' - 'Money Changes EveryThing'",
            "protected": false,
            "followers_count": 290,
            "friends_count": 198,
            "listed_count": 0,
            "created_at": "Tue Jan 11 07:54:22 +0000 2011",
            "favourites_count": 22,
            "utc_offset": -10800,
            "time_zone": "Greenland",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 15634,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "352726",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/266846033/79c146a1373a3cd9dc11d2e3465eeda5.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/266846033/79c146a1373a3cd9dc11d2e3465eeda5.jpg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000464895742/bb9927950d70ef89a66c616ce9703331_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000464895742/bb9927950d70ef89a66c616ce9703331_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/236740004/1378487786",
            "profile_link_color": "15FF00",
            "profile_sidebar_border_color": "FFFF00",
            "profile_sidebar_fill_color": "FFFF00",
            "profile_text_color": "FF0000",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                52.6604578,
                4.8167981
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                4.8167981,
                52.6604578
            ]
        },
        "place": {
            "id": "a6cb81aab2ae4239",
            "url": "https://api.twitter.com/1.1/geo/id/a6cb81aab2ae4239.json",
            "place_type": "city",
            "name": "Heerhugowaard",
            "full_name": "Heerhugowaard, North Holland",
            "country_code": "NL",
            "country": "The Netherlands",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            4.7855597,
                            52.6328145
                        ],
                        [
                            4.7855597,
                            52.7233246
                        ],
                        [
                            4.8999298,
                            52.7233246
                        ],
                        [
                            4.8999298,
                            52.6328145
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "nl"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804600930300,
        "id_str": "407240804600930304",
        "text": "@colinproctor123 @ConceptGlasgow @dionneeee_ @laurenKoneill95 they're so cute!!",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407239627893129200,
        "in_reply_to_status_id_str": "407239627893129217",
        "in_reply_to_user_id": 396819608,
        "in_reply_to_user_id_str": "396819608",
        "in_reply_to_screen_name": "colinproctor123",
        "user": {
            "id": 559615742,
            "id_str": "559615742",
            "name": "fat amy",
            "screen_name": "_amytimelow",
            "location": "Glasgow, UK",
            "url": null,
            "description": "two can keep a secret, if one of them is dead",
            "protected": false,
            "followers_count": 2593,
            "friends_count": 2349,
            "listed_count": 6,
            "created_at": "Sat Apr 21 14:59:18 +0000 2012",
            "favourites_count": 1106,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 13697,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000113197134/dc7874a2db3b95eee7d74459e906d086.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000113197134/dc7874a2db3b95eee7d74459e906d086.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000816895155/27e39ad41938914cca223052fe5e714b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000816895155/27e39ad41938914cca223052fe5e714b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/559615742/1384564315",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                56.00972084,
                -4.71125657
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -4.71125657,
                56.00972084
            ]
        },
        "place": {
            "id": "0e9a0bdd7a864e4f",
            "url": "https://api.twitter.com/1.1/geo/id/0e9a0bdd7a864e4f.json",
            "place_type": "city",
            "name": "Argyll and Bute",
            "full_name": "Argyll and Bute, Argyll and Bute",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -7.008572,
                            55.274286999999994
                        ],
                        [
                            -7.008572,
                            56.705107999999996
                        ],
                        [
                            -4.559835,
                            56.705107999999996
                        ],
                        [
                            -4.559835,
                            55.274286999999994
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "colinproctor123",
                    "name": "colin :) ",
                    "id": 396819608,
                    "id_str": "396819608",
                    "indices": [
                        0,
                        16
                    ]
                },
                {
                    "screen_name": "ConceptGlasgow",
                    "name": "ashhh",
                    "id": 390132030,
                    "id_str": "390132030",
                    "indices": [
                        17,
                        32
                    ]
                },
                {
                    "screen_name": "dionneeee_",
                    "name": "dee",
                    "id": 1507359157,
                    "id_str": "1507359157",
                    "indices": [
                        33,
                        44
                    ]
                },
                {
                    "screen_name": "laurenKoneill95",
                    "name": "SupaGeekLaurenX",
                    "id": 1035401466,
                    "id_str": "1035401466",
                    "indices": [
                        45,
                        61
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804608925700,
        "id_str": "407240804608925696",
        "text": "Galatasaray her zaman ki gibi bu akşamda beni sinir krizine soktu .s",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1438493042,
            "id_str": "1438493042",
            "name": "E R T A N",
            "screen_name": "Ertn37",
            "location": "Çavuspaşa",
            "url": "https://www.facebook.com/Ertaninprofili?ref=tn_tnmn",
            "description": "#Duman #Eminem #Toygar Işıklı #Sagopa Kajmer ♫           GALATASARAY",
            "protected": false,
            "followers_count": 230,
            "friends_count": 169,
            "listed_count": 0,
            "created_at": "Sat May 18 14:07:32 +0000 2013",
            "favourites_count": 268,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2619,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000123073552/9581d9d890aa675273c6b863aabaa0b0.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000123073552/9581d9d890aa675273c6b863aabaa0b0.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000784734620/9589c4bd797a7fcac4f66d2426b0953c_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000784734620/9589c4bd797a7fcac4f66d2426b0953c_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1438493042/1385236520",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804730941440,
        "id_str": "407240804730941440",
        "text": "@rafarood @marcelinhodibob @raivianna cadeee vcssss",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240623524413440,
        "in_reply_to_status_id_str": "407240623524413440",
        "in_reply_to_user_id": 840579637,
        "in_reply_to_user_id_str": "840579637",
        "in_reply_to_screen_name": "rafarood",
        "user": {
            "id": 174467217,
            "id_str": "174467217",
            "name": "2k",
            "screen_name": "Ko_Kaa",
            "location": "",
            "url": "http://www.facebook.com/koka.RTT",
            "description": "Estilo livre vivazZzZzzzz",
            "protected": false,
            "followers_count": 421,
            "friends_count": 168,
            "listed_count": 2,
            "created_at": "Wed Aug 04 00:31:06 +0000 2010",
            "favourites_count": 208,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7074,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "EDECE9",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/704467012/4dfc49a467d1a1fbd4ab14e0f65d6043.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/704467012/4dfc49a467d1a1fbd4ab14e0f65d6043.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000343040989/656626430ccdfb327ea7a242d68631b7_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000343040989/656626430ccdfb327ea7a242d68631b7_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/174467217/1379996837",
            "profile_link_color": "088253",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "C0DFEC",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -22.8090913,
                -43.4238885
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -43.4238885,
                -22.8090913
            ]
        },
        "place": {
            "id": "abbb45debbf38127",
            "url": "https://api.twitter.com/1.1/geo/id/abbb45debbf38127.json",
            "place_type": "city",
            "name": "Nilópolis",
            "full_name": "Nilópolis, Rio de Janeiro",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -43.469372,
                            -22.848515
                        ],
                        [
                            -43.469372,
                            -22.791608999999998
                        ],
                        [
                            -43.390788,
                            -22.791608999999998
                        ],
                        [
                            -43.390788,
                            -22.848515
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "rafarood",
                    "name": "Rafa Rodrigues",
                    "id": 840579637,
                    "id_str": "840579637",
                    "indices": [
                        0,
                        9
                    ]
                },
                {
                    "screen_name": "marcelinhodibob",
                    "name": "Marceliinhoo",
                    "id": 1955482693,
                    "id_str": "1955482693",
                    "indices": [
                        10,
                        26
                    ]
                },
                {
                    "screen_name": "raivianna",
                    "name": "Raissa Vianna ",
                    "id": 53804277,
                    "id_str": "53804277",
                    "indices": [
                        27,
                        37
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804181098500,
        "id_str": "407240804181098496",
        "text": "inchallah @AlexKossdar",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240400026738700,
        "in_reply_to_status_id_str": "407240400026738690",
        "in_reply_to_user_id": 997938782,
        "in_reply_to_user_id_str": "997938782",
        "in_reply_to_screen_name": "AlexKossdar",
        "user": {
            "id": 1027288556,
            "id_str": "1027288556",
            "name": "II .G",
            "screen_name": "Dmk_Saanchez",
            "location": "91 SANG 50",
            "url": null,
            "description": "I'll get there #Football #3",
            "protected": false,
            "followers_count": 313,
            "friends_count": 235,
            "listed_count": 0,
            "created_at": "Fri Dec 21 22:35:47 +0000 2012",
            "favourites_count": 258,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 12916,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "A65A92",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000105847640/f5adb452e2d0f9183410e7b6604803b9.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000105847640/f5adb452e2d0f9183410e7b6604803b9.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000816855371/1b478feeb8a9118ac1e0926df08e5d62_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000816855371/1b478feeb8a9118ac1e0926df08e5d62_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1027288556/1378581531",
            "profile_link_color": "36A9F5",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "90b0e77f61e6b864",
            "url": "https://api.twitter.com/1.1/geo/id/90b0e77f61e6b864.json",
            "place_type": "city",
            "name": "Etampes",
            "full_name": "Etampes, Essonne",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.0714097,
                            48.3823193
                        ],
                        [
                            2.0714097,
                            48.4631267
                        ],
                        [
                            2.2335308,
                            48.4631267
                        ],
                        [
                            2.2335308,
                            48.3823193
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "AlexKossdar",
                    "name": "Maki'Lourd",
                    "id": 997938782,
                    "id_str": "997938782",
                    "indices": [
                        10,
                        22
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "et"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804684800000,
        "id_str": "407240804684800000",
        "text": "@DeiiNunez @MarlyVilla13 Yo tampoco noce quien es JAJAJAJAJA sii Marlucha dice que es puta es PUTAAAA!!",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240436122538000,
        "in_reply_to_status_id_str": "407240436122537985",
        "in_reply_to_user_id": 538512939,
        "in_reply_to_user_id_str": "538512939",
        "in_reply_to_screen_name": "DeiiNunez",
        "user": {
            "id": 353270555,
            "id_str": "353270555",
            "name": "ÑA RODETE :$",
            "screen_name": "lore_bogadoV",
            "location": "",
            "url": null,
            "description": "CERRISTA *--------* DESDE LA CUNA HASTA EL CAJÒN, FRANQUEÑA, BATAN 0'14",
            "protected": false,
            "followers_count": 926,
            "friends_count": 835,
            "listed_count": 0,
            "created_at": "Thu Aug 11 20:26:40 +0000 2011",
            "favourites_count": 687,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14669,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/795180579/eb316e137f025e8272ec879994c746ea.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/795180579/eb316e137f025e8272ec879994c746ea.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000649723574/4670c403c9970602a323ef4fdbf281b0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000649723574/4670c403c9970602a323ef4fdbf281b0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/353270555/1382894015",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -25.24575,
                -57.5345443
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -57.5345443,
                -25.24575
            ]
        },
        "place": {
            "id": "1b107df3ccc0aaa1",
            "url": "https://api.twitter.com/1.1/geo/id/1b107df3ccc0aaa1.json",
            "place_type": "country",
            "name": "Brasil",
            "full_name": "Brasil",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -73.99148199999999,
                            -33.750575999999995
                        ],
                        [
                            -73.99148199999999,
                            5.27192
                        ],
                        [
                            -32.378186,
                            5.27192
                        ],
                        [
                            -32.378186,
                            -33.750575999999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "DeiiNunez",
                    "name": "IMPERFECTA ♡",
                    "id": 538512939,
                    "id_str": "538512939",
                    "indices": [
                        0,
                        10
                    ]
                },
                {
                    "screen_name": "MarlyVilla13",
                    "name": "Ña Kachi .",
                    "id": 987722132,
                    "id_str": "987722132",
                    "indices": [
                        11,
                        24
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804793876500,
        "id_str": "407240804793876480",
        "text": "@feelslik_DEJAvu wrestling",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240362454167550,
        "in_reply_to_status_id_str": "407240362454167553",
        "in_reply_to_user_id": 428681559,
        "in_reply_to_user_id_str": "428681559",
        "in_reply_to_screen_name": "feelslik_DEJAvu",
        "user": {
            "id": 311270967,
            "id_str": "311270967",
            "name": "wavey ✊",
            "screen_name": "Brick_Raw",
            "location": "Around",
            "url": null,
            "description": "Wavey✊",
            "protected": false,
            "followers_count": 633,
            "friends_count": 521,
            "listed_count": 2,
            "created_at": "Sun Jun 05 05:05:45 +0000 2011",
            "favourites_count": 569,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 49676,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "EDECE9",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/740195894/af1148770b18581f7bb5a777d5e3d0af.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/740195894/af1148770b18581f7bb5a777d5e3d0af.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000798945610/12c32883cb20e949fe231d2396c759d5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000798945610/12c32883cb20e949fe231d2396c759d5_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/311270967/1385085372",
            "profile_link_color": "088253",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "E3E2DE",
            "profile_text_color": "634047",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.79775213,
                -75.47050927
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -75.47050927,
                39.79775213
            ]
        },
        "place": {
            "id": "7c3a198212bb6e2a",
            "url": "https://api.twitter.com/1.1/geo/id/7c3a198212bb6e2a.json",
            "place_type": "city",
            "name": "Claymont",
            "full_name": "Claymont, DE",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -75.486733,
                            39.790219
                        ],
                        [
                            -75.486733,
                            39.819158
                        ],
                        [
                            -75.436975,
                            39.819158
                        ],
                        [
                            -75.436975,
                            39.790219
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "feelslik_DEJAvu",
                    "name": "DW",
                    "id": 428681559,
                    "id_str": "428681559",
                    "indices": [
                        0,
                        16
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804579958800,
        "id_str": "407240804579958784",
        "text": "@raad_1433 هنا الغباء لما تجتمع مع الجهل",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240635213963260,
        "in_reply_to_status_id_str": "407240635213963265",
        "in_reply_to_user_id": 846513679,
        "in_reply_to_user_id_str": "846513679",
        "in_reply_to_screen_name": "raad_1433",
        "user": {
            "id": 307816928,
            "id_str": "307816928",
            "name": "Ph.Abrar_jameel.",
            "screen_name": "Bero5555",
            "location": "Riyadh _ Jeddah",
            "url": null,
            "description": "اللّهمّ اهدِني , ثُم اهدِني , ثُم اهدِني , ثُم خُذني إليك ♥ http://ask.fm/abrarjameel",
            "protected": false,
            "followers_count": 355,
            "friends_count": 688,
            "listed_count": 2,
            "created_at": "Mon May 30 10:25:53 +0000 2011",
            "favourites_count": 83,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3005,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000625301190/77fd547ab36efbd8b1bfe5d730dbd353_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000625301190/77fd547ab36efbd8b1bfe5d730dbd353_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/307816928/1385116848",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                24.7665592,
                46.8242482
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                46.8242482,
                24.7665592
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "raad_1433",
                    "name": "الشريف رعد بن فهيد",
                    "id": 846513679,
                    "id_str": "846513679",
                    "indices": [
                        0,
                        10
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804626083840,
        "id_str": "407240804626083841",
        "text": "@azrameliss HMM BELKİDE MARILYN MANSON PSİKOPATININ KARISI OLDUĞU İÇİN UNF ETMİŞİM",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240338198106100,
        "in_reply_to_status_id_str": "407240338198106112",
        "in_reply_to_user_id": 619102793,
        "in_reply_to_user_id_str": "619102793",
        "in_reply_to_screen_name": "azrameliss",
        "user": {
            "id": 290530274,
            "id_str": "290530274",
            "name": "Who Am I?",
            "screen_name": "bthnhammett",
            "location": "Samsun",
            "url": null,
            "description": "Facebook:http://facebook.com/batuhan.yurtse…     Instagram: batuhanyrtsvn",
            "protected": false,
            "followers_count": 608,
            "friends_count": 132,
            "listed_count": 0,
            "created_at": "Sat Apr 30 12:43:49 +0000 2011",
            "favourites_count": 597,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2693,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131623",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/851505096/5f2af30598b07cc765e72b17cf0789e6.gif",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/851505096/5f2af30598b07cc765e72b17cf0789e6.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000794814398/9cd239f5fc0dfa4180eb9aa74fa6fbaf_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000794814398/9cd239f5fc0dfa4180eb9aa74fa6fbaf_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/290530274/1364583078",
            "profile_link_color": "5EB490",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "C1BA85",
            "profile_text_color": "4D6057",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.335349,
                36.2598454
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                36.2598454,
                41.335349
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "azrameliss",
                    "name": "miss manson",
                    "id": 619102793,
                    "id_str": "619102793",
                    "indices": [
                        0,
                        11
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804827418600,
        "id_str": "407240804827418624",
        "text": "@DShallzz hahahahahahaha 😘she asked me who she could call obviously I said you",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407239642812280800,
        "in_reply_to_status_id_str": "407239642812280832",
        "in_reply_to_user_id": 355831164,
        "in_reply_to_user_id_str": "355831164",
        "in_reply_to_screen_name": "DShallzz",
        "user": {
            "id": 446408892,
            "id_str": "446408892",
            "name": "Anna Conklin",
            "screen_name": "TurnUPtheA_C_",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 598,
            "friends_count": 853,
            "listed_count": 0,
            "created_at": "Sun Dec 25 17:51:23 +0000 2011",
            "favourites_count": 3399,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1640,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000398507108/c4003c285bfc360b70df661b38cc6574_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000398507108/c4003c285bfc360b70df661b38cc6574_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/446408892/1373947181",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.89031538,
                -74.51339272
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -74.51339272,
                40.89031538
            ]
        },
        "place": {
            "id": "ea767b0daf0dda36",
            "url": "https://api.twitter.com/1.1/geo/id/ea767b0daf0dda36.json",
            "place_type": "city",
            "name": "Rockaway",
            "full_name": "Rockaway, NJ",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -74.535818,
                            40.883484
                        ],
                        [
                            -74.535818,
                            40.911887
                        ],
                        [
                            -74.496615,
                            40.911887
                        ],
                        [
                            -74.496615,
                            40.883484
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "DShallzz",
                    "name": "Dana Shalit",
                    "id": 355831164,
                    "id_str": "355831164",
                    "indices": [
                        0,
                        9
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804936466400,
        "id_str": "407240804936466432",
        "text": "اووووه جميله من نيمار كره جميله من البرشاااااا",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1977632437,
            "id_str": "1977632437",
            "name": "خالد (( أبو يزيد ))",
            "screen_name": "kdmotairi",
            "location": "kdmotairi",
            "url": null,
            "description": "يازارع وردتك في القاع - غيرك شوكته في البور.",
            "protected": false,
            "followers_count": 356,
            "friends_count": 576,
            "listed_count": 0,
            "created_at": "Mon Oct 21 06:00:35 +0000 2013",
            "favourites_count": 161,
            "utc_offset": 10800,
            "time_zone": "Riyadh",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1648,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000637422907/588e83652183372f1097e765a762b604_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000637422907/588e83652183372f1097e765a762b604_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1977632437/1382350288",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                24.780829,
                46.8102732
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                46.8102732,
                24.780829
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804928086000,
        "id_str": "407240804928086016",
        "text": "عيااال بقي على الإجازة ٣٢ يوم من غير الجمعة والسبت 😍👍 '",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 904057626,
            "id_str": "904057626",
            "name": "برهومم #بلوك",
            "screen_name": "ibrahimsaud12",
            "location": "",
            "url": null,
            "description": "هحيهفقيد مافهمت الكلمة صح ؟ طيب اقراها من اليسار لليمين نفس الشي مافهمت ، أجل فولو وانت ساكت|instagram : ibrahimsaud12",
            "protected": false,
            "followers_count": 891,
            "friends_count": 430,
            "listed_count": 0,
            "created_at": "Thu Oct 25 14:59:21 +0000 2012",
            "favourites_count": 258,
            "utc_offset": 10800,
            "time_zone": "Kuwait",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7656,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000765708813/d508af616562da0ef2fe470db7ba4244_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000765708813/d508af616562da0ef2fe470db7ba4244_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/904057626/1385134894",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                24.57838294,
                46.64643516
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                46.64643516,
                24.57838294
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804949049340,
        "id_str": "407240804949049344",
        "text": "@m_swilem @m_mosa2 @alkzraj ههههههه في موسم 1408 انتهى الدور الاول بتصدر النصر بفارق ثمان نقاط وفي نهاية الدوري توج الهلال بطلا",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407203168117080060,
        "in_reply_to_status_id_str": "407203168117080065",
        "in_reply_to_user_id": 336397021,
        "in_reply_to_user_id_str": "336397021",
        "in_reply_to_screen_name": "m_swilem",
        "user": {
            "id": 860949877,
            "id_str": "860949877",
            "name": "فهد اليابسي",
            "screen_name": "fahad140372",
            "location": "اعشق السفر وأهوى القنص",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 37,
            "friends_count": 75,
            "listed_count": 0,
            "created_at": "Thu Oct 04 06:14:42 +0000 2012",
            "favourites_count": 5,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 716,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000649408014/e5721e8b6c4bebf1c77c16ea3f4da0d8_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000649408014/e5721e8b6c4bebf1c77c16ea3f4da0d8_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/860949877/1349467625",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                23.639169,
                46.505927
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                46.505927,
                23.639169
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "m_swilem",
                    "name": "محمد السويلم",
                    "id": 336397021,
                    "id_str": "336397021",
                    "indices": [
                        0,
                        9
                    ]
                },
                {
                    "screen_name": "m_mosa2",
                    "name": "محمد الحنتوشي",
                    "id": 1392756194,
                    "id_str": "1392756194",
                    "indices": [
                        10,
                        18
                    ]
                },
                {
                    "screen_name": "alkzraj",
                    "name": "عبدالرحيم الخزرج",
                    "id": 462955528,
                    "id_str": "462955528",
                    "indices": [
                        19,
                        27
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804726767600,
        "id_str": "407240804726767616",
        "text": "' its okay i think your a whore too:*",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1141022528,
            "id_str": "1141022528",
            "name": "Chloe Petrie",
            "screen_name": "chloepetrie_",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 243,
            "friends_count": 688,
            "listed_count": 0,
            "created_at": "Fri Feb 01 23:54:16 +0000 2013",
            "favourites_count": 195,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 485,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000726344032/422dbc203f542854d731ad80c9b68228_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000726344032/422dbc203f542854d731ad80c9b68228_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1141022528/1382958129",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.95105165,
                -55.66918147
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -55.66918147,
                48.95105165
            ]
        },
        "place": {
            "id": "47bb0edd0532343e",
            "url": "https://api.twitter.com/1.1/geo/id/47bb0edd0532343e.json",
            "place_type": "city",
            "name": "Division No. 6",
            "full_name": "Division No. 6, Newfoundland and Labrador",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -57.969417,
                            48.223019
                        ],
                        [
                            -57.969417,
                            49.356428
                        ],
                        [
                            -54.231142,
                            49.356428
                        ],
                        [
                            -54.231142,
                            48.223019
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804940652540,
        "id_str": "407240804940652544",
        "text": "@nsmandy_ cê conseguiu entrar?",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240683477405700,
        "in_reply_to_status_id_str": "407240683477405696",
        "in_reply_to_user_id": 432069263,
        "in_reply_to_user_id_str": "432069263",
        "in_reply_to_screen_name": "nsmandy_",
        "user": {
            "id": 268510542,
            "id_str": "268510542",
            "name": "thay ",
            "screen_name": "thaytoledo_",
            "location": "",
            "url": null,
            "description": "you're the smile on my face, i love you to the moon and back @justinbieber! Believe 02.11.13 ♥ | [FDG's]",
            "protected": false,
            "followers_count": 774,
            "friends_count": 324,
            "listed_count": 0,
            "created_at": "Fri Mar 18 22:53:55 +0000 2011",
            "favourites_count": 2162,
            "utc_offset": -10800,
            "time_zone": "Santiago",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 112680,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1A1B1F",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000109329542/f46daeb081f82647a02c8fd17c199f14.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000109329542/f46daeb081f82647a02c8fd17c199f14.png",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000813551738/8fb824c74d4894dcfd867e12bab935af_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000813551738/8fb824c74d4894dcfd867e12bab935af_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/268510542/1383609616",
            "profile_link_color": "4D494B",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "8C8C8C",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -23.5036542,
                -46.60857707
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -46.60857707,
                -23.5036542
            ]
        },
        "place": {
            "id": "68e019afec7d0ba5",
            "url": "https://api.twitter.com/1.1/geo/id/68e019afec7d0ba5.json",
            "place_type": "city",
            "name": "São Paulo",
            "full_name": "São Paulo, São Paulo",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -46.826038999999994,
                            -24.008813999999997
                        ],
                        [
                            -46.826038999999994,
                            -23.356792
                        ],
                        [
                            -46.365052,
                            -23.356792
                        ],
                        [
                            -46.365052,
                            -24.008813999999997
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "nsmandy_",
                    "name": "Mandy ⚓",
                    "id": 432069263,
                    "id_str": "432069263",
                    "indices": [
                        0,
                        9
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804843810800,
        "id_str": "407240804843810817",
        "text": "You dropped that?!?!?",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 626024685,
            "id_str": "626024685",
            "name": "Danica Jungerman",
            "screen_name": "Danimals_10",
            "location": "Corvallis, Oregon",
            "url": null,
            "description": "Red Sox. Harry Potter. Sigma Kappa. Oregon State University. Taken by @DrewBushness",
            "protected": false,
            "followers_count": 196,
            "friends_count": 314,
            "listed_count": 0,
            "created_at": "Tue Jul 03 22:29:36 +0000 2012",
            "favourites_count": 2671,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2379,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0F1014",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000004692390/47b53e493a368148a83bd42089605410.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000004692390/47b53e493a368148a83bd42089605410.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000271012833/6f4baf1ea80b6b0dfdaf1e20c952b7c5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000271012833/6f4baf1ea80b6b0dfdaf1e20c952b7c5_normal.jpeg",
            "profile_link_color": "D1042A",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "413FBF",
            "profile_text_color": "2F7CC9",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                45.37591222,
                -122.62562116
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -122.62562116,
                45.37591222
            ]
        },
        "place": {
            "id": "2ea8f95d7d008ab5",
            "url": "https://api.twitter.com/1.1/geo/id/2ea8f95d7d008ab5.json",
            "place_type": "city",
            "name": "West Linn",
            "full_name": "West Linn, OR",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -122.677414,
                            45.337142
                        ],
                        [
                            -122.677414,
                            45.400272
                        ],
                        [
                            -122.60279,
                            45.400272
                        ],
                        [
                            -122.60279,
                            45.337142
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805053915140,
        "id_str": "407240805053915136",
        "text": "Just wanna use my new hockey stick",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 505264211,
            "id_str": "505264211",
            "name": "mav & goose",
            "screen_name": "Dev_Holder",
            "location": "sus island b(ased) major",
            "url": null,
            "description": "i love sydney.",
            "protected": false,
            "followers_count": 161,
            "friends_count": 153,
            "listed_count": 0,
            "created_at": "Mon Feb 27 01:47:28 +0000 2012",
            "favourites_count": 768,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4016,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000792007198/18ae81cd61065fdb17c46d49c5cb8655_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000792007198/18ae81cd61065fdb17c46d49c5cb8655_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/505264211/1379302524",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                44.33401379,
                -78.32447861
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -78.32447861,
                44.33401379
            ]
        },
        "place": {
            "id": "4a00547cb6cf3709",
            "url": "https://api.twitter.com/1.1/geo/id/4a00547cb6cf3709.json",
            "place_type": "city",
            "name": "Peterborough",
            "full_name": "Peterborough, Ontario",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -78.655034,
                            44.082240999999996
                        ],
                        [
                            -78.655034,
                            44.914791
                        ],
                        [
                            -77.72707299999999,
                            44.914791
                        ],
                        [
                            -77.72707299999999,
                            44.082240999999996
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804923473900,
        "id_str": "407240804923473920",
        "text": "سلام اللہ يا دارٍ تموت بحبها الاوطآن ، سكنها شعبٍ يردد بكل الكون نفديهآ ♡",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1551656419,
            "id_str": "1551656419",
            "name": "Aisha AlMan9oori",
            "screen_name": "3awshko",
            "location": "AD",
            "url": null,
            "description": "life is short enjoy your coffee ♡",
            "protected": false,
            "followers_count": 72,
            "friends_count": 113,
            "listed_count": 0,
            "created_at": "Thu Jun 27 22:20:40 +0000 2013",
            "favourites_count": 4,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 592,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000362405687/831e17c72bbf4ee19db8becea291b32f_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000362405687/831e17c72bbf4ee19db8becea291b32f_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1551656419/1377501632",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                24.4361464,
                54.438058
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                54.438058,
                24.4361464
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "none",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805087461400,
        "id_str": "407240805087461376",
        "text": "Safari arasi :)) (@ İş Turkuaz Evleri Sitesi w/ @basaakvrl @murat_tuna26) [pic]: http://t.co/RPv9DjK0Cn",
        "source": "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 111124018,
            "id_str": "111124018",
            "name": "GÜLAY GÜLAY",
            "screen_name": "gulaygly",
            "location": "",
            "url": null,
            "description": "NE MUTLU TÜRKÜM DİYENE",
            "protected": false,
            "followers_count": 22,
            "friends_count": 77,
            "listed_count": 0,
            "created_at": "Wed Feb 03 22:01:20 +0000 2010",
            "favourites_count": 3,
            "utc_offset": -10800,
            "time_zone": "Greenland",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 953,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000249451397/caba764f538cba536eceefbd28e45189_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000249451397/caba764f538cba536eceefbd28e45189_normal.jpeg",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.90103927,
                32.62611999
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                32.62611999,
                39.90103927
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Turkey",
            "full_name": "Turkey",
            "country_code": "TR",
            "country": "Turkey",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/RPv9DjK0Cn",
                    "expanded_url": "http://4sq.com/1cg1tZA",
                    "display_url": "4sq.com/1cg1tZA",
                    "indices": [
                        81,
                        103
                    ]
                }
            ],
            "user_mentions": [
                {
                    "screen_name": "basaakvrl",
                    "name": "Başak Vural",
                    "id": 1395265315,
                    "id_str": "1395265315",
                    "indices": [
                        48,
                        58
                    ]
                },
                {
                    "screen_name": "murat_tuna26",
                    "name": "Murat TUNA",
                    "id": 1096228404,
                    "id_str": "1096228404",
                    "indices": [
                        59,
                        72
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805074870300,
        "id_str": "407240805074870273",
        "text": "Cosa parlo a fare con voi che non sapete neanche dov'è il Guyana. Cazzo di #pantofolaimagici",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 862615261,
            "id_str": "862615261",
            "name": "Mattia Mangiarotti",
            "screen_name": "Bis_Stecca",
            "location": "Milano, Mi - No Compromise",
            "url": "http://www.paullumviaggi.it",
            "description": null,
            "protected": false,
            "followers_count": 58,
            "friends_count": 109,
            "listed_count": 0,
            "created_at": "Fri Oct 05 06:26:57 +0000 2012",
            "favourites_count": 306,
            "utc_offset": 3600,
            "time_zone": "Rome",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1977,
            "lang": "it",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/683825427/818e8dcfdac39f70c6fb2097fbc0d5ba.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/683825427/818e8dcfdac39f70c6fb2097fbc0d5ba.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000113628984/5067e3308280697f418828e995eafccf_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000113628984/5067e3308280697f418828e995eafccf_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/862615261/1373446252",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                45.41797039,
                9.40657892
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                9.40657892,
                45.41797039
            ]
        },
        "place": {
            "id": "45cd737629a8399b",
            "url": "https://api.twitter.com/1.1/geo/id/45cd737629a8399b.json",
            "place_type": "city",
            "name": "Paullo",
            "full_name": "Paullo, Milano",
            "country_code": "IT",
            "country": "Italia",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            9.3829361,
                            45.3907733
                        ],
                        [
                            9.3829361,
                            45.438204
                        ],
                        [
                            9.4254736,
                            45.438204
                        ],
                        [
                            9.4254736,
                            45.3907733
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "pantofolaimagici",
                    "indices": [
                        75,
                        92
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "it"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804218839040,
        "id_str": "407240804218839040",
        "text": "The other dumbass award goes too http://t.co/dcC1LuK67Y",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 285927486,
            "id_str": "285927486",
            "name": "dreamerr",
            "screen_name": "AridonHiseni",
            "location": "",
            "url": null,
            "description": "#dreambig\n289 442 6856 \nSaltfleet / 16",
            "protected": false,
            "followers_count": 609,
            "friends_count": 427,
            "listed_count": 0,
            "created_at": "Fri Apr 22 01:39:49 +0000 2011",
            "favourites_count": 6805,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9883,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000772428883/049b016896ec3ac069da69ff2257da74_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000772428883/049b016896ec3ac069da69ff2257da74_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/285927486/1384398839",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                43.18986204,
                -79.78350664
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -79.78350664,
                43.18986204
            ]
        },
        "place": {
            "id": "1ae2bdcee87aaf17",
            "url": "https://api.twitter.com/1.1/geo/id/1ae2bdcee87aaf17.json",
            "place_type": "city",
            "name": "Hamilton",
            "full_name": "Hamilton, Ontario",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -80.248423,
                            43.050553
                        ],
                        [
                            -80.248423,
                            43.470838
                        ],
                        [
                            -79.57861799999999,
                            43.470838
                        ],
                        [
                            -79.57861799999999,
                            43.050553
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240804147544060,
                    "id_str": "407240804147544064",
                    "indices": [
                        33,
                        55
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWo1CQAA4OVL.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWo1CQAA4OVL.jpg",
                    "url": "http://t.co/dcC1LuK67Y",
                    "display_url": "pic.twitter.com/dcC1LuK67Y",
                    "expanded_url": "http://twitter.com/AridonHiseni/status/407240804218839040/photo/1",
                    "type": "photo",
                    "sizes": {
                        "large": {
                            "w": 640,
                            "h": 960,
                            "resize": "fit"
                        },
                        "medium": {
                            "w": 600,
                            "h": 900,
                            "resize": "fit"
                        },
                        "small": {
                            "w": 340,
                            "h": 510,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804789649400,
        "id_str": "407240804789649408",
        "text": "Bien athletic jugando de tu a tu",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 445437461,
            "id_str": "445437461",
            "name": "XVIII ❤",
            "screen_name": "J1alcaide",
            "location": "",
            "url": null,
            "description": "Insieme per sempre ❤  // #goalkeeper   KASUKABE !!",
            "protected": false,
            "followers_count": 404,
            "friends_count": 339,
            "listed_count": 0,
            "created_at": "Sat Dec 24 11:53:27 +0000 2011",
            "favourites_count": 294,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 21014,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000025073879/793e0c802080d191cbe5fa5e023e0fdf.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000025073879/793e0c802080d191cbe5fa5e023e0fdf.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000600367872/99e1e63acb2fa10f49ff8bcf7f4f89a7_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000600367872/99e1e63acb2fa10f49ff8bcf7f4f89a7_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/445437461/1384280659",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                36.7098821,
                -4.4482167
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -4.4482167,
                36.7098821
            ]
        },
        "place": {
            "id": "507a015cba6ef518",
            "url": "https://api.twitter.com/1.1/geo/id/507a015cba6ef518.json",
            "place_type": "city",
            "name": "Málaga",
            "full_name": "Málaga, Málaga",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -4.5879284,
                            36.6355853
                        ],
                        [
                            -4.5879284,
                            36.8941705
                        ],
                        [
                            -4.2601339,
                            36.8941705
                        ],
                        [
                            -4.2601339,
                            36.6355853
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805112229900,
        "id_str": "407240805112229888",
        "text": "Au lit tellement HS, rhume de merde. #dodotime #malade",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 422022266,
            "id_str": "422022266",
            "name": " Ana ",
            "screen_name": "WoodstockAna",
            "location": "",
            "url": "http://facebook.com/Woodstock.Ana",
            "description": "Étudiante - 21ans - Vitré/Rennes",
            "protected": false,
            "followers_count": 147,
            "friends_count": 542,
            "listed_count": 1,
            "created_at": "Sat Nov 26 18:07:26 +0000 2011",
            "favourites_count": 38,
            "utc_offset": 3600,
            "time_zone": "Paris",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2960,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "F7F7F7",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000119541999/5340056596853232e5a58f3bcd47fdc2.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000119541999/5340056596853232e5a58f3bcd47fdc2.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000624110603/e769cf9454407101a693ac675ad1286d_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000624110603/e769cf9454407101a693ac675ad1286d_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/422022266/1384806817",
            "profile_link_color": "E62020",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "3c595899dda3b951",
            "url": "https://api.twitter.com/1.1/geo/id/3c595899dda3b951.json",
            "place_type": "city",
            "name": "Vitré",
            "full_name": "Vitré, Ille-et-Vilaine",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -1.2492527,
                            48.0748755
                        ],
                        [
                            -1.2492527,
                            48.1463076
                        ],
                        [
                            -1.1448923,
                            48.1463076
                        ],
                        [
                            -1.1448923,
                            48.0748755
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "dodotime",
                    "indices": [
                        37,
                        46
                    ]
                },
                {
                    "text": "malade",
                    "indices": [
                        47,
                        54
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804852187140,
        "id_str": "407240804852187136",
        "text": "can't get enough of Hazza Potter this weekend 👳💫",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 597589538,
            "id_str": "597589538",
            "name": "rhɩαnnon~",
            "screen_name": "_RhiannonGage",
            "location": "Scotland ",
            "url": null,
            "description": "~people may give up on you, but never give up on yourself~",
            "protected": false,
            "followers_count": 116,
            "friends_count": 117,
            "listed_count": 0,
            "created_at": "Sat Jun 02 17:26:16 +0000 2012",
            "favourites_count": 384,
            "utc_offset": 0,
            "time_zone": "Casablanca",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8205,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0099B9",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme4/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme4/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000717061036/0e138ae793912af6dc8b99422b6babfd_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000717061036/0e138ae793912af6dc8b99422b6babfd_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/597589538/1385131575",
            "profile_link_color": "0099B9",
            "profile_sidebar_border_color": "5ED4DC",
            "profile_sidebar_fill_color": "95E8EC",
            "profile_text_color": "3C3940",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                55.20367987,
                -3.31731454
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -3.31731454,
                55.20367987
            ]
        },
        "place": {
            "id": "7e01fd5dbfdd5fa0",
            "url": "https://api.twitter.com/1.1/geo/id/7e01fd5dbfdd5fa0.json",
            "place_type": "city",
            "name": "Dumfries and Galloway",
            "full_name": "Dumfries and Galloway, Dumfries and Galloway",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -5.192216,
                            54.631564
                        ],
                        [
                            -5.192216,
                            55.464043
                        ],
                        [
                            -2.857334,
                            55.464043
                        ],
                        [
                            -2.857334,
                            54.631564
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805015769100,
        "id_str": "407240805015769088",
        "text": "@grahamparley @ezralevant most ITO's xome with application to seal to protect integrity of investigation. Don't need to \"prove\" anything 1/2",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407236991814610940,
        "in_reply_to_status_id_str": "407236991814610944",
        "in_reply_to_user_id": 29270193,
        "in_reply_to_user_id_str": "29270193",
        "in_reply_to_screen_name": "grahamparley",
        "user": {
            "id": 627012374,
            "id_str": "627012374",
            "name": "Alex Burton",
            "screen_name": "AlexSBurton",
            "location": "Vancouver BC",
            "url": "http://alexburton.ca",
            "description": "Political activist, concerned citizen, Crown Prosecutor, Vancouver Kingsway Liberal President, Husband and father of two",
            "protected": false,
            "followers_count": 705,
            "friends_count": 1990,
            "listed_count": 9,
            "created_at": "Thu Jul 05 03:28:58 +0000 2012",
            "favourites_count": 3,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1929,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "F5F5F5",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/674584461/397680b33c00dd8550becc618e9073af.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/674584461/397680b33c00dd8550becc618e9073af.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/2671826666/bbc5189d015bd1a3c701395b447d6d11_normal.png",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/2671826666/bbc5189d015bd1a3c701395b447d6d11_normal.png",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/627012374/1349147110",
            "profile_link_color": "FF1F13",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                49.25591103,
                -123.10432903
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -123.10432903,
                49.25591103
            ]
        },
        "place": {
            "id": "216dd1bcf824f9f7",
            "url": "https://api.twitter.com/1.1/geo/id/216dd1bcf824f9f7.json",
            "place_type": "city",
            "name": "Greater Vancouver",
            "full_name": "Greater Vancouver, British Columbia",
            "country_code": "CA",
            "country": "Canada",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -123.73837499999999,
                            49.001920999999996
                        ],
                        [
                            -123.73837499999999,
                            49.574551
                        ],
                        [
                            -122.406655,
                            49.574551
                        ],
                        [
                            -122.406655,
                            49.001920999999996
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "grahamparley",
                    "name": "Graham Parley",
                    "id": 29270193,
                    "id_str": "29270193",
                    "indices": [
                        0,
                        13
                    ]
                },
                {
                    "screen_name": "ezralevant",
                    "name": "Ezra Levant",
                    "id": 20878297,
                    "id_str": "20878297",
                    "indices": [
                        14,
                        25
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805280415740,
        "id_str": "407240805280415744",
        "text": "Meus olhos estão ardendo bagarai",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 183721529,
            "id_str": "183721529",
            "name": "caroline",
            "screen_name": "CarolRucci",
            "location": "Haas  ♥",
            "url": "http://instagram.com/whycaroles",
            "description": null,
            "protected": false,
            "followers_count": 195,
            "friends_count": 80,
            "listed_count": 2,
            "created_at": "Fri Aug 27 18:42:02 +0000 2010",
            "favourites_count": 1138,
            "utc_offset": -10800,
            "time_zone": "Santiago",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 33983,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FCFCFC",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000063418394/c3d7a5a549bab044506b12d9e863d4e6.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000063418394/c3d7a5a549bab044506b12d9e863d4e6.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000683280186/f4f81a46eabed3a54d0bade126292505_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000683280186/f4f81a46eabed3a54d0bade126292505_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/183721529/1385017464",
            "profile_link_color": "B1B3B3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "000000",
            "profile_text_color": "A306A3",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -25.3575261,
                -49.2731523
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -49.2731523,
                -25.3575261
            ]
        },
        "place": {
            "id": "6d5542f8d837770d",
            "url": "https://api.twitter.com/1.1/geo/id/6d5542f8d837770d.json",
            "place_type": "city",
            "name": "Curitiba",
            "full_name": "Curitiba, Paraná",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -49.3916434,
                            -25.6447517
                        ],
                        [
                            -49.3916434,
                            -25.3457471
                        ],
                        [
                            -49.1851531,
                            -25.3457471
                        ],
                        [
                            -49.1851531,
                            -25.6447517
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805074890750,
        "id_str": "407240805074890752",
        "text": "“@1DAlert: Zayn have apparently just arrived at the Premiere!!!” spero non abbia portato il cane",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407236363780894700,
        "in_reply_to_status_id_str": "407236363780894721",
        "in_reply_to_user_id": 612924569,
        "in_reply_to_user_id_str": "612924569",
        "in_reply_to_screen_name": "1DAlert",
        "user": {
            "id": 562958733,
            "id_str": "562958733",
            "name": "",
            "screen_name": "zaysmirk",
            "location": "",
            "url": null,
            "description": "zayn over everything and everyone",
            "protected": false,
            "followers_count": 2686,
            "friends_count": 1116,
            "listed_count": 12,
            "created_at": "Wed Apr 25 13:22:48 +0000 2012",
            "favourites_count": 4002,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 40190,
            "lang": "it",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000806562463/da62f102d2c2be4ab141c1786d6c469e_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000806562463/da62f102d2c2be4ab141c1786d6c469e_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/562958733/1385739698",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.91802455,
                12.52427055
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                12.52427055,
                41.91802455
            ]
        },
        "place": {
            "id": "7d588036fe12e124",
            "url": "https://api.twitter.com/1.1/geo/id/7d588036fe12e124.json",
            "place_type": "city",
            "name": "Roma",
            "full_name": "Roma, Roma",
            "country_code": "IT",
            "country": "Italia",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            12.2344266,
                            41.6558738
                        ],
                        [
                            12.2344266,
                            42.140958999999995
                        ],
                        [
                            12.8558641,
                            42.140958999999995
                        ],
                        [
                            12.8558641,
                            41.6558738
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "1DAlert",
                    "name": "1DAlert",
                    "id": 612924569,
                    "id_str": "612924569",
                    "indices": [
                        1,
                        9
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805381062660,
        "id_str": "407240805381062656",
        "text": "Asi como cuando quieres salir en boxer a tu sala pero tu hermana ha traído a todos sus amigos para hacer un trabajo... YA ASI!",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 338091140,
            "id_str": "338091140",
            "name": "David Ashcallay",
            "screen_name": "davidashcallay",
            "location": "peru",
            "url": null,
            "description": "26, single with so many plans but not enough time...",
            "protected": false,
            "followers_count": 331,
            "friends_count": 430,
            "listed_count": 1,
            "created_at": "Tue Jul 19 02:21:15 +0000 2011",
            "favourites_count": 2639,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 28136,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C6E2EE",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme2/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme2/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000454518993/ebbae0286aa5d2f18d191262c80a1718_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000454518993/ebbae0286aa5d2f18d191262c80a1718_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/338091140/1378218414",
            "profile_link_color": "1F98C7",
            "profile_sidebar_border_color": "C6E2EE",
            "profile_sidebar_fill_color": "DAECF4",
            "profile_text_color": "663B12",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -12.0589203,
                -77.0930638
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -77.0930638,
                -12.0589203
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805129400300,
        "id_str": "407240805129400320",
        "text": "Necessiiiitaba verle despues de todo ! Te quiero muchito 😊",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1320436964,
            "id_str": "1320436964",
            "name": "12.♥",
            "screen_name": "feeelisa",
            "location": "1D",
            "url": null,
            "description": "SOY TONTA Y AMO A @Palo_SmokerFace",
            "protected": false,
            "followers_count": 435,
            "friends_count": 386,
            "listed_count": 0,
            "created_at": "Mon Apr 01 14:17:07 +0000 2013",
            "favourites_count": 1424,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4877,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "DBC1EB",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/885008028/8ef6d0a8dbc0d63353ba4a0a0a5d954f.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/885008028/8ef6d0a8dbc0d63353ba4a0a0a5d954f.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000801868626/e05fb1d4790f1298f38a9d1a0e4c6819_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000801868626/e05fb1d4790f1298f38a9d1a0e4c6819_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1320436964/1385334153",
            "profile_link_color": "B300B3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.18853939,
                -3.77888516
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -3.77888516,
                40.18853939
            ]
        },
        "place": {
            "id": "867a5787c36d56e2",
            "url": "https://api.twitter.com/1.1/geo/id/867a5787c36d56e2.json",
            "place_type": "city",
            "name": "Torrejón de Velasco",
            "full_name": "Torrejón de Velasco, Madrid",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -3.8008493,
                            40.1319731
                        ],
                        [
                            -3.8008493,
                            40.2114903
                        ],
                        [
                            -3.6997428,
                            40.2114903
                        ],
                        [
                            -3.6997428,
                            40.1319731
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805129416700,
        "id_str": "407240805129416705",
        "text": "اكرهه الي تقول انتي ليش تروحين مع ذي ليش تسولفين مع ذيك ! اوكي صح انك صديقتي واغليك وكذا بس مو عاد تتحكمين بعلاقاتي الثانيه !",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 938846618,
            "id_str": "938846618",
            "name": "نيقا تشي شالاقا",
            "screen_name": "Maram_Alonzi",
            "location": "",
            "url": "http://ask.fm/Maram_Alonzi",
            "description": "My life : Super Junior , Food , Internet",
            "protected": false,
            "followers_count": 407,
            "friends_count": 270,
            "listed_count": 2,
            "created_at": "Sat Nov 10 11:21:32 +0000 2012",
            "favourites_count": 0,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7359,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1A1B1F",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000807360952/af58bd3e9a87628934169223d3fd30e5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000807360952/af58bd3e9a87628934169223d3fd30e5_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/938846618/1385594533",
            "profile_link_color": "2FC2EF",
            "profile_sidebar_border_color": "181A1E",
            "profile_sidebar_fill_color": "252429",
            "profile_text_color": "666666",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                27.4302181,
                41.584765
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                41.584765,
                27.4302181
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805028360200,
        "id_str": "407240805028360192",
        "text": "I'm so basic I just bought a pair of uggs",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 585644249,
            "id_str": "585644249",
            "name": "mollyyyy",
            "screen_name": "mollyy_wardd",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 436,
            "friends_count": 550,
            "listed_count": 0,
            "created_at": "Sun May 20 12:53:16 +0000 2012",
            "favourites_count": 6191,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 12818,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "B2DFDA",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme13/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme13/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000801749234/8b07417b165de2f1bd4cabfa294c48dd_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000801749234/8b07417b165de2f1bd4cabfa294c48dd_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/585644249/1383312455",
            "profile_link_color": "93A644",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                35.83493252,
                -83.57681748
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -83.57681748,
                35.83493252
            ]
        },
        "place": {
            "id": "7f7d58e5229c6b6c",
            "url": "https://api.twitter.com/1.1/geo/id/7f7d58e5229c6b6c.json",
            "place_type": "admin",
            "name": "Tennessee",
            "full_name": "Tennessee, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -90.31029799999999,
                            34.982924
                        ],
                        [
                            -90.31029799999999,
                            36.678118
                        ],
                        [
                            -81.6469,
                            36.678118
                        ],
                        [
                            -81.6469,
                            34.982924
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805208703000,
        "id_str": "407240805208702976",
        "text": "lembrei que nem adianta né",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 486606045,
            "id_str": "486606045",
            "name": "Gabi Metralha ϟ",
            "screen_name": "TraficoDorgas",
            "location": "Rio Grande do Sul",
            "url": "http://instagram.com/gabi_timm",
            "description": "Só os loucos sabem, que não existem distâncias no meu novo mundo !",
            "protected": false,
            "followers_count": 1770,
            "friends_count": 1549,
            "listed_count": 0,
            "created_at": "Wed Feb 08 13:28:25 +0000 2012",
            "favourites_count": 569,
            "utc_offset": -36000,
            "time_zone": "Hawaii",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 113048,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "090A0A",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000095075191/9c83691fd4ffd8d86bb70263c69b8c14.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000095075191/9c83691fd4ffd8d86bb70263c69b8c14.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000798066910/fb398bbd764bcc85a22ce421d92d34da_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000798066910/fb398bbd764bcc85a22ce421d92d34da_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/486606045/1381824630",
            "profile_link_color": "450778",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "736e927254a43b33",
            "url": "https://api.twitter.com/1.1/geo/id/736e927254a43b33.json",
            "place_type": "city",
            "name": "Tucunduva",
            "full_name": "Tucunduva, Rio Grande do Sul",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -54.5658817,
                            -27.715774
                        ],
                        [
                            -54.5658817,
                            -27.5474838
                        ],
                        [
                            -54.2840262,
                            -27.5474838
                        ],
                        [
                            -54.2840262,
                            -27.715774
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805330726900,
        "id_str": "407240805330726914",
        "text": "Quien es ese hombre que me mira y me desnuda!&gt;",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 538542323,
            "id_str": "538542323",
            "name": "Cami ♥",
            "screen_name": "CaamilaaAlcaraz",
            "location": "",
            "url": null,
            "description": "Soy inmensamente feliz, no me importa como pueda terminar mañana porque se lo que vivi hasta hoy♥",
            "protected": false,
            "followers_count": 144,
            "friends_count": 176,
            "listed_count": 0,
            "created_at": "Tue Mar 27 22:53:35 +0000 2012",
            "favourites_count": 36,
            "utc_offset": -36000,
            "time_zone": "Hawaii",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3754,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "280838",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000031444165/556818527a407b5004798104df953d73.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000031444165/556818527a407b5004798104df953d73.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000804312466/55570e51ab9441997571e0cff4ef9740_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000804312466/55570e51ab9441997571e0cff4ef9740_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/538542323/1385692229",
            "profile_link_color": "0000B3",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -36.0202214,
                -60.0126326
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -60.0126326,
                -36.0202214
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805406232600,
        "id_str": "407240805406232577",
        "text": "@NilsKaller i love you en ik hoop echt dat je me gaat volgen en ik vind he echt geweldig hoe je op het podium staat 💕",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": 523649807,
        "in_reply_to_user_id_str": "523649807",
        "in_reply_to_screen_name": "NilsKaller",
        "user": {
            "id": 392291017,
            "id_str": "392291017",
            "name": "manon",
            "screen_name": "Manonnemeis1",
            "location": "Den Bosch  ♥",
            "url": null,
            "description": "{2/5 mainstreet}",
            "protected": false,
            "followers_count": 223,
            "friends_count": 166,
            "listed_count": 0,
            "created_at": "Sun Oct 16 20:22:36 +0000 2011",
            "favourites_count": 47,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7707,
            "lang": "nl",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "F26A8C",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000124308239/856051dcf1e5e97791d11577d0a94437.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000124308239/856051dcf1e5e97791d11577d0a94437.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000802002801/b6ff18f9611cad0dfd1e18089ebda8c9_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000802002801/b6ff18f9611cad0dfd1e18089ebda8c9_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/392291017/1385666382",
            "profile_link_color": "B40B43",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "E5507E",
            "profile_text_color": "362720",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                51.73074192,
                5.32655167
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                5.32655167,
                51.73074192
            ]
        },
        "place": {
            "id": "a266ed083a48c0e2",
            "url": "https://api.twitter.com/1.1/geo/id/a266ed083a48c0e2.json",
            "place_type": "city",
            "name": "Den Bosch",
            "full_name": "Den Bosch, Brabant",
            "country_code": "NL",
            "country": "Nederland",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            5.2066704,
                            51.6640335
                        ],
                        [
                            5.2066704,
                            51.7621115
                        ],
                        [
                            5.4296852,
                            51.7621115
                        ],
                        [
                            5.4296852,
                            51.6640335
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "NilsKaller",
                    "name": "Nils Käller",
                    "id": 523649807,
                    "id_str": "523649807",
                    "indices": [
                        0,
                        11
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "nl"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805066502140,
        "id_str": "407240805066502144",
        "text": "Ben uyuyorum amk ıyi geceler",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 869348582,
            "id_str": "869348582",
            "name": "ÖmerOfficial ▲",
            "screen_name": "UcannAdamm",
            "location": "WU–TANG CLAN",
            "url": null,
            "description": "ENDORFİN HİP-HOP BREAK DANCER.",
            "protected": false,
            "followers_count": 7343,
            "friends_count": 7123,
            "listed_count": 0,
            "created_at": "Tue Oct 09 06:38:08 +0000 2012",
            "favourites_count": 20941,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1678,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000068217903/7e319404bb024175295cecfc546e7bc7.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000068217903/7e319404bb024175295cecfc546e7bc7.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000814514175/5df56925cc0ca65f1666cc2048d069cd_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000814514175/5df56925cc0ca65f1666cc2048d069cd_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/869348582/1375213929",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.0395192,
                28.8246013
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                28.8246013,
                41.0395192
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805540442100,
        "id_str": "407240805540442112",
        "text": "Going Walking Today.... Hopefully People Be Out &amp; About..  because It Feels Good Outsideeeee Today.  (:",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 626696880,
            "id_str": "626696880",
            "name": "Ny'Ashia ` R.  ",
            "screen_name": "Nae_Thugginqq",
            "location": "",
            "url": null,
            "description": "Hi , Im Ny'Ashia .\nFMOI: @Dimple_Face123 \nKik: 'Sincerely_IRDGAF..' \nEnjoy My Tweets ,",
            "protected": false,
            "followers_count": 1228,
            "friends_count": 1148,
            "listed_count": 0,
            "created_at": "Wed Jul 04 17:11:33 +0000 2012",
            "favourites_count": 365,
            "utc_offset": -36000,
            "time_zone": "Hawaii",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 37432,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000815837897/34f8ba9bf597b3ffd10c146dd1a2968a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000815837897/34f8ba9bf597b3ffd10c146dd1a2968a_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/626696880/1380494145",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                36.3044922,
                -76.2297268
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -76.2297268,
                36.3044922
            ]
        },
        "place": {
            "id": "9321754c451bd09c",
            "url": "https://api.twitter.com/1.1/geo/id/9321754c451bd09c.json",
            "place_type": "city",
            "name": "Elizabeth City",
            "full_name": "Elizabeth City, NC",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -76.303828,
                            36.262543
                        ],
                        [
                            -76.303828,
                            36.33672
                        ],
                        [
                            -76.181073,
                            36.33672
                        ],
                        [
                            -76.181073,
                            36.262543
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805380665340,
        "id_str": "407240805380665345",
        "text": "Ve bir insanın birini hem sevip hem de ona düşmanlık duyması kadar taşınması zor bir duygu ikiliği,inanın az bulunur..",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 265671787,
            "id_str": "265671787",
            "name": "Merve Duman ♕",
            "screen_name": "memiiderki",
            "location": "",
            "url": "http://instagram.com/mervedumannn",
            "description": null,
            "protected": false,
            "followers_count": 756,
            "friends_count": 422,
            "listed_count": 2,
            "created_at": "Sun Mar 13 23:56:59 +0000 2011",
            "favourites_count": 295,
            "utc_offset": -10800,
            "time_zone": "Greenland",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7914,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "DBE9ED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/851379673/a10e2ca3103eac01cd645b4ce22e3433.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/851379673/a10e2ca3103eac01cd645b4ce22e3433.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000800113368/fc2c3fa3b8c7436257b7dae6d4885ffa_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000800113368/fc2c3fa3b8c7436257b7dae6d4885ffa_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/265671787/1361588658",
            "profile_link_color": "CC3366",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFCCE9",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805091663900,
        "id_str": "407240805091663872",
        "text": "http://t.co/ZxDazSPd80",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 250116977,
            "id_str": "250116977",
            "name": "SafeOut",
            "screen_name": "FireEscapeLadde",
            "location": "Netherlands",
            "url": "http://www.safeout.nl",
            "description": "Fire Escape Ladder,een uitklapbare ladder die tegen gevel bevestigd word De oplossing voor evacuatie bij een BRAND,voor alle type Woningen,Studentenkamers,enz",
            "protected": false,
            "followers_count": 1212,
            "friends_count": 2001,
            "listed_count": 7,
            "created_at": "Thu Feb 10 13:15:52 +0000 2011",
            "favourites_count": 13,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1711,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "9AE4E8",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme16/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme16/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000734128603/5ac6bfead3b9dfd2bd4a24866d7ec513_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000734128603/5ac6bfead3b9dfd2bd4a24866d7ec513_normal.jpeg",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "BDDCAD",
            "profile_sidebar_fill_color": "DDFFCC",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                51.8869557,
                5.5997423
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                5.5997423,
                51.8869557
            ]
        },
        "place": {
            "id": "d6e739d0f09c7aa4",
            "url": "https://api.twitter.com/1.1/geo/id/d6e739d0f09c7aa4.json",
            "place_type": "city",
            "name": "Druten",
            "full_name": "Druten, Gelderland",
            "country_code": "NL",
            "country": "The Netherlands",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            5.5310874,
                            51.8362196
                        ],
                        [
                            5.5310874,
                            51.9018987
                        ],
                        [
                            5.684912,
                            51.9018987
                        ],
                        [
                            5.684912,
                            51.8362196
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240804949041150,
                    "id_str": "407240804949041152",
                    "indices": [
                        0,
                        22
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWr0IIAAoHCm.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWr0IIAAoHCm.jpg",
                    "url": "http://t.co/ZxDazSPd80",
                    "display_url": "pic.twitter.com/ZxDazSPd80",
                    "expanded_url": "http://twitter.com/FireEscapeLadde/status/407240805091663872/photo/1",
                    "type": "photo",
                    "sizes": {
                        "large": {
                            "w": 708,
                            "h": 720,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "small": {
                            "w": 340,
                            "h": 345,
                            "resize": "fit"
                        },
                        "medium": {
                            "w": 599,
                            "h": 610,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "und"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805448163300,
        "id_str": "407240805448163328",
        "text": "Oh merde 🙊🙈",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1243467752,
            "id_str": "1243467752",
            "name": "⚡️1.10.1❄️",
            "screen_name": "Indien92i",
            "location": "Banlieue 92i Antony 1.6.0",
            "url": "http://www.DonneurDeConseil.com",
            "description": "Indien Dur A Suivre Mais Facile A Follow #TeamIndia #TeamBooba #TeamKaaris #TeamPSG #T4E #TeamiPhone #92i Instagram / Kik / Snapchat : Indien92i ❄️1.10.1❄️",
            "protected": false,
            "followers_count": 868,
            "friends_count": 456,
            "listed_count": 0,
            "created_at": "Tue Mar 05 11:03:46 +0000 2013",
            "favourites_count": 475,
            "utc_offset": 3600,
            "time_zone": "Paris",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 26497,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000752348289/9b919968bab4866b0ba149c58371cde5_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000752348289/9b919968bab4866b0ba149c58371cde5_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1243467752/1385926080",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.74694902,
                2.29414863
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                2.29414863,
                48.74694902
            ]
        },
        "place": {
            "id": "fcc667170f65d83d",
            "url": "https://api.twitter.com/1.1/geo/id/fcc667170f65d83d.json",
            "place_type": "city",
            "name": "Antony",
            "full_name": "Antony, Hauts-de-Seine",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.2746001,
                            48.7293493
                        ],
                        [
                            2.2746001,
                            48.7724119
                        ],
                        [
                            2.3207372,
                            48.7724119
                        ],
                        [
                            2.3207372,
                            48.7293493
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "de"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804843794400,
        "id_str": "407240804843794432",
        "text": "So cute ;-; http://t.co/POGHGQOoop",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 717628387,
            "id_str": "717628387",
            "name": "Mini Crux",
            "screen_name": "RylieCrux",
            "location": "Westminster, Colorado, USA",
            "url": "http://www.furaffinity.net/user/ritzbitz/",
            "description": "Furry artist and Fursuit builder. Mini Cooper enthusiast. Ritz_Bitz on FA",
            "protected": false,
            "followers_count": 171,
            "friends_count": 188,
            "listed_count": 0,
            "created_at": "Thu Jul 26 07:36:19 +0000 2012",
            "favourites_count": 113,
            "utc_offset": -25200,
            "time_zone": "Arizona",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8141,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000662343733/7ef89efcbe09dd60a3f9159b755f589b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000662343733/7ef89efcbe09dd60a3f9159b755f589b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/717628387/1348584570",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.86108651,
                -105.07524974
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -105.07524974,
                39.86108651
            ]
        },
        "place": {
            "id": "3f871475c095f94f",
            "url": "https://api.twitter.com/1.1/geo/id/3f871475c095f94f.json",
            "place_type": "city",
            "name": "Westminster",
            "full_name": "Westminster, CO",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -105.165542,
                            39.817824
                        ],
                        [
                            -105.165542,
                            39.968186
                        ],
                        [
                            -104.987407,
                            39.968186
                        ],
                        [
                            -104.987407,
                            39.817824
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240804613124100,
                    "id_str": "407240804613124096",
                    "indices": [
                        12,
                        34
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWqkCcAAqcov.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWqkCcAAqcov.jpg",
                    "url": "http://t.co/POGHGQOoop",
                    "display_url": "pic.twitter.com/POGHGQOoop",
                    "expanded_url": "http://twitter.com/RylieCrux/status/407240804843794432/photo/1",
                    "type": "photo",
                    "sizes": {
                        "medium": {
                            "w": 600,
                            "h": 800,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "small": {
                            "w": 340,
                            "h": 453,
                            "resize": "fit"
                        },
                        "large": {
                            "w": 768,
                            "h": 1024,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "vi"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805322330100,
        "id_str": "407240805322330112",
        "text": "I'm at Şampiyon Kokoreç (Tekirdağ) http://t.co/4SSkzzzMEo",
        "source": "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 241513054,
            "id_str": "241513054",
            "name": "pinar",
            "screen_name": "pinar599",
            "location": "tekirdağ",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 257,
            "friends_count": 477,
            "listed_count": 0,
            "created_at": "Sat Jan 22 12:51:46 +0000 2011",
            "favourites_count": 4,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 631,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FCEBB6",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/488840721/x5323063ef8c0d92bbaf398290317c04.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/488840721/x5323063ef8c0d92bbaf398290317c04.png",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000237224944/70330a24bd9ef1bd29a9339e918a5b6d_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000237224944/70330a24bd9ef1bd29a9339e918a5b6d_normal.jpeg",
            "profile_link_color": "5E412F",
            "profile_sidebar_border_color": "F0A830",
            "profile_sidebar_fill_color": "78C0A8",
            "profile_text_color": "CE7834",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.98078051,
                27.5500633
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                27.5500633,
                40.98078051
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/4SSkzzzMEo",
                    "expanded_url": "http://4sq.com/1eEphG1",
                    "display_url": "4sq.com/1eEphG1",
                    "indices": [
                        35,
                        57
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805532065800,
        "id_str": "407240805532065792",
        "text": "Rams baby! (@ Candlestick Park w/ @stonezone) http://t.co/mgjUYAHoHl",
        "source": "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 35569745,
            "id_str": "35569745",
            "name": "gaby",
            "screen_name": "KushDoll",
            "location": "Long Beach, CA",
            "url": null,
            "description": "I am Wolverine's clone *snikt snikt*. Complete adoration for my Angels, Rams, & Ducks. Nerd. Gamer. HTID.",
            "protected": false,
            "followers_count": 1983,
            "friends_count": 2183,
            "listed_count": 91,
            "created_at": "Sun Apr 26 21:26:40 +0000 2009",
            "favourites_count": 117,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 13169,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1A1B1F",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000105629144/1d41d6b0e2028773c8b3120dee1cc96d.gif",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000105629144/1d41d6b0e2028773c8b3120dee1cc96d.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000652181823/5f856c52b88b47bfefc98f04e4c63101_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000652181823/5f856c52b88b47bfefc98f04e4c63101_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/35569745/1383175717",
            "profile_link_color": "D40404",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "343338",
            "profile_text_color": "786778",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                37.71345565,
                -122.38623619
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -122.38623619,
                37.71345565
            ]
        },
        "place": {
            "id": "2319e4e34315f3a7",
            "url": "https://api.twitter.com/1.1/geo/id/2319e4e34315f3a7.json",
            "place_type": "neighborhood",
            "name": "Bayview",
            "full_name": "Bayview, San Francisco",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -122.40828108,
                            37.708230959999995
                        ],
                        [
                            -122.40828108,
                            37.75042998
                        ],
                        [
                            -122.37784199999999,
                            37.75042998
                        ],
                        [
                            -122.37784199999999,
                            37.708230959999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/mgjUYAHoHl",
                    "expanded_url": "http://4sq.com/1eEph8X",
                    "display_url": "4sq.com/1eEph8X",
                    "indices": [
                        46,
                        68
                    ]
                }
            ],
            "user_mentions": [
                {
                    "screen_name": "StoneZone",
                    "name": "StoneZone",
                    "id": 19153663,
                    "id_str": "19153663",
                    "indices": [
                        34,
                        44
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805623939100,
        "id_str": "407240805623939072",
        "text": "acho que essas coisas de estudar de noite,não vai dar mais certo !",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 404514540,
            "id_str": "404514540",
            "name": "Gabriela",
            "screen_name": "Gabriella_vdk",
            "location": "Itapiranga-sc",
            "url": null,
            "description": "O ideal é ser feliz e não perfeito.",
            "protected": false,
            "followers_count": 588,
            "friends_count": 900,
            "listed_count": 1,
            "created_at": "Fri Nov 04 01:21:19 +0000 2011",
            "favourites_count": 59,
            "utc_offset": -7200,
            "time_zone": "Mid-Atlantic",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14406,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "DBE9ED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000122980213/15c8fdbf2997f4c74dfe5f2f23d34a2f.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000122980213/15c8fdbf2997f4c74dfe5f2f23d34a2f.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000811286814/4866f6ce1939e51782aedf95153f7d9b_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000811286814/4866f6ce1939e51782aedf95153f7d9b_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/404514540/1385308712",
            "profile_link_color": "F5256A",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "000305",
            "profile_text_color": "350438",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "050f17a0f61a0543",
            "url": "https://api.twitter.com/1.1/geo/id/050f17a0f61a0543.json",
            "place_type": "city",
            "name": "Águas de Chapecó",
            "full_name": "Águas de Chapecó, Santa Catarina",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -53.045154999999994,
                            -27.159373
                        ],
                        [
                            -53.045154999999994,
                            -26.946669999999997
                        ],
                        [
                            -52.895368999999995,
                            -26.946669999999997
                        ],
                        [
                            -52.895368999999995,
                            -27.159373
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240804374433800,
        "id_str": "407240804374433792",
        "text": "Sonra Yaren neden ders çalışmıyo?? http://t.co/6otZtQ7si4",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 736546681,
            "id_str": "736546681",
            "name": "Yaren Ayçiçek",
            "screen_name": "YarenAycicek",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 341,
            "friends_count": 171,
            "listed_count": 1,
            "created_at": "Sat Aug 04 11:02:50 +0000 2012",
            "favourites_count": 367,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3641,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/692470668/939da5ebfbf41afa7e0f9d46d1d67d7f.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/692470668/939da5ebfbf41afa7e0f9d46d1d67d7f.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000757668114/405757c4a8100a557a70e02ba3767348_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000757668114/405757c4a8100a557a70e02ba3767348_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/736546681/1384467764",
            "profile_link_color": "990014",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.4468447,
                31.7680945
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                31.7680945,
                41.4468447
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240804072439800,
                    "id_str": "407240804072439808",
                    "indices": [
                        35,
                        57
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPWojIQAAIrL-.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPWojIQAAIrL-.jpg",
                    "url": "http://t.co/6otZtQ7si4",
                    "display_url": "pic.twitter.com/6otZtQ7si4",
                    "expanded_url": "http://twitter.com/YarenAycicek/status/407240804374433792/photo/1",
                    "type": "photo",
                    "sizes": {
                        "small": {
                            "w": 340,
                            "h": 452,
                            "resize": "fit"
                        },
                        "medium": {
                            "w": 600,
                            "h": 798,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "large": {
                            "w": 1023,
                            "h": 1363,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805808889860,
        "id_str": "407240805808889856",
        "text": "Ah Enes o motor senin ecelin oldu be kardeşim yaktin hepimizin yüreklerini :(",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 2207509128,
            "id_str": "2207509128",
            "name": "Ebru Yüksel",
            "screen_name": "Nazendelifebru",
            "location": "Merkez ",
            "url": null,
            "description": "Kaprisli dağınık mutsuz hayattan bezmiş Canı sıkıldığında müzik dinleyen mutluluğu gitarında bulan biriyim canımı sıkan insanlar hepinizin canı cehenneme ...",
            "protected": false,
            "followers_count": 16,
            "friends_count": 39,
            "listed_count": 0,
            "created_at": "Thu Nov 21 17:10:12 +0000 2013",
            "favourites_count": 71,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 223,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000121734332/e2e1849d28c7edb00578205d34e0763c.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000121734332/e2e1849d28c7edb00578205d34e0763c.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000793752091/e9124c899d1f8a63dfeee2f66f9dde29_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000793752091/e9124c899d1f8a63dfeee2f66f9dde29_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/2207509128/1385055904",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.8125075,
                31.1151495
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                31.1151495,
                40.8125075
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805607571460,
        "id_str": "407240805607571456",
        "text": "@YAdgzel sarkinin ismi ayri bi komedi zaten hahahahaha",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240591177961500,
        "in_reply_to_status_id_str": "407240591177961473",
        "in_reply_to_user_id": 1468395116,
        "in_reply_to_user_id_str": "1468395116",
        "in_reply_to_screen_name": "YAdgzel",
        "user": {
            "id": 513522269,
            "id_str": "513522269",
            "name": "Yaren Cebeci",
            "screen_name": "Yaren_Cebeci",
            "location": "Vienna / Samsun",
            "url": null,
            "description": "Beşiktaş",
            "protected": false,
            "followers_count": 476,
            "friends_count": 390,
            "listed_count": 0,
            "created_at": "Sat Mar 03 19:44:42 +0000 2012",
            "favourites_count": 3844,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10405,
            "lang": "de",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/781153764/77eb04da4376713c27f9feda1e9bef36.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/781153764/77eb04da4376713c27f9feda1e9bef36.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000803209272/e2fde82be7da5b228096fae00e3963a0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000803209272/e2fde82be7da5b228096fae00e3963a0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/513522269/1359908083",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.1907197,
                16.3626421
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                16.3626421,
                48.1907197
            ]
        },
        "place": {
            "id": "9f659d51e5c5deae",
            "url": "https://api.twitter.com/1.1/geo/id/9f659d51e5c5deae.json",
            "place_type": "city",
            "name": "Wien",
            "full_name": "Wien, Wien",
            "country_code": "AT",
            "country": "Österreich",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            16.18218,
                            48.117666
                        ],
                        [
                            16.18218,
                            48.322573999999996
                        ],
                        [
                            16.577510999999998,
                            48.322573999999996
                        ],
                        [
                            16.577510999999998,
                            48.117666
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "YAdgzel",
                    "name": "Yaren",
                    "id": 1468395116,
                    "id_str": "1468395116",
                    "indices": [
                        0,
                        8
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:28 +0000 2013",
        "id": 407240805695631360,
        "id_str": "407240805695631360",
        "text": "О да, я в легла в кровать. Волшебный момент ^^",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1260420090,
            "id_str": "1260420090",
            "name": "Kseniya Rydukha",
            "screen_name": "RyduhaKseniya",
            "location": "",
            "url": "http://vk.com/id110340218",
            "description": null,
            "protected": false,
            "followers_count": 37,
            "friends_count": 38,
            "listed_count": 0,
            "created_at": "Mon Mar 11 21:17:23 +0000 2013",
            "favourites_count": 37,
            "utc_offset": 10800,
            "time_zone": "Minsk",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1173,
            "lang": "ru",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/812274783/233bb06fbc4af8201d9af13a67db4ca9.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/812274783/233bb06fbc4af8201d9af13a67db4ca9.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000758418623/a4fb1a536ec87b52e9a62f7e1d47494d_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000758418623/a4fb1a536ec87b52e9a62f7e1d47494d_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1260420090/1363124869",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                53.9290831,
                27.6314826
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                27.6314826,
                53.9290831
            ]
        },
        "place": {
            "id": "333a5811d6b0c1cb",
            "url": "https://api.twitter.com/1.1/geo/id/333a5811d6b0c1cb.json",
            "place_type": "country",
            "name": "Belarus",
            "full_name": "Belarus",
            "country_code": "BY",
            "country": "Belarus",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            23.179216999999998,
                            51.2626423
                        ],
                        [
                            23.179216999999998,
                            56.1717339
                        ],
                        [
                            32.794200000000004,
                            56.1717339
                        ],
                        [
                            32.794200000000004,
                            51.2626423
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ru"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808879108100,
        "id_str": "407240808879108096",
        "text": "Imagine meeting the man that does the voice for the bus. 'Stand clear, luggage doors operating'.",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 94171362,
            "id_str": "94171362",
            "name": "Morsmordre.",
            "screen_name": "RebeccahLouise",
            "location": "Ireland",
            "url": "http://rebeccahlouise.tumblr.com/",
            "description": "Instead of a face I have four arses.",
            "protected": false,
            "followers_count": 798,
            "friends_count": 532,
            "listed_count": 7,
            "created_at": "Wed Dec 02 20:42:14 +0000 2009",
            "favourites_count": 4486,
            "utc_offset": -7200,
            "time_zone": "Mid-Atlantic",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 26473,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme18/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme18/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000816546711/2e34323924199b7c423f01445e708529_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000816546711/2e34323924199b7c423f01445e708529_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/94171362/1385824565",
            "profile_link_color": "9E2B2B",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "C28A91",
            "profile_text_color": "6B326B",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                52.36129882,
                -7.57994196
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -7.57994196,
                52.36129882
            ]
        },
        "place": {
            "id": "2edf98027d556c5f",
            "url": "https://api.twitter.com/1.1/geo/id/2edf98027d556c5f.json",
            "place_type": "city",
            "name": "South Tipperary",
            "full_name": "South Tipperary, South Tipperary",
            "country_code": "IE",
            "country": "Ireland",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -8.4057899,
                            52.2013149
                        ],
                        [
                            -8.4057899,
                            52.7335849
                        ],
                        [
                            -7.3718273,
                            52.7335849
                        ],
                        [
                            -7.3718273,
                            52.2013149
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808753287200,
        "id_str": "407240808753287168",
        "text": "@dps2002 THAT IS AWESOME",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240731049594900,
        "in_reply_to_status_id_str": "407240731049594880",
        "in_reply_to_user_id": 88314089,
        "in_reply_to_user_id_str": "88314089",
        "in_reply_to_screen_name": "dps2002",
        "user": {
            "id": 50850603,
            "id_str": "50850603",
            "name": "Dupcros Gingernitz.™",
            "screen_name": "hayPENS",
            "location": "#BurghProud",
            "url": "http://www.heyyyyyfannnssss.blogspot.com/",
            "description": "Permanently inked my allegiance with the Pittsburgh Penguins in 2008. I like to write about sports.",
            "protected": false,
            "followers_count": 1119,
            "friends_count": 1052,
            "listed_count": 15,
            "created_at": "Fri Jun 26 00:56:11 +0000 2009",
            "favourites_count": 16294,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 32070,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/651146322/c1y99okn9zzcro3bhc9h.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/651146322/c1y99okn9zzcro3bhc9h.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000668128914/783de3c39b9a8682ae9823b0aa975c5c_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000668128914/783de3c39b9a8682ae9823b0aa975c5c_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/50850603/1381628699",
            "profile_link_color": "988822",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "F3F3F3",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.29904165,
                -78.93382153
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -78.93382153,
                40.29904165
            ]
        },
        "place": {
            "id": "9a7c79750cb70faf",
            "url": "https://api.twitter.com/1.1/geo/id/9a7c79750cb70faf.json",
            "place_type": "city",
            "name": "Elim",
            "full_name": "Elim, PA",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -78.965732,
                            40.283215
                        ],
                        [
                            -78.965732,
                            40.312975
                        ],
                        [
                            -78.915931,
                            40.312975
                        ],
                        [
                            -78.915931,
                            40.283215
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "dps2002",
                    "name": "David Straub",
                    "id": 88314089,
                    "id_str": "88314089",
                    "indices": [
                        0,
                        8
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808727707650,
        "id_str": "407240808727707648",
        "text": "\"Muter2 dihatikamuu :$ @Marsriansyah: Yo ke mano be \"@puputJe: \"Ciee kehilangan :$ @Marsriansyah: @puputJe ke mano lah putri ni eee\"\"\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 106391827,
            "id_str": "106391827",
            "name": "Tuan Putri",
            "screen_name": "puputJe",
            "location": "",
            "url": null,
            "description": "Partner Life of Marsriansyah♥",
            "protected": false,
            "followers_count": 396,
            "friends_count": 222,
            "listed_count": 3,
            "created_at": "Tue Jan 19 12:05:14 +0000 2010",
            "favourites_count": 53,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 13375,
            "lang": "id",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "ACDED6",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000111893299/bebf7fb2cbfa64b102dcfeb4ac376b99.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000111893299/bebf7fb2cbfa64b102dcfeb4ac376b99.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000814899809/42507916c1d5e3692b15ca941e8ce8ca_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000814899809/42507916c1d5e3692b15ca941e8ce8ca_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/106391827/1385736438",
            "profile_link_color": "038543",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "F6F6F6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -1.6208189,
                103.5615574
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                103.5615574,
                -1.6208189
            ]
        },
        "place": {
            "id": "404819eb1c5580d7",
            "url": "https://api.twitter.com/1.1/geo/id/404819eb1c5580d7.json",
            "place_type": "city",
            "name": "Jambi Luar Kota",
            "full_name": "Jambi Luar Kota, Muaro Jambi",
            "country_code": "ID",
            "country": "Indonesia",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            103.47953,
                            -1.754549
                        ],
                        [
                            103.47953,
                            -1.5379099999999999
                        ],
                        [
                            103.688751,
                            -1.5379099999999999
                        ],
                        [
                            103.688751,
                            -1.754549
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Marsriansyah",
                    "name": "Ansah",
                    "id": 1702084662,
                    "id_str": "1702084662",
                    "indices": [
                        23,
                        36
                    ]
                },
                {
                    "screen_name": "puputJe",
                    "name": "Tuan Putri",
                    "id": 106391827,
                    "id_str": "106391827",
                    "indices": [
                        53,
                        61
                    ]
                },
                {
                    "screen_name": "Marsriansyah",
                    "name": "Ansah",
                    "id": 1702084662,
                    "id_str": "1702084662",
                    "indices": [
                        83,
                        96
                    ]
                },
                {
                    "screen_name": "puputJe",
                    "name": "Tuan Putri",
                    "id": 106391827,
                    "id_str": "106391827",
                    "indices": [
                        98,
                        106
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "id"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808765874200,
        "id_str": "407240808765874177",
        "text": "Ya estoy me pensando olvidarte",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1548163927,
            "id_str": "1548163927",
            "name": "Daniel Calzada",
            "screen_name": "DaniCalzada61",
            "location": "",
            "url": null,
            "description": "LA PUTA JDC",
            "protected": false,
            "followers_count": 84,
            "friends_count": 119,
            "listed_count": 0,
            "created_at": "Wed Jun 26 12:56:46 +0000 2013",
            "favourites_count": 39,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 135,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000812755934/12248ef4a985ca99be4088071765589f_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000812755934/12248ef4a985ca99be4088071765589f_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1548163927/1384897628",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.640741,
                -4.7407228
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -4.7407228,
                41.640741
            ]
        },
        "place": {
            "id": "2afe3164f39d1b83",
            "url": "https://api.twitter.com/1.1/geo/id/2afe3164f39d1b83.json",
            "place_type": "city",
            "name": "Valladolid",
            "full_name": "Valladolid, Valladolid",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -4.928146,
                            41.5231077
                        ],
                        [
                            -4.928146,
                            41.8155527
                        ],
                        [
                            -4.6308818,
                            41.8155527
                        ],
                        [
                            -4.6308818,
                            41.5231077
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808883306500,
        "id_str": "407240808883306496",
        "text": "I really wish these niggas with gf leave me alone don't have time for the crap",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 317931425,
            "id_str": "317931425",
            "name": "ig. koko_got_cake",
            "screen_name": "ShutUp_N_Twatch",
            "location": "",
            "url": null,
            "description": "Diss me and you'll never hear a reply for it!",
            "protected": false,
            "followers_count": 263,
            "friends_count": 224,
            "listed_count": 0,
            "created_at": "Wed Jun 15 18:07:02 +0000 2011",
            "favourites_count": 305,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 17268,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "E6CAE6",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/432637498/marilyn-monroe---money.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/432637498/marilyn-monroe---money.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000816257849/66a9935c7d29a233c71e8e45785eac91_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000816257849/66a9935c7d29a233c71e8e45785eac91_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/317931425/1385915814",
            "profile_link_color": "E0B1E0",
            "profile_sidebar_border_color": "F0DAF0",
            "profile_sidebar_fill_color": "F2EDF2",
            "profile_text_color": "D6C5D6",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                34.68080691,
                -82.979939
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -82.979939,
                34.68080691
            ]
        },
        "place": {
            "id": "6057f1e35bcc6c20",
            "url": "https://api.twitter.com/1.1/geo/id/6057f1e35bcc6c20.json",
            "place_type": "admin",
            "name": "South Carolina",
            "full_name": "South Carolina, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -83.353928,
                            32.033454
                        ],
                        [
                            -83.353928,
                            35.21554
                        ],
                        [
                            -78.499301,
                            35.21554
                        ],
                        [
                            -78.499301,
                            32.033454
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808224796700,
        "id_str": "407240808224796672",
        "text": "@wtfsoares vai estudar",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240283332833300,
        "in_reply_to_status_id_str": "407240283332833281",
        "in_reply_to_user_id": 1286184277,
        "in_reply_to_user_id_str": "1286184277",
        "in_reply_to_screen_name": "wtfsoares",
        "user": {
            "id": 277533756,
            "id_str": "277533756",
            "name": "RIP Paul",
            "screen_name": "_andraderenan",
            "location": "Rio de Janeiro",
            "url": null,
            "description": "Quem se descreve se limita",
            "protected": false,
            "followers_count": 148,
            "friends_count": 106,
            "listed_count": 1,
            "created_at": "Tue Apr 05 15:21:56 +0000 2011",
            "favourites_count": 1427,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 12809,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "ACDED6",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000064519068/5641b3b992fc6f229776fe8ebdb799e4.gif",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000064519068/5641b3b992fc6f229776fe8ebdb799e4.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000794089954/c46f7343999cf373e92e02b4e7ce9ff8_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000794089954/c46f7343999cf373e92e02b4e7ce9ff8_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/277533756/1380419887",
            "profile_link_color": "FA8C05",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -22.84005279,
                -43.29557476
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -43.29557476,
                -22.84005279
            ]
        },
        "place": {
            "id": "97bcdfca1a2dca59",
            "url": "https://api.twitter.com/1.1/geo/id/97bcdfca1a2dca59.json",
            "place_type": "city",
            "name": "Rio de Janeiro",
            "full_name": "Rio de Janeiro, Rio de Janeiro",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -43.795449,
                            -23.083019999999998
                        ],
                        [
                            -43.795449,
                            -22.749043999999998
                        ],
                        [
                            -43.099381,
                            -22.749043999999998
                        ],
                        [
                            -43.099381,
                            -23.083019999999998
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "wtfsoares",
                    "name": "Fé acesa ✌️",
                    "id": 1286184277,
                    "id_str": "1286184277",
                    "indices": [
                        0,
                        10
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808685785100,
        "id_str": "407240808685785088",
        "text": "@ValorOjeda_ yes 😂",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240542003535900,
        "in_reply_to_status_id_str": "407240542003535873",
        "in_reply_to_user_id": 800981407,
        "in_reply_to_user_id_str": "800981407",
        "in_reply_to_screen_name": "ValorOjeda_",
        "user": {
            "id": 825495806,
            "id_str": "825495806",
            "name": " Unicorns ❤️",
            "screen_name": "15nataliee",
            "location": "",
            "url": null,
            "description": "Heat & Texans | Paris & London ✈️ | Karina is bae ❤️ | Sing for me & ill dance for you | #JustOneMoreTime",
            "protected": false,
            "followers_count": 492,
            "friends_count": 332,
            "listed_count": 2,
            "created_at": "Sat Sep 15 15:49:42 +0000 2012",
            "favourites_count": 2214,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 26001,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000811918920/94983ef631473dcf8ebb91c6d467f64a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000811918920/94983ef631473dcf8ebb91c6d467f64a_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/825495806/1385335786",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                29.7064022,
                -95.17394453
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -95.17394453,
                29.7064022
            ]
        },
        "place": {
            "id": "3e82edc94d5c5ce1",
            "url": "https://api.twitter.com/1.1/geo/id/3e82edc94d5c5ce1.json",
            "place_type": "city",
            "name": "Pasadena",
            "full_name": "Pasadena, TX",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -95.234542,
                            29.557836
                        ],
                        [
                            -95.234542,
                            29.739927
                        ],
                        [
                            -94.982683,
                            29.739927
                        ],
                        [
                            -94.982683,
                            29.557836
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "ValorOjeda_",
                    "name": "Valor(:",
                    "id": 800981407,
                    "id_str": "800981407",
                    "indices": [
                        0,
                        12
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "und"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808845545500,
        "id_str": "407240808845545472",
        "text": "HAVE YOURSLEF A BALL GAME ALSHON! #BearDown",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 248536964,
            "id_str": "248536964",
            "name": "Brandon Smith",
            "screen_name": "bubbagum5",
            "location": "Fort Wayne, Indiana",
            "url": null,
            "description": "Generic last name, Black nick-name.  Never saw a shot I didn't like. #hoosiernation",
            "protected": false,
            "followers_count": 201,
            "friends_count": 304,
            "listed_count": 0,
            "created_at": "Mon Feb 07 06:13:52 +0000 2011",
            "favourites_count": 350,
            "utc_offset": -14400,
            "time_zone": "Atlantic Time (Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2468,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/525578304/Pacers.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/525578304/Pacers.jpg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/344513261582748752/8b53ae09c8b3ef6eb63295a17f102136_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/344513261582748752/8b53ae09c8b3ef6eb63295a17f102136_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/248536964/1369500048",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.0591558,
                -85.26173861
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -85.26173861,
                41.0591558
            ]
        },
        "place": {
            "id": "c408ee05c408f612",
            "url": "https://api.twitter.com/1.1/geo/id/c408ee05c408f612.json",
            "place_type": "city",
            "name": "Aboite",
            "full_name": "Aboite, IN",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -85.337024,
                            41.001603
                        ],
                        [
                            -85.337024,
                            41.089723
                        ],
                        [
                            -85.226276,
                            41.089723
                        ],
                        [
                            -85.226276,
                            41.001603
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "BearDown",
                    "indices": [
                        34,
                        43
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808434499600,
        "id_str": "407240808434499584",
        "text": "Und wenn du es nicht verstehen kannst, dann sag ich nochmal damit du verstehst: ICH LIEBE DICH ♥ http://t.co/ZCOcPO37gx",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1596624362,
            "id_str": "1596624362",
            "name": "Carteira/Pequenina ♥",
            "screen_name": "daniiodioc",
            "location": "",
            "url": null,
            "description": "Daniela ||17 anos || Odivelas ♥|| Portugal ♥♥ || Alemanha :(",
            "protected": false,
            "followers_count": 79,
            "friends_count": 272,
            "listed_count": 0,
            "created_at": "Mon Jul 15 19:50:06 +0000 2013",
            "favourites_count": 480,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 2220,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0F0F0F",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000046801050/595d4e673c0e2b0ae50302867d47295d.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000046801050/595d4e673c0e2b0ae50302867d47295d.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000668639862/a862dd4ba892b1ab04325190a0a44bbb_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000668639862/a862dd4ba892b1ab04325190a0a44bbb_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1596624362/1383128162",
            "profile_link_color": "32BDE3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                51.0607554,
                7.0069114
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                7.0069114,
                51.0607554
            ]
        },
        "place": {
            "id": "4267d6645adb29a6",
            "url": "https://api.twitter.com/1.1/geo/id/4267d6645adb29a6.json",
            "place_type": "city",
            "name": "Leverkusen",
            "full_name": "Leverkusen, Leverkusen",
            "country_code": "DE",
            "country": "Alemanha",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            6.899146,
                            51.011133
                        ],
                        [
                            6.899146,
                            51.097148999999995
                        ],
                        [
                            7.116137999999999,
                            51.097148999999995
                        ],
                        [
                            7.116137999999999,
                            51.011133
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240808321257500,
                    "id_str": "407240808321257473",
                    "indices": [
                        97,
                        119
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPW4YIEAELaej.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPW4YIEAELaej.jpg",
                    "url": "http://t.co/ZCOcPO37gx",
                    "display_url": "pic.twitter.com/ZCOcPO37gx",
                    "expanded_url": "http://twitter.com/daniiodioc/status/407240808434499584/photo/1",
                    "type": "photo",
                    "sizes": {
                        "large": {
                            "w": 918,
                            "h": 1224,
                            "resize": "fit"
                        },
                        "medium": {
                            "w": 600,
                            "h": 800,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "small": {
                            "w": 340,
                            "h": 453,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "de"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809109782500,
        "id_str": "407240809109782528",
        "text": "I could go for a nice bud heavy right now",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 124447885,
            "id_str": "124447885",
            "name": "Tuco Salamanca",
            "screen_name": "Mike_304",
            "location": "Grafton,WV",
            "url": null,
            "description": "I'm Irie  ..#MoutaineerNation #Lakers #STL #Eagles",
            "protected": false,
            "followers_count": 540,
            "friends_count": 298,
            "listed_count": 0,
            "created_at": "Fri Mar 19 12:34:56 +0000 2010",
            "favourites_count": 753,
            "utc_offset": -18000,
            "time_zone": "Quito",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14341,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/888467178/35f170100cbd3ef575d35cacabbd3c7a.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/888467178/35f170100cbd3ef575d35cacabbd3c7a.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000681340366/6eac4fa3a022e3553dc28ae6c703e535_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000681340366/6eac4fa3a022e3553dc28ae6c703e535_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/124447885/1377567021",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.3469278,
                -80.0166896
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -80.0166896,
                39.3469278
            ]
        },
        "place": {
            "id": "bf5b7bb7177bd938",
            "url": "https://api.twitter.com/1.1/geo/id/bf5b7bb7177bd938.json",
            "place_type": "city",
            "name": "Grafton",
            "full_name": "Grafton, WV",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -80.043755,
                            39.322366
                        ],
                        [
                            -80.043755,
                            39.358394
                        ],
                        [
                            -79.983904,
                            39.358394
                        ],
                        [
                            -79.983904,
                            39.322366
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808996548600,
        "id_str": "407240808996548608",
        "text": "Et demain, personne ne verra rien. J'aurai un grand sourire, je dirai que je suis juste fatigué ou que je ne dors pas très bien.",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 407120238,
            "id_str": "407120238",
            "name": "bizzle ♥ ",
            "screen_name": "tiffdrauhl",
            "location": "Strasbourg BELIEVE TOUR 08/04",
            "url": null,
            "description": "@justinbieber .BELIEBERS.  Cody, Ariana, Alli, Tal, Keen'v, PZK, Carly, twist follows. #PLL  #BELIEBERS IS A PROMISE JACQUE RAE ♥",
            "protected": false,
            "followers_count": 19755,
            "friends_count": 17978,
            "listed_count": 41,
            "created_at": "Mon Nov 07 17:21:29 +0000 2011",
            "favourites_count": 20502,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 80489,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1A1B1F",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme9/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000785381029/839389aa086ad74768f32780a7a3ee1c_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000785381029/839389aa086ad74768f32780a7a3ee1c_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/407120238/1384958821",
            "profile_link_color": "8B59B3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "252429",
            "profile_text_color": "666666",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.9317744,
                7.8375689
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                7.8375689,
                48.9317744
            ]
        },
        "place": {
            "id": "11ae1f35700e86ee",
            "url": "https://api.twitter.com/1.1/geo/id/11ae1f35700e86ee.json",
            "place_type": "city",
            "name": "Merkwiller-Pechelbronn",
            "full_name": "Merkwiller-Pechelbronn, Bas-Rhin",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            7.8150322,
                            48.9155042
                        ],
                        [
                            7.8150322,
                            48.9426109
                        ],
                        [
                            7.8423245,
                            48.9426109
                        ],
                        [
                            7.8423245,
                            48.9155042
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809046478850,
        "id_str": "407240809046478848",
        "text": "-\n\"A vida é bela , aproveite cada minuto , poq o passado nn voltara \"",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 571334350,
            "id_str": "571334350",
            "name": " anderson s2",
            "screen_name": "Sioone_Maria",
            "location": "",
            "url": null,
            "description": "Sorriiaaa , o inimigo odeia isso ! Hehehe ;)",
            "protected": false,
            "followers_count": 289,
            "friends_count": 863,
            "listed_count": 0,
            "created_at": "Sat May 05 01:45:32 +0000 2012",
            "favourites_count": 17,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8303,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000816191864/87b91608472e6599958319164096dc45_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000816191864/87b91608472e6599958319164096dc45_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/571334350/1385911902",
            "profile_link_color": "F531AD",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "E3E2DE",
            "profile_text_color": "634047",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "f207b85be9f1513e",
            "url": "https://api.twitter.com/1.1/geo/id/f207b85be9f1513e.json",
            "place_type": "city",
            "name": "Recife",
            "full_name": "Recife, Pernambuco",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -35.019805,
                            -8.157554
                        ],
                        [
                            -35.019805,
                            -7.929652
                        ],
                        [
                            -34.858893,
                            -7.929652
                        ],
                        [
                            -34.858893,
                            -8.157554
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809168519200,
        "id_str": "407240809168519168",
        "text": "Roll up",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 360235877,
            "id_str": "360235877",
            "name": "Seth Nieves",
            "screen_name": "NievesSwag",
            "location": "",
            "url": null,
            "description": "Senior at William Fleming High School #Classof2014 #TeamGalaxyS4 #TeamLeo Follow me #TeamFollowback #TeamSneakerHead I Done Took Flight ✈✈✈",
            "protected": false,
            "followers_count": 226,
            "friends_count": 327,
            "listed_count": 0,
            "created_at": "Mon Aug 22 22:21:12 +0000 2011",
            "favourites_count": 147,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4667,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000790641318/885be83c01487ce32ac158be2e361e01_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000790641318/885be83c01487ce32ac158be2e361e01_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/360235877/1384316910",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                37.3047267,
                -79.9654015
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -79.9654015,
                37.3047267
            ]
        },
        "place": {
            "id": "9d63050d3d33d32f",
            "url": "https://api.twitter.com/1.1/geo/id/9d63050d3d33d32f.json",
            "place_type": "city",
            "name": "Roanoke",
            "full_name": "Roanoke, VA",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -80.037598,
                            37.211227
                        ],
                        [
                            -80.037598,
                            37.337417
                        ],
                        [
                            -79.877487,
                            37.337417
                        ],
                        [
                            -79.877487,
                            37.211227
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809223049200,
        "id_str": "407240809223049217",
        "text": "Los simpson",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1594922226,
            "id_str": "1594922226",
            "name": "SKVM mi religion",
            "screen_name": "28Bonetti",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 67,
            "friends_count": 57,
            "listed_count": 0,
            "created_at": "Mon Jul 15 04:14:32 +0000 2013",
            "favourites_count": 44,
            "utc_offset": -10800,
            "time_zone": "Buenos Aires",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3856,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000813957934/3f895617d045de370b935a7316a959d1_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000813957934/3f895617d045de370b935a7316a959d1_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1594922226/1384283985",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -31.6312344,
                -60.7027381
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -60.7027381,
                -31.6312344
            ]
        },
        "place": {
            "id": "1b107df3ccc0aaa1",
            "url": "https://api.twitter.com/1.1/geo/id/1b107df3ccc0aaa1.json",
            "place_type": "country",
            "name": "Brasil",
            "full_name": "Brasil",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -73.99148199999999,
                            -33.750575999999995
                        ],
                        [
                            -73.99148199999999,
                            5.27192
                        ],
                        [
                            -32.378186,
                            5.27192
                        ],
                        [
                            -32.378186,
                            -33.750575999999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240808987770900,
        "id_str": "407240808987770880",
        "text": "@VictorAndradeuv vem c o paivaaaaaaaaaaaa",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240678284857340,
        "in_reply_to_status_id_str": "407240678284857344",
        "in_reply_to_user_id": 1873260762,
        "in_reply_to_user_id_str": "1873260762",
        "in_reply_to_screen_name": "VictorAndradeuv",
        "user": {
            "id": 316526052,
            "id_str": "316526052",
            "name": "ousadia pura △‎",
            "screen_name": "oedebss",
            "location": "http://instagram.com/pqdebss",
            "url": null,
            "description": "''Ela é um poço de qualidade e defeito..''",
            "protected": false,
            "followers_count": 960,
            "friends_count": 1568,
            "listed_count": 2,
            "created_at": "Mon Jun 13 15:47:22 +0000 2011",
            "favourites_count": 2757,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14363,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000117219615/0c55f4523c50e0bcb3b401b5d51dc6b5.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000117219615/0c55f4523c50e0bcb3b401b5d51dc6b5.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000791224126/a9a4843592b0444575db4e0bfb9853b9_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000791224126/a9a4843592b0444575db4e0bfb9853b9_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/316526052/1385443481",
            "profile_link_color": "B30033",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "870609f609c207e4",
            "url": "https://api.twitter.com/1.1/geo/id/870609f609c207e4.json",
            "place_type": "city",
            "name": "Araruama",
            "full_name": "Araruama, Rio de Janeiro",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -42.448794,
                            -22.938817999999998
                        ],
                        [
                            -42.448794,
                            -22.551040999999998
                        ],
                        [
                            -42.132670999999995,
                            -22.551040999999998
                        ],
                        [
                            -42.132670999999995,
                            -22.938817999999998
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "VictorAndradeuv",
                    "name": "The boy",
                    "id": 1873260762,
                    "id_str": "1873260762",
                    "indices": [
                        0,
                        16
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809311117300,
        "id_str": "407240809311117312",
        "text": "Just posted a photo @ lifepoint church -Lynnwood http://t.co/PTohIGkf4c",
        "source": "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 15726937,
            "id_str": "15726937",
            "name": "Brady Anderson",
            "screen_name": "bradypaul",
            "location": "Lynnwood, WA",
            "url": "http://www.facebook.com/bradypaul",
            "description": "Married, two boys (one in heaven), moved to Seattle from TX in 2008, planting a church. Jesus Conservative Politics Cigars Singing Barbershop Digital Marketing",
            "protected": false,
            "followers_count": 1896,
            "friends_count": 2082,
            "listed_count": 56,
            "created_at": "Mon Aug 04 19:57:25 +0000 2008",
            "favourites_count": 30,
            "utc_offset": -28800,
            "time_zone": "Pacific Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5111,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "3F7A23",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/85626554/BradyBen.jpg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/85626554/BradyBen.jpg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/2489760077/zrat007mjyt48nyfp2zg_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/2489760077/zrat007mjyt48nyfp2zg_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/15726937/1360643777",
            "profile_link_color": "1D4C9E",
            "profile_sidebar_border_color": "789654",
            "profile_sidebar_fill_color": "789654",
            "profile_text_color": "000000",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                47.82069187,
                -122.30011105
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -122.30011105,
                47.82069187
            ]
        },
        "place": {
            "id": "3912e7cd4cf62c39",
            "url": "https://api.twitter.com/1.1/geo/id/3912e7cd4cf62c39.json",
            "place_type": "city",
            "name": "Lynnwood",
            "full_name": "Lynnwood, WA",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -122.337735,
                            47.802219
                        ],
                        [
                            -122.337735,
                            47.853569
                        ],
                        [
                            -122.261618,
                            47.853569
                        ],
                        [
                            -122.261618,
                            47.802219
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/PTohIGkf4c",
                    "expanded_url": "http://instagram.com/p/hZFhz_D5m8/",
                    "display_url": "instagram.com/p/hZFhz_D5m8/",
                    "indices": [
                        49,
                        71
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809126580200,
        "id_str": "407240809126580225",
        "text": "Pua, sp.",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 371425972,
            "id_str": "371425972",
            "name": "Jumanji",
            "screen_name": "MartinaZaldivar",
            "location": "Montevideo, Uruguay",
            "url": "https://www.facebook.com/marticarbonera11",
            "description": "Aim zecsi end ai nou it",
            "protected": false,
            "followers_count": 241,
            "friends_count": 117,
            "listed_count": 1,
            "created_at": "Sat Sep 10 20:46:51 +0000 2011",
            "favourites_count": 270,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5034,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "1FDEC5",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000091319873/b443d2f2712c8599b6bd26f9ed1e6e27.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000091319873/b443d2f2712c8599b6bd26f9ed1e6e27.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000808245578/d513b2dcffb6d344e78df72b32ddd3e1_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000808245578/d513b2dcffb6d344e78df72b32ddd3e1_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/371425972/1383776714",
            "profile_link_color": "20E6C5",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -34.7801089,
                -55.4691443
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -55.4691443,
                -34.7801089
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "id"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809134981100,
        "id_str": "407240809134981120",
        "text": "Fiskmiddag. #fredrikätermaten @ Thomas Moore Tavern http://t.co/X5jGvYLDem",
        "source": "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 291701236,
            "id_str": "291701236",
            "name": "Fredrik Thimeradh",
            "screen_name": "Thimeradh",
            "location": "Timrå, Sweden",
            "url": "http://www.facebook.com/fredrik.thimeradh",
            "description": "Welcome. Please stay. I bite.",
            "protected": false,
            "followers_count": 63,
            "friends_count": 150,
            "listed_count": 0,
            "created_at": "Mon May 02 13:42:10 +0000 2011",
            "favourites_count": 2,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 834,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/3076714153/32720864174c35c1bd2fe896cd95dbf7_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/3076714153/32720864174c35c1bd2fe896cd95dbf7_normal.jpeg",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                52.3362709,
                -6.4620247
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -6.4620247,
                52.3362709
            ]
        },
        "place": {
            "id": "0239f5fd632185d5",
            "url": "https://api.twitter.com/1.1/geo/id/0239f5fd632185d5.json",
            "place_type": "city",
            "name": "Wexford",
            "full_name": "Wexford, Wexford",
            "country_code": "IE",
            "country": "Ireland",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -7.0175074,
                            52.1223805
                        ],
                        [
                            -7.0175074,
                            52.7970862
                        ],
                        [
                            -6.1425178,
                            52.7970862
                        ],
                        [
                            -6.1425178,
                            52.1223805
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "fredrikätermaten",
                    "indices": [
                        12,
                        29
                    ]
                }
            ],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/X5jGvYLDem",
                    "expanded_url": "http://instagram.com/p/hZFVmVljvt/",
                    "display_url": "instagram.com/p/hZFVmVljvt/",
                    "indices": [
                        52,
                        74
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "sv"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809403392000,
        "id_str": "407240809403392001",
        "text": "الخسارة خسـإرة إلجـنـة مـو بــنئ إدم",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 488581593,
            "id_str": "488581593",
            "name": "RF♡",
            "screen_name": "RFF_73",
            "location": "KUWAIT",
            "url": "http://ask.fm/RFF_73",
            "description": "if you need anything  just ask ;*",
            "protected": false,
            "followers_count": 449,
            "friends_count": 125,
            "listed_count": 2,
            "created_at": "Fri Feb 10 16:17:47 +0000 2012",
            "favourites_count": 217,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7736,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000634114017/2d65f02946f0e0e31438c3d2fec000ff_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000634114017/2d65f02946f0e0e31438c3d2fec000ff_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/488581593/1385921078",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                29.3044842,
                48.0662605
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                48.0662605,
                29.3044842
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809428574200,
        "id_str": "407240809428574208",
        "text": "La llave del éxito es el conocimiento del valor de las cosas.\nhttp://t.co/mELtFEKHG2",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 737638484,
            "id_str": "737638484",
            "name": "TRIBUTUM XXI",
            "screen_name": "tributumxxi7",
            "location": "Caracas - Venezuela",
            "url": "http://www.facebook.com/tributumxxi7",
            "description": "Lideres en servicio de asesoría y capacitación en el area Aduanera y Tributaria. Transmitimos experiencia y conocimiento a nuestros clientes",
            "protected": false,
            "followers_count": 20429,
            "friends_count": 21127,
            "listed_count": 47,
            "created_at": "Sat Aug 04 23:51:49 +0000 2012",
            "favourites_count": 365,
            "utc_offset": -16200,
            "time_zone": "Caracas",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 19953,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/629959686/jdaxw2bp2t660ti4kzdi.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/629959686/jdaxw2bp2t660ti4kzdi.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000248104157/8f6eb070a4fb089ca534d669f8c7a221_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000248104157/8f6eb070a4fb089ca534d669f8c7a221_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/737638484/1373193849",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                10.4876391,
                -66.9327061
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -66.9327061,
                10.4876391
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/mELtFEKHG2",
                    "expanded_url": "http://Tributumxxi.com",
                    "display_url": "Tributumxxi.com",
                    "indices": [
                        62,
                        84
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809445347300,
        "id_str": "407240809445347328",
        "text": "@yosef_tweetz انته تفهم ياخي كلامك عالجرح ومؤلم جدا",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240685465907200,
        "in_reply_to_status_id_str": "407240685465907201",
        "in_reply_to_user_id": 409984029,
        "in_reply_to_user_id_str": "409984029",
        "in_reply_to_screen_name": "yosef_tweetz",
        "user": {
            "id": 1411230278,
            "id_str": "1411230278",
            "name": "حجيه علويه ☆.",
            "screen_name": "alia_ajmy",
            "location": "دارن باس ارضها جابر| manqaf ",
            "url": "http://ask.fm/aalia_hussain",
            "description": "أبي هو قيسي وأنا بالعشق ليلاه | اللهم ارحم عمي سالم العجمي واجعل ايامه في الجنه اجمل ♡|اللهم اشف مرضى السرطان |امشي و أوزع تفاؤل|#hah",
            "protected": false,
            "followers_count": 468,
            "friends_count": 173,
            "listed_count": 0,
            "created_at": "Tue May 07 20:57:38 +0000 2013",
            "favourites_count": 1111,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 14405,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000756689624/81e060100632e5852e948924351f65d0_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000756689624/81e060100632e5852e948924351f65d0_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1411230278/1384780753",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                29.1117999,
                48.1277659
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                48.1277659,
                29.1117999
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "yosef_tweetz",
                    "name": "انا يسموني يسوف☀️",
                    "id": 409984029,
                    "id_str": "409984029",
                    "indices": [
                        0,
                        13
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809453740000,
        "id_str": "407240809453740032",
        "text": "vinte e sete #mtvstars justin bieber",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 265551911,
            "id_str": "265551911",
            "name": "xoleana",
            "screen_name": "ffckjb",
            "location": "jb e3 ahs thg hh ldr",
            "url": null,
            "description": "they'd change, if they knew the pain",
            "protected": false,
            "followers_count": 2074,
            "friends_count": 910,
            "listed_count": 61,
            "created_at": "Sun Mar 13 19:05:31 +0000 2011",
            "favourites_count": 203,
            "utc_offset": -10800,
            "time_zone": "Santiago",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 39236,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/801788345/1593aa3665b681685ca10af791ad283d.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/801788345/1593aa3665b681685ca10af791ad283d.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000768051942/53d74f4a4cadb00be4d45db55fe1df1e_normal.png",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000768051942/53d74f4a4cadb00be4d45db55fe1df1e_normal.png",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/265551911/1384995367",
            "profile_link_color": "6B6869",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -9.54728007,
                -35.74944733
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -35.74944733,
                -9.54728007
            ]
        },
        "place": {
            "id": "70d9237ded8be5f4",
            "url": "https://api.twitter.com/1.1/geo/id/70d9237ded8be5f4.json",
            "place_type": "city",
            "name": "Maceió",
            "full_name": "Maceió, Alagoas",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -35.815833999999995,
                            -9.711808
                        ],
                        [
                            -35.815833999999995,
                            -9.354851
                        ],
                        [
                            -35.558391,
                            -9.354851
                        ],
                        [
                            -35.558391,
                            -9.711808
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "mtvstars",
                    "indices": [
                        13,
                        22
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809017131000,
        "id_str": "407240809017131008",
        "text": "@FCdoguime_poa ihasiasijas magrinho é doido na real",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240324860223500,
        "in_reply_to_status_id_str": "407240324860223489",
        "in_reply_to_user_id": 364664643,
        "in_reply_to_user_id_str": "364664643",
        "in_reply_to_screen_name": "FCdoguime_poa",
        "user": {
            "id": 2153727324,
            "id_str": "2153727324",
            "name": "Jeniffer Cardoso",
            "screen_name": "jeniffercrds",
            "location": "Gaúcha ",
            "url": "http://cinzasdesaudade.tumblr.com/",
            "description": "Ainda que a minha mente e o meu corpo enfraqueçam, Deus é a minha força, Ele é tudo o que eu sempre preciso.\r\n@CLUBEFOLLOWBACK",
            "protected": false,
            "followers_count": 209,
            "friends_count": 261,
            "listed_count": 0,
            "created_at": "Thu Oct 24 22:07:33 +0000 2013",
            "favourites_count": 16,
            "utc_offset": -7200,
            "time_zone": "Brasilia",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4083,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000690695714/d5054725e5bb898c622faaa14a684f5e_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000690695714/d5054725e5bb898c622faaa14a684f5e_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/2153727324/1385411855",
            "profile_link_color": "F797CD",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "c44302d542084bfe",
            "url": "https://api.twitter.com/1.1/geo/id/c44302d542084bfe.json",
            "place_type": "city",
            "name": "Florianópolis",
            "full_name": "Florianópolis, Santa Catarina",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -48.6102638,
                            -27.8389356
                        ],
                        [
                            -48.6102638,
                            -27.3804458
                        ],
                        [
                            -48.3474853,
                            -27.3804458
                        ],
                        [
                            -48.3474853,
                            -27.8389356
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "FCdoguime_poa",
                    "name": "Suzane do gui  ♡",
                    "id": 364664643,
                    "id_str": "364664643",
                    "indices": [
                        0,
                        14
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809323696100,
        "id_str": "407240809323696128",
        "text": "@BobHrdz @armindaumanzor el cuello no duele al colgárse 4 medallas, FELICIDADES CAMPEÓN !",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 406575292397150200,
        "in_reply_to_status_id_str": "406575292397150208",
        "in_reply_to_user_id": 134677248,
        "in_reply_to_user_id_str": "134677248",
        "in_reply_to_screen_name": "BobHrdz",
        "user": {
            "id": 591471141,
            "id_str": "591471141",
            "name": "Eduardo Cader R.",
            "screen_name": "ciegokdr",
            "location": "",
            "url": null,
            "description": "Patriota y defensor de la libertad hasta que el corazon me deje de palpitar. Tuitepeque, El Salvador.",
            "protected": false,
            "followers_count": 695,
            "friends_count": 556,
            "listed_count": 4,
            "created_at": "Sun May 27 00:58:49 +0000 2012",
            "favourites_count": 269,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8144,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/3458085188/233f98d5de4c62be8d0e187dbf86ad9a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/3458085188/233f98d5de4c62be8d0e187dbf86ad9a_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/591471141/1364354996",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                13.68541971,
                -89.22295283
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -89.22295283,
                13.68541971
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "BobHrdz",
                    "name": "Roberto Hernandez",
                    "id": 134677248,
                    "id_str": "134677248",
                    "indices": [
                        0,
                        8
                    ]
                },
                {
                    "screen_name": "armindaumanzor",
                    "name": "Arminda Umanzor",
                    "id": 266158757,
                    "id_str": "266158757",
                    "indices": [
                        9,
                        24
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809369853950,
        "id_str": "407240809369853953",
        "text": "These 3d street art things are such bullshit they're clearly photoshopped why does nobody see that",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 65613012,
            "id_str": "65613012",
            "name": "hara",
            "screen_name": "haraspyrou",
            "location": "london",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 191,
            "friends_count": 169,
            "listed_count": 0,
            "created_at": "Fri Aug 14 11:17:04 +0000 2009",
            "favourites_count": 154,
            "utc_offset": 0,
            "time_zone": "London",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 205,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "022330",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000089239292/939325abb98fbc03f1ecdea5ada79ba0.png",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000089239292/939325abb98fbc03f1ecdea5ada79ba0.png",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000725695929/ff9c752e5cfa518bba6b396a3976a2ea_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000725695929/ff9c752e5cfa518bba6b396a3976a2ea_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/65613012/1384936017",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "C0DFEC",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                51.59596633,
                -0.14846781
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -0.14846781,
                51.59596633
            ]
        },
        "place": {
            "id": "4d62c7634b786e67",
            "url": "https://api.twitter.com/1.1/geo/id/4d62c7634b786e67.json",
            "place_type": "city",
            "name": "Haringey",
            "full_name": "Haringey, London",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -0.17024599999999998,
                            51.564585
                        ],
                        [
                            -0.17024599999999998,
                            51.6111637
                        ],
                        [
                            -0.034078,
                            51.6111637
                        ],
                        [
                            -0.034078,
                            51.564585
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809109782500,
        "id_str": "407240809109782529",
        "text": "@susannareid100 Your my favourite meerkats! I have voted every week and loved every minute. Thankyou for dancing. Much love to you both.",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": 407237882429341700,
        "in_reply_to_status_id_str": "407237882429341696",
        "in_reply_to_user_id": 19477583,
        "in_reply_to_user_id_str": "19477583",
        "in_reply_to_screen_name": "susannareid100",
        "user": {
            "id": 581998415,
            "id_str": "581998415",
            "name": "Shelley West",
            "screen_name": "shelleywestuk",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 5,
            "friends_count": 78,
            "listed_count": 0,
            "created_at": "Wed May 16 17:07:12 +0000 2012",
            "favourites_count": 3,
            "utc_offset": 0,
            "time_zone": "London",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 42,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "642D8B",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000754286876/fa2e4b15f75745a85abb520acfbd13da_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000754286876/fa2e4b15f75745a85abb520acfbd13da_normal.jpeg",
            "profile_link_color": "FF0000",
            "profile_sidebar_border_color": "65B0DA",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                50.769383,
                -2.02293966
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -2.02293966,
                50.769383
            ]
        },
        "place": {
            "id": "6eef21ee3d4ccbcf",
            "url": "https://api.twitter.com/1.1/geo/id/6eef21ee3d4ccbcf.json",
            "place_type": "city",
            "name": "East Dorset",
            "full_name": "East Dorset, Dorset",
            "country_code": "GB",
            "country": "United Kingdom",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -2.1641269999999997,
                            50.74285
                        ],
                        [
                            -2.1641269999999997,
                            50.992101
                        ],
                        [
                            -1.7907179999999998,
                            50.992101
                        ],
                        [
                            -1.7907179999999998,
                            50.74285
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "susannareid100",
                    "name": "Susanna Reid",
                    "id": 19477583,
                    "id_str": "19477583",
                    "indices": [
                        0,
                        15
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809189474300,
        "id_str": "407240809189474304",
        "text": "Maybe I shoulda Played then came back..",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240426249146400,
        "in_reply_to_status_id_str": "407240426249146368",
        "in_reply_to_user_id": 106027471,
        "in_reply_to_user_id_str": "106027471",
        "in_reply_to_screen_name": "ThereGo_Avion",
        "user": {
            "id": 106027471,
            "id_str": "106027471",
            "name": "DJ DoesITall",
            "screen_name": "ThereGo_Avion",
            "location": "Jungle West",
            "url": null,
            "description": "| #PartyBoyzDJs | #InkredibleSoundsDjs | Booking: 972-896-1049 (SERIOUS INQURIES ONLY) | Photographer | #GFX | #TAMUC Hurdler | #AvionAngels™",
            "protected": false,
            "followers_count": 1914,
            "friends_count": 1896,
            "listed_count": 14,
            "created_at": "Mon Jan 18 07:44:40 +0000 2010",
            "favourites_count": 137,
            "utc_offset": -25200,
            "time_zone": "Mountain Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 65754,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "000000",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000093134535/6e2a0d40dae7610096773e977fe6b32d.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000093134535/6e2a0d40dae7610096773e977fe6b32d.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000808366846/c9fc4335a3ec197df407001d015e02c6_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000808366846/c9fc4335a3ec197df407001d015e02c6_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/106027471/1385055282",
            "profile_link_color": "4C0296",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "000000",
            "profile_text_color": "7A7A7A",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                33.24096589,
                -95.90995864
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -95.90995864,
                33.24096589
            ]
        },
        "place": {
            "id": "ae85e7b0eaee93ed",
            "url": "https://api.twitter.com/1.1/geo/id/ae85e7b0eaee93ed.json",
            "place_type": "city",
            "name": "Commerce",
            "full_name": "Commerce, TX",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -95.923807,
                            33.211979
                        ],
                        [
                            -95.923807,
                            33.266129
                        ],
                        [
                            -95.873806,
                            33.266129
                        ],
                        [
                            -95.873806,
                            33.211979
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809457917950,
        "id_str": "407240809457917953",
        "text": "“#@ruhsardemirel Halkımıza en yakın hizmet veren Aile Hekimleri ve Aile Sağlığı Elemanları niye bu kadar üzgün,mutsuz ve tepkililer??",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 754849903,
            "id_str": "754849903",
            "name": "Fırat Karadeniz",
            "screen_name": "Dr_Firat",
            "location": "Sakarya",
            "url": "http://sakahed.org",
            "description": "Aile Hekimi/ SAKAHED YK Başkanı/RT'ler içeriğe destek ya da karşıtlık anlamında değil, paylaşım amaçlıdır...",
            "protected": false,
            "followers_count": 1709,
            "friends_count": 1972,
            "listed_count": 17,
            "created_at": "Mon Aug 13 10:03:51 +0000 2012",
            "favourites_count": 100,
            "utc_offset": 7200,
            "time_zone": "Istanbul",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 8890,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000657175897/813fa7911442aa6f3203954532d49069_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000657175897/813fa7911442aa6f3203954532d49069_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/754849903/1379279252",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.76789692,
                30.36631697
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                30.36631697,
                40.76789692
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809550192640,
        "id_str": "407240809550192640",
        "text": "عَلمت ذاتَ مَره أنَ الوجَع ليسَ شَرطاً أنَ يكوُن بُكاء ، ربَما يَدعُو عَليكٰ شَخص مَظلوُم فَتكوُن حَياتكٰ كُلهَا أوجاعاً . .\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 2147529904,
            "id_str": "2147529904",
            "name": "євтιѕαм ",
            "screen_name": "fgjdjd369",
            "location": "",
            "url": null,
            "description": "لا تـنـصـدم مــٍن بـســمــتــي يـــؤم أحــاكــيــك .. أحــيــان تــلقــئ بــالجــريــح #أبــتــســامــہ ..:/3",
            "protected": false,
            "followers_count": 569,
            "friends_count": 1023,
            "listed_count": 1,
            "created_at": "Mon Oct 21 21:41:28 +0000 2013",
            "favourites_count": 0,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 1470,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000807319484/3ebc54f77544e3b00680aab0832696b6_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000807319484/3ebc54f77544e3b00680aab0832696b6_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/2147529904/1382391857",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                24.71797442,
                40.15133623
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                40.15133623,
                24.71797442
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809252401150,
        "id_str": "407240809252401152",
        "text": "#Şubatta40binAtamaBütçeyeYükDeğilGeleceğeYatırımdır BRANŞ İSMİYLE 3-5BİN İSTEYENLERİ SPAMLAYALIM,BÖLEN DEĞİL BİRLESTİREN OLALIM.....\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1493213449,
            "id_str": "1493213449",
            "name": "nilgün BESYO",
            "screen_name": "NKotu",
            "location": "istanbul",
            "url": null,
            "description": "KİMSEYİ TAKMA,AĞZI OLAN KONUŞUYOR.HAYALLERİN VAR UNUTMA !!",
            "protected": false,
            "followers_count": 1342,
            "friends_count": 1656,
            "listed_count": 0,
            "created_at": "Sat Jun 08 15:24:47 +0000 2013",
            "favourites_count": 578,
            "utc_offset": 10800,
            "time_zone": "Baghdad",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9576,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000732109235/ce0dfa5ba5b1059078e8c715163e9c76_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000732109235/ce0dfa5ba5b1059078e8c715163e9c76_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1493213449/1382803793",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.070372,
                29.0132629
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                29.0132629,
                41.070372
            ]
        },
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "Şubatta40binAtamaBütçeyeYükDeğilGeleceğeYatırımdır",
                    "indices": [
                        0,
                        51
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809520840700,
        "id_str": "407240809520840704",
        "text": "Bizarrement quand un acteur ou un chanteur meurt direct les gens il s'y intéresse et tout",
        "source": "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 786629653,
            "id_str": "786629653",
            "name": "Margauuux ✞♡",
            "screen_name": "gomar92",
            "location": "",
            "url": null,
            "description": "Le Bonheur Est Un Voyage Et Non Une Destination ! ♡ @Arthur0551mon amourr @smadjouille mon bonheur quotidien. Fuck les rageux! Follow me ♡",
            "protected": false,
            "followers_count": 228,
            "friends_count": 176,
            "listed_count": 0,
            "created_at": "Tue Aug 28 09:35:34 +0000 2012",
            "favourites_count": 210,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5858,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/804163977/be2a4086346597573e6f8f9f700d4314.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/804163977/be2a4086346597573e6f8f9f700d4314.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000736374378/97d15cbc4ab37c6053780f0d14faa3e4_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000736374378/97d15cbc4ab37c6053780f0d14faa3e4_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/786629653/1385320063",
            "profile_link_color": "006BB3",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.90133193,
                2.26658822
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                2.26658822,
                48.90133193
            ]
        },
        "place": {
            "id": "30b5d37dd5aae12a",
            "url": "https://api.twitter.com/1.1/geo/id/30b5d37dd5aae12a.json",
            "place_type": "city",
            "name": "Courbevoie",
            "full_name": "Courbevoie, Hauts-de-Seine",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.2306588,
                            48.8869026
                        ],
                        [
                            2.2306588,
                            48.9082685
                        ],
                        [
                            2.2841562,
                            48.9082685
                        ],
                        [
                            2.2841562,
                            48.8869026
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809554411500,
        "id_str": "407240809554411520",
        "text": "@chadhartberger same team that you sat Tate lol?",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407240608928251900,
        "in_reply_to_status_id_str": "407240608928251904",
        "in_reply_to_user_id": 588671614,
        "in_reply_to_user_id_str": "588671614",
        "in_reply_to_screen_name": "chadhartberger",
        "user": {
            "id": 374074437,
            "id_str": "374074437",
            "name": "mike guglielmo ",
            "screen_name": "Googie_boogie31",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 168,
            "friends_count": 246,
            "listed_count": 0,
            "created_at": "Thu Sep 15 17:22:36 +0000 2011",
            "favourites_count": 1423,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3626,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000607350435/49c60cc8811d3496fd51201c247e3899_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000607350435/49c60cc8811d3496fd51201c247e3899_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/374074437/1383428331",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                40.82617363,
                -74.56106742
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -74.56106742,
                40.82617363
            ]
        },
        "place": {
            "id": "62885343883547f8",
            "url": "https://api.twitter.com/1.1/geo/id/62885343883547f8.json",
            "place_type": "city",
            "name": "Randolph",
            "full_name": "Randolph, NJ",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -74.645802,
                            40.804714
                        ],
                        [
                            -74.645802,
                            40.883942
                        ],
                        [
                            -74.524895,
                            40.883942
                        ],
                        [
                            -74.524895,
                            40.804714
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "chadhartberger",
                    "name": "chad hartberger",
                    "id": 588671614,
                    "id_str": "588671614",
                    "indices": [
                        0,
                        15
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809302347800,
        "id_str": "407240809302347776",
        "text": "来年の師走まで…２０５系は残っているかどうか…。",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 150537319,
            "id_str": "150537319",
            "name": "ひろゆき",
            "screen_name": "molnyk",
            "location": "東京都",
            "url": null,
            "description": "昔のアニメと特撮-鉄道-プロレス-北方謙三著作の水滸伝-楊令伝-岳飛伝-三国志等の歴史小説-仮面ライダーWとスカル-ダークナイト-アイアンマン-ウルヴァリン-肉弾アクション映画が好きな中年のおっさん…",
            "protected": false,
            "followers_count": 70,
            "friends_count": 182,
            "listed_count": 2,
            "created_at": "Tue Jun 01 05:17:34 +0000 2010",
            "favourites_count": 446,
            "utc_offset": 32400,
            "time_zone": "Tokyo",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4475,
            "lang": "ja",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000808766080/5e0da0eac65f22e99de0ee63667861e1_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000808766080/5e0da0eac65f22e99de0ee63667861e1_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/150537319/1385782016",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                35.5118244,
                139.592324
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                139.592324,
                35.5118244
            ]
        },
        "place": {
            "id": "dded92a2db180dd1",
            "url": "https://api.twitter.com/1.1/geo/id/dded92a2db180dd1.json",
            "place_type": "city",
            "name": "横浜市港北区",
            "full_name": "横浜市港北区, 神奈川県",
            "country_code": "JP",
            "country": "日本",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            139.582547222222,
                            35.4895230555556
                        ],
                        [
                            139.582547222222,
                            35.5627266666667
                        ],
                        [
                            139.658308333333,
                            35.5627266666667
                        ],
                        [
                            139.658308333333,
                            35.4895230555556
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ja"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809571156000,
        "id_str": "407240809571155968",
        "text": "@TatianaPosohova ты когда сваливаешь?",
        "source": "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
        "truncated": false,
        "in_reply_to_status_id": 407148245337772000,
        "in_reply_to_status_id_str": "407148245337772032",
        "in_reply_to_user_id": 491370433,
        "in_reply_to_user_id_str": "491370433",
        "in_reply_to_screen_name": "TatianaPosohova",
        "user": {
            "id": 507589469,
            "id_str": "507589469",
            "name": "Жиличкина Кристина",
            "screen_name": "114Tina",
            "location": "",
            "url": null,
            "description": "Лучше быть абсолютно смешной, чем абсолютно скучной.",
            "protected": false,
            "followers_count": 86,
            "friends_count": 72,
            "listed_count": 0,
            "created_at": "Tue Feb 28 16:27:51 +0000 2012",
            "favourites_count": 1373,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5954,
            "lang": "ru",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/824357238/f8205b2e2b4aaf08b5a259041de41749.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/824357238/f8205b2e2b4aaf08b5a259041de41749.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000503538193/66d4fa5e1d330e867a7e2c27946edc5a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000503538193/66d4fa5e1d330e867a7e2c27946edc5a_normal.jpeg",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "F6FFD1",
            "profile_text_color": "333333",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                54.62297868,
                39.78308151
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                39.78308151,
                54.62297868
            ]
        },
        "place": {
            "id": "f4a405ee7b85831a",
            "url": "https://api.twitter.com/1.1/geo/id/f4a405ee7b85831a.json",
            "place_type": "city",
            "name": "Рязань",
            "full_name": "Рязань, Рязань",
            "country_code": "RU",
            "country": "Россия",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            39.5694059,
                            54.5138511
                        ],
                        [
                            39.5694059,
                            54.8081861
                        ],
                        [
                            39.859300000000005,
                            54.8081861
                        ],
                        [
                            39.859300000000005,
                            54.5138511
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "TatianaPosohova",
                    "name": "Татьяна Посохова",
                    "id": 491370433,
                    "id_str": "491370433",
                    "indices": [
                        0,
                        16
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ru"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809595936800,
        "id_str": "407240809595936768",
        "text": "BEN FAKEYMİŞİM :O \n\nhttps://t.co/SFeZ0tT2G1 \n\nevet fakeyim :D :D",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1867882368,
            "id_str": "1867882368",
            "name": "†‏ Aliynaa .♥ ♥",
            "screen_name": "AleynaT14488146",
            "location": "GALATASARAY ♥",
            "url": "http://www.facebook.com/CcaleynaCc",
            "description": "†‏▼ Δ Denke Du bist eine Frau von Widder Rest . ♥",
            "protected": false,
            "followers_count": 421,
            "friends_count": 982,
            "listed_count": 0,
            "created_at": "Sun Sep 15 14:20:41 +0000 2013",
            "favourites_count": 50,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 568,
            "lang": "tr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "131516",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme14/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000799576852/420608c0383e16aa20f67a3f17e5ddff_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000799576852/420608c0383e16aa20f67a3f17e5ddff_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1867882368/1385597810",
            "profile_link_color": "009999",
            "profile_sidebar_border_color": "EEEEEE",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "682c5a667856ef42",
            "url": "https://api.twitter.com/1.1/geo/id/682c5a667856ef42.json",
            "place_type": "country",
            "name": "Türkiye",
            "full_name": "Türkiye",
            "country_code": "TR",
            "country": "Türkiye",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            25.663883,
                            35.817497
                        ],
                        [
                            25.663883,
                            42.109993
                        ],
                        [
                            44.822762,
                            42.109993
                        ],
                        [
                            44.822762,
                            35.817497
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "https://t.co/SFeZ0tT2G1",
                    "expanded_url": "https://www.facebook.com/CcaleynaCc",
                    "display_url": "facebook.com/CcaleynaCc",
                    "indices": [
                        20,
                        43
                    ]
                }
            ],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809726373900,
        "id_str": "407240809726373888",
        "text": "I need you so 🎧",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1390046768,
            "id_str": "1390046768",
            "name": "Marie-Zoé ✨",
            "screen_name": "MarieZoeGrignon",
            "location": "Paris XV ",
            "url": null,
            "description": "Meg mon amr ❤❤ BBM : 24BE0686 Insta : MarieZoeGrn",
            "protected": false,
            "followers_count": 121,
            "friends_count": 152,
            "listed_count": 0,
            "created_at": "Mon Apr 29 17:38:22 +0000 2013",
            "favourites_count": 96,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4058,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "235CEB",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000021490160/f13995349abcd6d3a7b0b7504ffbefad.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000021490160/f13995349abcd6d3a7b0b7504ffbefad.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000792711857/3f6bae5e8f7d3789d0b049038c4c9d51_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000792711857/3f6bae5e8f7d3789d0b049038c4c9d51_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1390046768/1385921324",
            "profile_link_color": "DB1FBF",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                48.83207308,
                2.30694755
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                2.30694755,
                48.83207308
            ]
        },
        "place": {
            "id": "7238f93a3e899af6",
            "url": "https://api.twitter.com/1.1/geo/id/7238f93a3e899af6.json",
            "place_type": "city",
            "name": "Paris",
            "full_name": "Paris, Paris",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            2.2241006,
                            48.8155414
                        ],
                        [
                            2.2241006,
                            48.9021461
                        ],
                        [
                            2.4699099,
                            48.9021461
                        ],
                        [
                            2.4699099,
                            48.8155414
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809587957760,
        "id_str": "407240809587957760",
        "text": "🎄 &lt;-- sin ti .... 😞 mejor 😲",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 50517930,
            "id_str": "50517930",
            "name": "28 days ^.^",
            "screen_name": "Emely_Ivette",
            "location": "With Jesus ",
            "url": null,
            "description": "Nothing in this life compares to feeling the breath of God behind everything you do. 122510. My Twin ♥ StephyLizx3 :)",
            "protected": false,
            "followers_count": 205,
            "friends_count": 98,
            "listed_count": 1,
            "created_at": "Thu Jun 25 02:05:23 +0000 2009",
            "favourites_count": 4202,
            "utc_offset": -21600,
            "time_zone": "Central Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 24109,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "642D8B",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme10/bg.gif",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000806810605/0ea84637b5fa3b6adb295b76f866d1fb_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000806810605/0ea84637b5fa3b6adb295b76f866d1fb_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/50517930/1385352877",
            "profile_link_color": "FF0000",
            "profile_sidebar_border_color": "65B0DA",
            "profile_sidebar_fill_color": "7AC3EE",
            "profile_text_color": "3D1957",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                41.36028226,
                -73.63406902
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -73.63406902,
                41.36028226
            ]
        },
        "place": {
            "id": "e86b380cfefcced5",
            "url": "https://api.twitter.com/1.1/geo/id/e86b380cfefcced5.json",
            "place_type": "admin",
            "name": "Connecticut",
            "full_name": "Connecticut, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -73.727775,
                            40.950942999999995
                        ],
                        [
                            -73.727775,
                            42.050587
                        ],
                        [
                            -71.787239,
                            42.050587
                        ],
                        [
                            -71.787239,
                            40.950942999999995
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809785094140,
        "id_str": "407240809785094145",
        "text": "شرهة الميت !\nعلى بيض النوايا ، يوم يحتاج الدعآء\nوهم غافلين ، بعثروا صمت المقابر في هدايا ، \nوأمطروها بالدعاا للميتين '(\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 701962234,
            "id_str": "701962234",
            "name": "مـن أجلـك ♥",
            "screen_name": "hkk5566",
            "location": "",
            "url": null,
            "description": "‏ي'عسـانا ندخـل الجَنـهه سوى ♡M♥",
            "protected": false,
            "followers_count": 794,
            "friends_count": 1447,
            "listed_count": 0,
            "created_at": "Sat Oct 05 10:07:08 +0000 2013",
            "favourites_count": 11,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 838,
            "lang": "ar",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000707235763/6f2a0c60bffca97d4d766a30f6112f4a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000707235763/6f2a0c60bffca97d4d766a30f6112f4a_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/701962234/1383835582",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                17.5122315,
                47.1025038
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                47.1025038,
                17.5122315
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "ar"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809768288260,
        "id_str": "407240809768288256",
        "text": "@HMSbeagle_ koşubandında elektrik kesilmedi ama  voltaj düştü.bu bir uyarı olabilir :D",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": 210391543,
        "in_reply_to_user_id_str": "210391543",
        "in_reply_to_screen_name": "HMSbeagle_",
        "user": {
            "id": 375784665,
            "id_str": "375784665",
            "name": "akn",
            "screen_name": "dzdcnfsd",
            "location": "earth",
            "url": "http://www.linkedin.com/pub/ak%C4%B1n-g%C3%BCndo%C4%9Fdu/2a/132/93b",
            "description": null,
            "protected": false,
            "followers_count": 55,
            "friends_count": 56,
            "listed_count": 1,
            "created_at": "Sun Sep 18 18:41:13 +0000 2011",
            "favourites_count": 159,
            "utc_offset": -18000,
            "time_zone": "Quito",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5068,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "698691",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/829833010/290fbbf9aba3e5cdc56cb4c9f728ac27.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/829833010/290fbbf9aba3e5cdc56cb4c9f728ac27.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000814387661/67d9fad0d5d5b346be8d4760b6f7b60a_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000814387661/67d9fad0d5d5b346be8d4760b6f7b60a_normal.jpeg",
            "profile_link_color": "99B3BF",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "EEEEEE",
            "profile_text_color": "000000",
            "profile_use_background_image": false,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                32.75087393,
                13.13609705
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                13.13609705,
                32.75087393
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "HMSbeagle_",
                    "name": "outlaw",
                    "id": 210391543,
                    "id_str": "210391543",
                    "indices": [
                        0,
                        11
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "tr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809847590900,
        "id_str": "407240809847590913",
        "text": "Será q vc pensa em mim como eu penso em vc ?",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 1239196766,
            "id_str": "1239196766",
            "name": "Gabss ✌️",
            "screen_name": "Gabriela_VF13",
            "location": "",
            "url": null,
            "description": "Larga tudo e vem correndo pra eu mergulhar no seu sorriso, me arranca desse inferno e me leva pro seu paraíso (8",
            "protected": false,
            "followers_count": 263,
            "friends_count": 393,
            "listed_count": 0,
            "created_at": "Sun Mar 03 15:40:58 +0000 2013",
            "favourites_count": 1018,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5163,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000063116035/568db87f48e83d0f859a7163f655c0f8.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000063116035/568db87f48e83d0f859a7163f655c0f8.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000703823205/a788d5a1fee558354400bfaf0d033416_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000703823205/a788d5a1fee558354400bfaf0d033416_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/1239196766/1376673536",
            "profile_link_color": "B30089",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "59373f0a295160e4",
            "url": "https://api.twitter.com/1.1/geo/id/59373f0a295160e4.json",
            "place_type": "city",
            "name": "Niterói",
            "full_name": "Niterói, Rio de Janeiro",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -43.191597,
                            -22.982969999999998
                        ],
                        [
                            -43.191597,
                            -22.856025
                        ],
                        [
                            -42.954408,
                            -22.856025
                        ],
                        [
                            -42.954408,
                            -22.982969999999998
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809613119500,
        "id_str": "407240809613119488",
        "text": "Le seul element positife de la semaine = #TPMP",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 405089049,
            "id_str": "405089049",
            "name": "middle.",
            "screen_name": "MathildeLalevee",
            "location": "Aix en pce,France",
            "url": null,
            "description": "15 ans,Lycéenne. #TeamOM #TeamBasket #TPMP #Fanzouze #TheMentalist #TeamHanouna",
            "protected": false,
            "followers_count": 239,
            "friends_count": 298,
            "listed_count": 1,
            "created_at": "Fri Nov 04 21:00:13 +0000 2011",
            "favourites_count": 1764,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 4349,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme3/bg.gif",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme3/bg.gif",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000689754892/e650095ad982f010ff3dabff9484d2c9_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000689754892/e650095ad982f010ff3dabff9484d2c9_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/405089049/1382818818",
            "profile_link_color": "EB63A5",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "EFEFEF",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                43.4429776,
                5.6952769
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                5.6952769,
                43.4429776
            ]
        },
        "place": {
            "id": "cd6dd49e515fd8aa",
            "url": "https://api.twitter.com/1.1/geo/id/cd6dd49e515fd8aa.json",
            "place_type": "city",
            "name": "Trets",
            "full_name": "Trets, Bouches-du-Rhône",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            5.6388439,
                            43.3991433
                        ],
                        [
                            5.6388439,
                            43.4914764
                        ],
                        [
                            5.7882451,
                            43.4914764
                        ],
                        [
                            5.7882451,
                            43.3991433
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [
                {
                    "text": "TPMP",
                    "indices": [
                        41,
                        46
                    ]
                }
            ],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809466331140,
        "id_str": "407240809466331136",
        "text": "Se quiere salir... Casi afuera... Quien viene y la termina de sacar http://t.co/xEwfEW68Ht",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 856491456,
            "id_str": "856491456",
            "name": "AndresVersAct",
            "screen_name": "AndresVersAct",
            "location": "",
            "url": null,
            "description": "En una escala de 0 a 10 en arrechera soy un 1000, el sexo oral es mi favorito, y pues soy descomplicado, cualquier otra cosa pregunte... WHATSAPP ganatelo",
            "protected": false,
            "followers_count": 1561,
            "friends_count": 98,
            "listed_count": 4,
            "created_at": "Mon Oct 01 14:52:44 +0000 2012",
            "favourites_count": 213,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 5109,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "E6E6E1",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/811431570/a1f35cbbd06f4e6c55024602fa4e139c.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/811431570/a1f35cbbd06f4e6c55024602fa4e139c.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000268423046/a94ca3a251ba89cd7120381404631afd_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000268423046/a94ca3a251ba89cd7120381404631afd_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/856491456/1371778889",
            "profile_link_color": "ADA6A3",
            "profile_sidebar_border_color": "000000",
            "profile_sidebar_fill_color": "6DF5EB",
            "profile_text_color": "EDE200",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                10.9802468,
                -74.8132138
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -74.8132138,
                10.9802468
            ]
        },
        "place": null,
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [],
            "media": [
                {
                    "id": 407240809122381800,
                    "id_str": "407240809122381824",
                    "indices": [
                        68,
                        90
                    ],
                    "media_url": "http://pbs.twimg.com/media/BabPW7XIQAAMwJ9.jpg",
                    "media_url_https": "https://pbs.twimg.com/media/BabPW7XIQAAMwJ9.jpg",
                    "url": "http://t.co/xEwfEW68Ht",
                    "display_url": "pic.twitter.com/xEwfEW68Ht",
                    "expanded_url": "http://twitter.com/AndresVersAct/status/407240809466331136/photo/1",
                    "type": "photo",
                    "sizes": {
                        "medium": {
                            "w": 600,
                            "h": 450,
                            "resize": "fit"
                        },
                        "thumb": {
                            "w": 150,
                            "h": 150,
                            "resize": "crop"
                        },
                        "large": {
                            "w": 640,
                            "h": 480,
                            "resize": "fit"
                        },
                        "small": {
                            "w": 340,
                            "h": 255,
                            "resize": "fit"
                        }
                    }
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809851805700,
        "id_str": "407240809851805696",
        "text": "Passando aqui pra falar que eu te amo, coração! Mesmo me esquecendo, viada! E tô brava ainda! Fdp! @Larialmd_",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 107531755,
            "id_str": "107531755",
            "name": "Emily Manduca",
            "screen_name": "_emily2",
            "location": "Jaboticabal - São Paulo.",
            "url": "http://instagram.com/emilymanduca_",
            "description": "Não discuto com o destino, o que pintar eu assino.",
            "protected": false,
            "followers_count": 778,
            "friends_count": 404,
            "listed_count": 2,
            "created_at": "Fri Jan 22 21:57:54 +0000 2010",
            "favourites_count": 5009,
            "utc_offset": 3600,
            "time_zone": "Madrid",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 91798,
            "lang": "pt",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFFFFF",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000118856296/1221b3d8cace6ccd99c78c517bf750b3.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000118856296/1221b3d8cace6ccd99c78c517bf750b3.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000614289385/23305adc60bba0e1e3f1b4b100f0220d_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000614289385/23305adc60bba0e1e3f1b4b100f0220d_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/107531755/1384711830",
            "profile_link_color": "FC4B4B",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "FFFFFF",
            "profile_text_color": "000000",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "71822018c0530dc3",
            "url": "https://api.twitter.com/1.1/geo/id/71822018c0530dc3.json",
            "place_type": "city",
            "name": "Jaboticabal",
            "full_name": "Jaboticabal, São Paulo",
            "country_code": "BR",
            "country": "Brasil",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -48.449538,
                            -21.360746
                        ],
                        [
                            -48.449538,
                            -21.0592846
                        ],
                        [
                            -48.137626,
                            -21.0592846
                        ],
                        [
                            -48.137626,
                            -21.360746
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "Larialmd_",
                    "name": "Larissa",
                    "id": 140581648,
                    "id_str": "140581648",
                    "indices": [
                        99,
                        109
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809713778700,
        "id_str": "407240809713778688",
        "text": "RIP petit animal à 4pattes..",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 767523360,
            "id_str": "767523360",
            "name": "Papuuuche",
            "screen_name": "EliseDubiel",
            "location": "Toulouse",
            "url": "http://www.facebook.com/elise.dubiel",
            "description": "Tu connais les 7péchés capitaux? Je suis le 8°.✝",
            "protected": false,
            "followers_count": 66,
            "friends_count": 105,
            "listed_count": 0,
            "created_at": "Sun Aug 19 12:59:13 +0000 2012",
            "favourites_count": 4,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 293,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "FFF04D",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000005818230/3d39ffa7296702d6d44228f142b2efed.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000005818230/3d39ffa7296702d6d44228f142b2efed.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000746475176/9d4cf8806da3f010dbf3fc3926fda238_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000746475176/9d4cf8806da3f010dbf3fc3926fda238_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/767523360/1384981384",
            "profile_link_color": "0099CC",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                47.2741759,
                -1.0230773
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -1.0230773,
                47.2741759
            ]
        },
        "place": {
            "id": "22a99a14be9d66e2",
            "url": "https://api.twitter.com/1.1/geo/id/22a99a14be9d66e2.json",
            "place_type": "city",
            "name": "Saint-Pierre-Montlimart",
            "full_name": "Saint-Pierre-Montlimart, Maine-et-Loire",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -1.0730953,
                            47.2353141
                        ],
                        [
                            -1.0730953,
                            47.3212652
                        ],
                        [
                            -1.000295,
                            47.3212652
                        ],
                        [
                            -1.000295,
                            47.2353141
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809856385000,
        "id_str": "407240809856385025",
        "text": "\"@SergioCastander: Va va va seguimos con Payback de Sandro Silva!! http://t.co/7v68vs9h5O\"",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 203621498,
            "id_str": "203621498",
            "name": "Javi Herrero ◢◤",
            "screen_name": "javiherrero10",
            "location": "Gijon,Asturias,España",
            "url": "http://soundcloud.com/we-are-2-shy/",
            "description": "12/11/96 // 2º Bachiller en La Asuncion // TimBerg ◢◤ // #EDMFamily // #WeLoveMusic_FM // @WeAreShy // @WeLoveMusic_FM",
            "protected": false,
            "followers_count": 382,
            "friends_count": 373,
            "listed_count": 7,
            "created_at": "Sat Oct 16 18:07:23 +0000 2010",
            "favourites_count": 126,
            "utc_offset": 3600,
            "time_zone": "Amsterdam",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 7892,
            "lang": "es",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "68EB1D",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/378800000002549952/408dff191e4a01e6d83fc761c5f346ee.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/378800000002549952/408dff191e4a01e6d83fc761c5f346ee.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000587546270/fe4dafc385f9c8375dfb3374176e97c9_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000587546270/fe4dafc385f9c8375dfb3374176e97c9_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/203621498/1382173961",
            "profile_link_color": "E61212",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                43.53853882,
                -5.6531958
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -5.6531958,
                43.53853882
            ]
        },
        "place": {
            "id": "731c9d11275a5436",
            "url": "https://api.twitter.com/1.1/geo/id/731c9d11275a5436.json",
            "place_type": "city",
            "name": "Gijón",
            "full_name": "Gijón, Asturias",
            "country_code": "ES",
            "country": "España",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -5.8209772,
                            43.4416802
                        ],
                        [
                            -5.8209772,
                            43.5751547
                        ],
                        [
                            -5.5629115,
                            43.5751547
                        ],
                        [
                            -5.5629115,
                            43.4416802
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [
                {
                    "url": "http://t.co/7v68vs9h5O",
                    "expanded_url": "http://Myradiostream.com/welovemusicfm",
                    "display_url": "Myradiostream.com/welovemusicfm",
                    "indices": [
                        67,
                        89
                    ]
                }
            ],
            "user_mentions": [
                {
                    "screen_name": "SergioCastander",
                    "name": "SƎRGIO",
                    "id": 918043189,
                    "id_str": "918043189",
                    "indices": [
                        1,
                        17
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "possibly_sensitive": false,
        "filter_level": "medium",
        "lang": "es"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809881165800,
        "id_str": "407240809881165824",
        "text": "@AJJeffery1 Best catch I've ever seen by a Chicago Bear! Wow!! Beast!",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": 249792520,
        "in_reply_to_user_id_str": "249792520",
        "in_reply_to_screen_name": "AJJeffery1",
        "user": {
            "id": 84016458,
            "id_str": "84016458",
            "name": "Drew",
            "screen_name": "Drewskii2389",
            "location": "",
            "url": null,
            "description": null,
            "protected": false,
            "followers_count": 64,
            "friends_count": 165,
            "listed_count": 0,
            "created_at": "Wed Oct 21 06:24:50 +0000 2009",
            "favourites_count": 152,
            "utc_offset": null,
            "time_zone": null,
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 978,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/703667486/c780abbb92b50db01c8838e6af4b9883.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/703667486/c780abbb92b50db01c8838e6af4b9883.jpeg",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000355205893/e297939f78e41bccdbbc9b4ea88a9454_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000355205893/e297939f78e41bccdbbc9b4ea88a9454_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/84016458/1358639792",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                42.29120832,
                -89.03515846
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -89.03515846,
                42.29120832
            ]
        },
        "place": {
            "id": "f54a2170ff4b15f7",
            "url": "https://api.twitter.com/1.1/geo/id/f54a2170ff4b15f7.json",
            "place_type": "admin",
            "name": "Illinois",
            "full_name": "Illinois, US",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -91.51307899999999,
                            36.970298
                        ],
                        [
                            -91.51307899999999,
                            42.508337999999995
                        ],
                        [
                            -87.01993499999999,
                            42.508337999999995
                        ],
                        [
                            -87.01993499999999,
                            36.970298
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "AJJeffery1",
                    "name": "Alshon Jeffery",
                    "id": 249792520,
                    "id_str": "249792520",
                    "indices": [
                        0,
                        11
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809931472900,
        "id_str": "407240809931472896",
        "text": "Reading this shit slow",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 922052804,
            "id_str": "922052804",
            "name": "Angelo",
            "screen_name": "_Otra1",
            "location": "",
            "url": null,
            "description": "Getting it. #24",
            "protected": false,
            "followers_count": 185,
            "friends_count": 173,
            "listed_count": 0,
            "created_at": "Sat Nov 03 00:03:30 +0000 2012",
            "favourites_count": 711,
            "utc_offset": -18000,
            "time_zone": "Eastern Time (US & Canada)",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3202,
            "lang": "en",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "022330",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme15/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme15/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000740461088/1ccfb553e0c5a2cd6d9ba625f52c3d3f_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000740461088/1ccfb553e0c5a2cd6d9ba625f52c3d3f_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/922052804/1378000346",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "A8C7F7",
            "profile_sidebar_fill_color": "C0DFEC",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                39.0939574,
                -94.6320576
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                -94.6320576,
                39.0939574
            ]
        },
        "place": {
            "id": "9a974dfc8efb32a0",
            "url": "https://api.twitter.com/1.1/geo/id/9a974dfc8efb32a0.json",
            "place_type": "city",
            "name": "Kansas City",
            "full_name": "Kansas City, KS",
            "country_code": "US",
            "country": "United States",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -94.908465,
                            39.043559
                        ],
                        [
                            -94.908465,
                            39.202911
                        ],
                        [
                            -94.588387,
                            39.202911
                        ],
                        [
                            -94.588387,
                            39.043559
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "en"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240810049339400,
        "id_str": "407240810049339393",
        "text": "@ShaDFE wwieeee",
        "source": "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
        "truncated": false,
        "in_reply_to_status_id": 407221103875342340,
        "in_reply_to_status_id_str": "407221103875342336",
        "in_reply_to_user_id": 616430386,
        "in_reply_to_user_id_str": "616430386",
        "in_reply_to_screen_name": "ShaDFE",
        "user": {
            "id": 218773963,
            "id_str": "218773963",
            "name": "hakuna matata☆",
            "screen_name": "Doominiqueexx",
            "location": "",
            "url": "http://Chiara.com",
            "description": null,
            "protected": false,
            "followers_count": 331,
            "friends_count": 250,
            "listed_count": 2,
            "created_at": "Tue Nov 23 06:59:10 +0000 2010",
            "favourites_count": 35,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 10295,
            "lang": "nl",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "0099B9",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/674902749/dd87b41ba874f4aafd6e732a1660fd61.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/674902749/dd87b41ba874f4aafd6e732a1660fd61.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000740694865/eb04327eb10026c7b5ff665267b07d95_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000740694865/eb04327eb10026c7b5ff665267b07d95_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/218773963/1385587281",
            "profile_link_color": "0099B9",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "E5507E",
            "profile_text_color": "362720",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                52.42898377,
                4.66919702
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                4.66919702,
                52.42898377
            ]
        },
        "place": {
            "id": "ad1b1f13f936d5f0",
            "url": "https://api.twitter.com/1.1/geo/id/ad1b1f13f936d5f0.json",
            "place_type": "city",
            "name": "Velsen",
            "full_name": "Velsen, Noord-Holland",
            "country_code": "NL",
            "country": "Nederland",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            4.5171962,
                            52.4108736
                        ],
                        [
                            4.5171962,
                            52.4920216
                        ],
                        [
                            4.7230637,
                            52.4920216
                        ],
                        [
                            4.7230637,
                            52.4108736
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "ShaDFE",
                    "name": "B-brave♥",
                    "id": 616430386,
                    "id_str": "616430386",
                    "indices": [
                        0,
                        7
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "pt"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809897918460,
        "id_str": "407240809897918464",
        "text": "@RchJulie Ah bah sa va tranquille, y en a qu'on du bol ! :rire:",
        "source": "web",
        "truncated": false,
        "in_reply_to_status_id": 407240560270143500,
        "in_reply_to_status_id_str": "407240560270143488",
        "in_reply_to_user_id": 406357646,
        "in_reply_to_user_id_str": "406357646",
        "in_reply_to_screen_name": "RchJulie",
        "user": {
            "id": 347826622,
            "id_str": "347826622",
            "name": "Nicolas Dericbourg",
            "screen_name": "Ndericbourg",
            "location": "Angers - France",
            "url": null,
            "description": "#TeamLens #TeamSco et #TeamSoccers         https://www.facebook.com/niko.dericbourg",
            "protected": false,
            "followers_count": 177,
            "friends_count": 228,
            "listed_count": 3,
            "created_at": "Wed Aug 03 12:35:06 +0000 2011",
            "favourites_count": 1,
            "utc_offset": 7200,
            "time_zone": "Athens",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 3453,
            "lang": "fr",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "C0DEED",
            "profile_background_image_url": "http://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_image_url_https": "https://abs.twimg.com/images/themes/theme1/bg.png",
            "profile_background_tile": false,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000749458972/a546a6b1afe41f602a0758218088ca6e_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000749458972/a546a6b1afe41f602a0758218088ca6e_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/347826622/1383957421",
            "profile_link_color": "0084B4",
            "profile_sidebar_border_color": "C0DEED",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": true,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": null,
        "coordinates": null,
        "place": {
            "id": "9f7883ef132ba99e",
            "url": "https://api.twitter.com/1.1/geo/id/9f7883ef132ba99e.json",
            "place_type": "city",
            "name": "Angers",
            "full_name": "Angers, Maine-et-Loire",
            "country_code": "FR",
            "country": "France",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            -0.6176846,
                            47.4373461
                        ],
                        [
                            -0.6176846,
                            47.5262286
                        ],
                        [
                            -0.5083534,
                            47.5262286
                        ],
                        [
                            -0.5083534,
                            47.4373461
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": [
                {
                    "screen_name": "RchJulie",
                    "name": "Julie Rch",
                    "id": 406357646,
                    "id_str": "406357646",
                    "indices": [
                        0,
                        9
                    ]
                }
            ]
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "fr"
    },
    {
        "created_at": "Sun Dec 01 20:12:29 +0000 2013",
        "id": 407240809767919600,
        "id_str": "407240809767919616",
        "text": "Entahlah mata mau merem.apa enggak.. yg penting besok libur",
        "source": "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
        "truncated": false,
        "in_reply_to_status_id": null,
        "in_reply_to_status_id_str": null,
        "in_reply_to_user_id": null,
        "in_reply_to_user_id_str": null,
        "in_reply_to_screen_name": null,
        "user": {
            "id": 569262793,
            "id_str": "569262793",
            "name": "Adien",
            "screen_name": "Dienazra",
            "location": "Bekasi ~ Jogjakarta",
            "url": "http://m.facebook.com/Adien.azra.maulana",
            "description": "So Relax, Mr. Simple | Economics Finance of Islamic Banking '012 | @LFC #Liverpudlian #YNWA",
            "protected": false,
            "followers_count": 359,
            "friends_count": 321,
            "listed_count": 1,
            "created_at": "Wed May 02 17:09:23 +0000 2012",
            "favourites_count": 75,
            "utc_offset": 25200,
            "time_zone": "Jakarta",
            "geo_enabled": true,
            "verified": false,
            "statuses_count": 9617,
            "lang": "id",
            "contributors_enabled": false,
            "is_translator": false,
            "profile_background_color": "F00E0E",
            "profile_background_image_url": "http://a0.twimg.com/profile_background_images/807957374/96df3111af0eadf7645e5adbb8f70304.jpeg",
            "profile_background_image_url_https": "https://si0.twimg.com/profile_background_images/807957374/96df3111af0eadf7645e5adbb8f70304.jpeg",
            "profile_background_tile": true,
            "profile_image_url": "http://pbs.twimg.com/profile_images/378800000813738467/927b75423e73e22adc320d55916d3603_normal.jpeg",
            "profile_image_url_https": "https://pbs.twimg.com/profile_images/378800000813738467/927b75423e73e22adc320d55916d3603_normal.jpeg",
            "profile_banner_url": "https://pbs.twimg.com/profile_banners/569262793/1380451176",
            "profile_link_color": "EB1515",
            "profile_sidebar_border_color": "FFFFFF",
            "profile_sidebar_fill_color": "DDEEF6",
            "profile_text_color": "333333",
            "profile_use_background_image": true,
            "default_profile": false,
            "default_profile_image": false,
            "following": null,
            "follow_request_sent": null,
            "notifications": null
        },
        "geo": {
            "type": "Point",
            "coordinates": [
                -7.7788876,
                110.3755963
            ]
        },
        "coordinates": {
            "type": "Point",
            "coordinates": [
                110.3755963,
                -7.7788876
            ]
        },
        "place": {
            "id": "ae188c2b719d333e",
            "url": "https://api.twitter.com/1.1/geo/id/ae188c2b719d333e.json",
            "place_type": "city",
            "name": "Gondokusuman",
            "full_name": "Gondokusuman, Kota Yogyakarta",
            "country_code": "ID",
            "country": "Indonesia",
            "contained_within": [],
            "bounding_box": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [
                            110.3681267,
                            -7.797803999999999
                        ],
                        [
                            110.3681267,
                            -7.7742774
                        ],
                        [
                            110.395497,
                            -7.7742774
                        ],
                        [
                            110.395497,
                            -7.797803999999999
                        ]
                    ]
                ]
            },
            "attributes": {}
        },
        "contributors": null,
        "retweet_count": 0,
        "favorite_count": 0,
        "entities": {
            "hashtags": [],
            "symbols": [],
            "urls": [],
            "user_mentions": []
        },
        "favorited": false,
        "retweeted": false,
        "filter_level": "medium",
        "lang": "id"
    }
];