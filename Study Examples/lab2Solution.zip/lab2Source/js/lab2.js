// Want to convert from K to F 
      function tempInF(tempInK) {
        // API returns temp in degrees Kelvin - to get degrees in C we subtract 273.15 from the Kelvin temp      
        var k2c = 273.15;

        return(Math.round((tempInK - k2c) * 9/5 + 32));
      }
// Want windspeed in mph
      function speedInMPH(speedInMps) {
        return(Math.round(speedInMps * 2.2369362920544));
      }

      try {
        navigator.geolocation && navigator.geolocation.getCurrentPosition(function (position) {
          console.log(position);
          lat = position.coords.latitude;
          lon = position.coords.longitude;
          var url = "http://api.openweathermap.org/data/2.5/weather?lat="+lat+"&lon="+lon;
          $.ajax({
            dataType: "jsonp",
            url: url,
            success: function success(data) {
              console.log(data);
              $("#icon").css({
                 "background-image" : "url('http://openweathermap.org/img/w/" + data.weather[0].icon +"')"
              });
              $("#location").html(data.name);
              $("#condition").html(data.weather[0].description);
              $("#temp").html(tempInF(data.main.temp) + "<span id='degreeSymbol'>&deg;<span id='scale'>F</span></span>");
              $("#wind").html("Wind: " + speedInMPH(data.wind.speed)  + " mph");
              $("#humidity").html("Humidity: " + data.main.humidity + "%");
            }, error: function(xhr, sts, err) {
              alert("xhr message: " + xhr.status +" " + xhr.statusText +"\nError: " + sts + "\nMessage: " + err);
            }
          });   
        });
      } catch (err) {
        errmsg = "An error was encountered: ";
        errmsg += err.message;
        errmsg += "\n";
        alert(errmsg);
      }

 