5/05/2014

I spent about an hour trying to get node.js to serve a different html page once the database is done bieng populated. I couldn't get that code to work and I probaby botched my grade on this quiz because of it. I wanted to serve a new page with a different page description and the form for the user to query the database.

code is in server.js and index.html