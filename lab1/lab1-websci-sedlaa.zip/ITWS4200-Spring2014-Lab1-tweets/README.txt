This web app was written by Aaron Woodrow Sedlacek, on 02/05/2014

This app pulls tweet data from a json file using AJAX and displays it on the index.html page in a pleasant and enjoyable layout.

If the user's profile picture cannot be found, their profile picture is instead replaced with a picture of Prof. Plotka.

installation instructions:

	1. Open index.html in a browser.

(note) watch out for Same Origin Policy problems, I could not get this application to work in chrome without making a virtual host

This application was designed and tested in Safari.

--Thanks for reading me!