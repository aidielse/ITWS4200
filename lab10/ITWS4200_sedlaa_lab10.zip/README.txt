04/29/2014
Lab 10 submission

Prof. Plotka gave my group a one day extension on this lab as per Mike Xie's request.

Due to running Mac OS X and having difficulties with the weird box things in the .docx, 
I have saved my queries in a file called Queries.txt.

The results are saved in: ITWS4200_sedlaa_Lab10Qn.rdf where n is the question number.
I could find no mention of any sort of naming convention ever mentioned by Prof. Plotka since Web Sys Dev.

The FOAF is saved as awsfoaf.rdf
