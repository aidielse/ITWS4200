var api_key = "bbcbd884606f1e1ec284b719c4cd9641",
    my_latitude, 
    my_longitude, 
    geocoder, 
    curr_lctn;

var hourly = false, daily = false;

function success( position ) {

  my_latitude = position.coords.latitude.toString();
  my_longitude = position.coords.longitude.toString();
  console.log( "Latitude: " + my_latitude );
  console.log( "Longitude: " + my_longitude );

}

function error( error ) {

  console.log( 'ERROR ' + error.code + ': ' + error.message );

}

function api_call() {

  $.ajax( {
    dataType: "json",
    url: "https://api.forecast.io/forecast/" + api_key + "/" + my_latitude + "," + my_longitude + "?callback=?",
    async: false,
    success: weather_current
  } );

}

function initialize() {

  geocoder = new google.maps.Geocoder();
  var city, state;
  var gm_latlng = new google.maps.LatLng( parseFloat(my_latitude), parseFloat(my_longitude) );
  geocoder.geocode( {'latLng': gm_latlng}, function( results, status ) {
    if ( status == google.maps.GeocoderStatus.OK ) {
      if ( results[1] ) {
        for ( var i=0; i<results[0].address_components.length; i++ ) {
          for ( var b=0; b<results[0].address_components[i].types.length; b++ ) {
            if ( results[0].address_components[i].types[b] == "locality" ) {
              city = results[0].address_components[i];
            }
            if ( results[0].address_components[i].types[b] == "administrative_area_level_1" ) {
              state = results[0].address_components[i];
            }
          }
        }
      }
      curr_lctn = city.long_name + ", " + state.short_name;
    } else {
      console.log( "Geolocation Error: " + status );
    }
  } );

}

function weather_current( weather_data ) {

  call_time = weather_data.currently.time;
  curr_summ = weather_data.currently.summary;
  curr_icon = weather_data.currently.icon;
  curr_temp = weather_data.currently.temperature;
  curr_atmp = weather_data.currently.apparentTemperature;
  curr_wspd = weather_data.currently.windSpeed;
  curr_hmdy = weather_data.currently.humidity;
  curr_dewp = weather_data.currently.dewPoint;

  var date = new Date( call_time * 1000 );
  var time = date.toLocaleTimeString();

  var output = "<div id='bg-container'>";
  var icon;

  switch( curr_icon ) {
    case "clear-day":
      icon = "01";
      break;
    case "clear-night":
      icon = "02";
      break;
    case "rain":
      icon = "03";
      break;
    case "snow":
      icon = "04";
      break;
    case "sleet":
      icon = "05";
      break;
    case "wind":
      icon = "06";
      break;
    case "fog":
      icon = "07";
      break;
    case "cloudy":
      icon = "08";
      break;
    case "partly-cloudy-day":
      icon = "09";
      break;
    case "partly-cloudy-night":
      icon = "10";
      break;
    default:
      icon = "00";
      break;
  }

  output += "<img src='img/" + icon + ".jpg' id='current-background' />";
  output += "</div>";
  output += "<div id='current-wrapper'>";
  output += "<div id='weather-wrapper'><div id='current-location' class='location'>" + curr_lctn + "</div>";
  output += "<img src='icon/" + icon + ".png' height='180' width='180' id='current-icon' />";
  output += "<div id='current-temperature' class='temperature'>" + Math.round( curr_temp ) + "<sup>&deg;F</sup></div></div>";
  if ( Math.round( curr_temp ) != Math.round( curr_atmp ) )
    output += "<div id='apparent-temperature'>Feels like " + Math.round( curr_atmp ) + " &deg;F</div>";
  output += "<div id='current-wind-speed'>Wind speed is " + curr_wspd + " mph</div>";
  output += "<div id='current-humidity'>Humidity is " + curr_hmdy * 100 + "&#37;</div>";
  output += "<div id='info-wrapper'><div id='call-time'>Data generated at " + time + "</div>";
  output += "<div id='forecast-io'>Powered by <a href='http://forecast.io/'>forecast.io</a></div></div>";
  output += "</div>";

  document.getElementById( "current-weather" ).innerHTML = output;

  if ( weather_data.alerts ) {

    $( "#current-weather" ).append( "<div id='alert-box'></div>" );

    console.log("Severe Weather Warning");

    alrt = weather_data.alerts;

    output = "<div id='alert'>Alerts:</div>";

    for ( i in alrt ) {

      var d = new Date( alrt[i].expires * 1000 );
      var e = d.toLocaleTimeString();
      var e = e.substring( 0, e.length - 6 ) + e.substring( e.length - 3, e.length );
      var n = d.getDay(); var day;

      switch( n ) {
        case 0: day = "Sunday";
          break;
        case 1: day = "Monday";
          break;
        case 2: day = "Tuesday";
          break;
        case 3: day = "Wednesday";
          break;
        case 4: day = "Thursday";
          break;
        case 5: day = "Friday";
          break;
        case 6: day = "Saturday";
          break;
      }

      output += "<div class='alert'><a href='" + alrt[i].uri + "'>" + alrt[i].title + "</a> until " + e + " on " + day + "</div>";

    }

    document.getElementById( "alert-box" ).innerHTML = output;

  }

  if ( hourly ) {

    hour = weather_data.hourly;

    $( "#current-weather" ).append( "<div id='hourly-weather'></div>" );

    output = "<div class='title'>Hourly Forecast</div>";

    document.getElementById( "hourly-weather" ).innerHTML = output;

  }

  if ( daily ) {

    dail = weather_data.daily;

    $( "#current-weather" ).append( "<div id='daily-weather'></div>" );

    output = "<div class='title'>Daily Forecast</div>";

    document.getElementById( "daily-weather" ).innerHTML = output;

  }

}

navigator.geolocation.getCurrentPosition( success, error );

setTimeout( initialize, 200 );
setTimeout( api_call, 200 );