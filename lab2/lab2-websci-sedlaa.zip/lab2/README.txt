Weather App by Aaron Sedlacek
02/13/2014

This app was designed and tested in safari web browser. There might be SoP(Same origin Policy) problems in any other browser.

I reccomend putting this web app on a Virtual Server.

Install Instructions:

1. Get apache configured for virtualhosts
2. Copy every file in this directory to your root directory for your virtual server

This web app utilizes google maps api for geocoding and location. 

It also utilizes the forecast.io API for weather data. 

Longitude and Latitude information is obtained from the google maps API and given to the forecast.io API.

comments? criticisms? snide remarks? email me at aarons104@gmail.com