Web Science Lab 5
Aaron Sedlacek
3/05/2014

I used Node.js for this lab. Mainly Express for the server/listener, fs to write to a file, and ntwitter for twitter API interfacing

Installation/Execution Instructions:

	1. Make sure you have Node.js Express, fs, and ntwitter:
		brew install node
		npm install express
		npm install fs
		npm install ntwitter

	2. make sure your terminal is in the current directory, then type the following:

		node server.js

I feel that my code is commented sufficiently to explain how everything works. 

This application uses the keys that I registered with twitter for Lab 4.